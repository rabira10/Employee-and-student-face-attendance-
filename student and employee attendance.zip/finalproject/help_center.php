<?php
session_start();

// Language support
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

$default_lang = 'en'; // Default language
$current_lang = $_SESSION['lang'] ?? $default_lang;

// Load translations
$translations = [];
$lang_file = "languages/{$current_lang}.php";
if (file_exists($lang_file)) {
    $translations = require $lang_file;
}

// Helper function for translations
function t($key, $translations) {
    return $translations[$key] ?? $key;
}

// Check authentication and role
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student_dean') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo t('help_center', $translations); ?> - <?php echo t('dire_dawa_university', $translations); ?></title>
    <style>
        /* Include all the CSS from your main dashboard */
        <?php include 'styles.php'; ?>
        
        .help-container {
            max-width: 1000px;
            margin: 2rem auto;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }
        
        .faq-section {
            margin-top: 2rem;
        }
        
        .faq-item {
            margin-bottom: 1rem;
            border: 1px solid #e1e5e9;
            border-radius: 8px;
            overflow: hidden;
        }
        
        .faq-question {
            padding: 1rem;
            background: #f8f9fa;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: 600;
        }
        
        .faq-answer {
            padding: 0 1rem;
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease;
        }
        
        .faq-item.active .faq-answer {
            padding: 1rem;
            max-height: 500px;
        }
        
        .search-box {
            width: 100%;
            padding: 1rem;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            margin-bottom: 2rem;
        }
        
        .help-categories {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin: 2rem 0;
        }
        
        .category-card {
            background: white;
            border-radius: 8px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .category-card:hover {
            transform: translateY(-5px);
        }
        
        .category-icon {
            font-size: 2rem;
            color: #003366;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <!-- Header (same as dashboard) -->
    <?php include 'header.php'; ?>

    <div class="container">
        <div class="help-container">
            <div class="card-header">
                <div class="card-icon">❓</div>
                <div class="card-title"><?php echo t('help_center', $translations); ?></div>
            </div>
            
            <p><?php echo t('help_center_description', $translations); ?></p>
            
            <input type="text" class="search-box" placeholder="<?php echo t('search_help_articles', $translations); ?>...">
            
            <h3><?php echo t('help_categories', $translations); ?></h3>
            <div class="help-categories">
                <a href="#attendance-help" class="category-card">
                    <div class="category-icon"><i class="fas fa-calendar-check"></i></div>
                    <h4><?php echo t('attendance', $translations); ?></h4>
                </a>
                
                <a href="#student-management" class="category-card">
                    <div class="category-icon"><i class="fas fa-users"></i></div>
                    <h4><?php echo t('student_management', $translations); ?></h4>
                </a>
                
                <a href="#reports" class="category-card">
                    <div class="category-icon"><i class="fas fa-chart-bar"></i></div>
                    <h4><?php echo t('reports', $translations); ?></h4>
                </a>
                
                <a href="#account" class="category-card">
                    <div class="category-icon"><i class="fas fa-user-cog"></i></div>
                    <h4><?php echo t('account_settings', $translations); ?></h4>
                </a>
            </div>
            
            <div class="faq-section">
                <h3><?php echo t('frequently_asked_questions', $translations); ?></h3>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <span><?php echo t('how_to_set_attendance_time', $translations); ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p><?php echo t('attendance_time_instructions', $translations); ?></p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <span><?php echo t('how_to_generate_reports', $translations); ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p><?php echo t('report_generation_instructions', $translations); ?></p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <span><?php echo t('how_to_register_student', $translations); ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p><?php echo t('student_registration_instructions', $translations); ?></p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <span><?php echo t('how_to_change_password', $translations); ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p><?php echo t('password_change_instructions', $translations); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="still-need-help">
                <h3><?php echo t('still_need_help', $translations); ?></h3>
                <p><?php echo t('contact_our_support_team', $translations); ?></p>
                <a href="contact_us.php" class="btn">
                    <i class="fas fa-headset"></i> <?php echo t('contact_support', $translations); ?>
                </a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script>
        // FAQ toggle functionality
        document.querySelectorAll('.faq-question').forEach(question => {
            question.addEventListener('click', () => {
                const item = question.parentElement;
                item.classList.toggle('active');
                
                const icon = question.querySelector('i');
                if (item.classList.contains('active')) {
                    icon.classList.remove('fa-chevron-down');
                    icon.classList.add('fa-chevron-up');
                } else {
                    icon.classList.remove('fa-chevron-up');
                    icon.classList.add('fa-chevron-down');
                }
            });
        });
        
        // Search functionality
        const searchBox = document.querySelector('.search-box');
        searchBox.addEventListener('input', (e) => {
            const searchTerm = e.target.value.toLowerCase();
            const faqItems = document.querySelectorAll('.faq-item');
            
            faqItems.forEach(item => {
                const question = item.querySelector('.faq-question').textContent.toLowerCase();
                const answer = item.querySelector('.faq-answer').textContent.toLowerCase();
                
                if (question.includes(searchTerm) || answer.includes(searchTerm)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>