<?php
header('Content-Type: application/json');
session_start();

// Check authentication
if (!isset($_SESSION['user'])) {
    echo json_encode([]);
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die(json_encode([]));
}

$result = $conn->query("SELECT full_name, face_descriptor FROM students WHERE face_descriptor IS NOT NULL");
$students = [];
while ($row = $result->fetch_assoc()) {
    $students[] = $row;
}

echo json_encode($students);
$conn->close();
?>