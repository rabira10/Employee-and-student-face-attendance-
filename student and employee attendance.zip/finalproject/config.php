<?php
// config.php

date_default_timezone_set('Africa/Addis_Ababa');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ddu_attendance');

// Simple database connection class
class Database {
    private $conn;
    
    public function __construct() {
        $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($this->conn->connect_error) {
            die("Database connection failed: " . $this->conn->connect_error);
        }
    }
    
    public function getConnection() {
        return $this->conn;
    }

    public function getAllEmployees() {
        $sql = "SELECT username, face_descriptor FROM employees WHERE face_descriptor IS NOT NULL";
        $result = $this->conn->query($sql);
        $users = [];

        while ($row = $result->fetch_assoc()) {
            $users[] = [
                'username' => $row['username'],
                'descriptor' => json_decode($row['face_descriptor'])
            ];
        }

        return $users;
    }
}
