<?php
echo password_hash('hr123', PASSWORD_DEFAULT);
?>
