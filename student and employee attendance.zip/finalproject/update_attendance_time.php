<?php
session_start();

// Message display (if redirected back with session message)
$message = $_SESSION['message'] ?? "";
unset($_SESSION['message']);

// Only HR can access this page
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'hr') {
    header("Location: login.html");
    exit();
}

// Connect to DB
$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $am_start = $_POST['am_start_time'] ?? '';
    $am_end   = $_POST['am_end_time'] ?? '';
    $pm_start = $_POST['pm_start_time'] ?? '';
    $pm_end   = $_POST['pm_end_time'] ?? '';

    $stmt = $conn->prepare("UPDATE attendance_settings 
        SET am_start_time = ?, am_end_time = ?, pm_start_time = ?, pm_end_time = ?, updated_at = NOW() 
        WHERE id = 1");
    $stmt->bind_param("ssss", $am_start, $am_end, $pm_start, $pm_end);

    if ($stmt->execute()) {
        $_SESSION['message'] = "✅ Attendance times updated successfully.";
    } else {
        $_SESSION['message'] = "❌ Error updating times: " . $stmt->error;
    }

    $stmt->close();
    header("Location: update_attendance_time.php");
    exit();
}

// Get current time for display
date_default_timezone_set("Africa/Addis_Ababa");
$currentTime = date("h:i A");

// Fetch current time settings
$result = $conn->query("SELECT * FROM attendance_settings WHERE id = 1");
$settings = $result->fetch_assoc() ?? [
    'am_start_time' => '',
    'am_end_time' => '',
    'pm_start_time' => '',
    'pm_end_time' => ''
];

$conn->close();

// Convert to 12-hour format for display
function convertTo12Hour($time24) {
    if (!$time24) return '';
    return date("h:i A", strtotime($time24));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Set Attendance Time</title>
  <style>
    body { font-family: Arial; padding: 30px; background-color: #f0f4f8; color: #003366; }
    form { background: #fff; padding: 20px; border-radius: 8px; width: 500px; margin: auto; box-shadow: 0 0 8px rgba(0,0,0,0.1); }
    input[type='time'] { width: 100%; padding: 10px; margin-top: 5px; margin-bottom: 10px; border: 1px solid #003366; border-radius: 4px; }
    button { padding: 10px 20px; background: #003366; color: #FFCC00; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; }
    button:hover { background: #FFCC00; color: #003366; }
    .message { margin-top: 20px; padding: 10px; background-color: #e7f3fe; border-left: 5px solid #2196F3; }
    label { display: block; font-weight: bold; margin-top: 15px; }
    .back-link {
        display: inline-block;
        margin-bottom: 20px;
        text-decoration: none;
        background-color: #003366;
        color: #FFCC00;
        padding: 8px 16px;
        border-radius: 6px;
        font-weight: bold;
        transition: background-color 0.3s ease, color 0.3s ease;
    }
    .back-link:hover {
        background-color: #FFCC00;
        color: #003366;
    }
    .time-12h {
        font-size: 0.9em;
        color: #555;
        margin-top: 3px;
    }
  </style>
</head>
<body>

<h2 style="text-align: center;">🕒 Set Attendance Time Windows</h2>

<div style="text-align: center; margin-bottom: 20px;">
    Current Time: <strong><?= $currentTime ?></strong><br>
    <a href="dashboard_hr.php" class="back-link">← Back to Dashboard</a>
</div>

<?php if ($message): ?>
    <div class="message"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<form method="POST">
    <label for="am_start_time">AM Start Time:</label>
    <input type="time" name="am_start_time" id="am_start_time" required value="<?= htmlspecialchars($settings['am_start_time']) ?>">
    <div class="time-12h">12-hour: <?= convertTo12Hour($settings['am_start_time']) ?></div>

    <label for="am_end_time">AM End Time:</label>
    <input type="time" name="am_end_time" id="am_end_time" required value="<?= htmlspecialchars($settings['am_end_time']) ?>">
    <div class="time-12h">12-hour: <?= convertTo12Hour($settings['am_end_time']) ?></div>

    <label for="pm_start_time">PM Start Time:</label>
    <input type="time" name="pm_start_time" id="pm_start_time" required value="<?= htmlspecialchars($settings['pm_start_time']) ?>">
    <div class="time-12h">12-hour: <?= convertTo12Hour($settings['pm_start_time']) ?></div>

    <label for="pm_end_time">PM End Time:</label>
    <input type="time" name="pm_end_time" id="pm_end_time" required value="<?= htmlspecialchars($settings['pm_end_time']) ?>">
    <div class="time-12h">12-hour: <?= convertTo12Hour($settings['pm_end_time']) ?></div>

    <button type="submit">💾 Save Settings</button>
</form>

</body>
</html>
