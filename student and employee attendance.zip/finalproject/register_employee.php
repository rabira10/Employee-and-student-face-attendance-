<?php
session_start();

// Database configuration
$host = 'localhost';
$dbname = 'ddu_attendance';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Create uploads directory if not exists
if (!is_dir(__DIR__ . '/uploads')) {
    mkdir(__DIR__ . '/uploads', 0755, true);
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['username']) && !empty($_POST['password']) && !empty($_POST['full_name'])) {
        $username = trim($_POST['username']);

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM employees WHERE username = ?");
        $stmt->execute([$username]);
        $userExists = $stmt->fetchColumn();

        if ($userExists) {
            $message = "Error: Username already exists.";
        } else {
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $full_name = trim($_POST['full_name']);
            $email = $_POST['email'] ?? null;
            $phone = $_POST['phone'] ?? null;
            $job_position = $_POST['job_position'] ?? null;
            $salary = $_POST['salary'] ?? null;
            $hire_date = $_POST['hire_date'] ?? null;
            $address = $_POST['address'] ?? null;

            $photo_path = '';
            if (isset($_FILES['photo_path']) && $_FILES['photo_path']['error'] === UPLOAD_ERR_OK) {
                $fileTmpPath = $_FILES['photo_path']['tmp_name'];
                $fileName = $_FILES['photo_path']['name'];
                $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

                $allowedfileExtensions = ['jpg', 'jpeg', 'png', 'gif'];
                if (in_array($fileExtension, $allowedfileExtensions)) {
                    $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
                    $uploadFileDir = __DIR__ . '/uploads/';
                    $dest_path = $uploadFileDir . $newFileName;
                    if (move_uploaded_file($fileTmpPath, $dest_path)) {
                        $photo_path = 'uploads/' . $newFileName;
                    } else {
                        $message = "Error uploading photo.";
                    }
                } else {
                    $message = "Only JPG, JPEG, PNG, GIF files allowed.";
                }
            }

            if (empty($_POST['face_descriptor'])) {
                $message = "Please capture your face for recognition.";
            } else {
                $face_descriptor = $_POST['face_descriptor'];
                $descArray = json_decode($face_descriptor, true);
                if (!is_array($descArray) || count($descArray) !== 128) {
                    $message = "Invalid face descriptor.";
                }
            }

            if (empty($message)) {
                try {
                    $pdo->beginTransaction();
                    $stmt = $pdo->prepare("INSERT INTO employees (username, password, full_name, email, phone, job_position, salary, hire_date, photo_path, address, face_descriptor, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                    $stmt->execute([$username, $password, $full_name, $email, $phone, $job_position, $salary, $hire_date, $photo_path, $address, $face_descriptor]);

                    $stmt2 = $pdo->prepare("INSERT INTO users (username, full_name, password, role) VALUES (?, ?, ?, ?)");
                    $stmt2->execute([$username, $full_name, $password, 'employee']);

                    $pdo->commit();
                    $_SESSION['success_message'] = "Employee registered successfully!";
                    header("Location: register_employee.php");
                    exit;
                } catch (PDOException $e) {
                    $pdo->rollBack();
                    $message = "Database error: " . $e->getMessage();
                }
            }
        }
    } else {
        $message = "Please fill in all required fields.";
    }
}

if (isset($_SESSION['success_message'])) {
    $message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Employee Registration/የሰራተኛ ምዝገባ</title>
  <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@2.0.0/dist/tf.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
  <style>
    body {
      font-family: Arial;
      background: #f0f0f0;
      margin: 0;
      padding: 20px;
    }
    .container {
      max-width: 800px;
      margin: auto;
      background: white;
      padding: 30px;
      border-radius: 8px;
      position: relative;
    }
    input, textarea, button, select {
      width: 100%;
      padding: 10px;
      margin-top: 10px;
      font-size: 16px;
    }
    label {
      font-weight: bold;
      margin-top: 15px;
      display: block;
    }
    #video {
      margin-top: 10px;
      border: 2px solid #003366;
      border-radius: 6px;
    }
    .message {
      padding: 10px;
      background: #d4edda;
      color: #155724;
      margin-bottom: 15px;
      border: 1px solid #c3e6cb;
      border-radius: 4px;
    }
    .error {
      background: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }
    .back-btn {
      position: absolute;
      top: 20px;
      right: 20px;
      padding: 8px 15px;
      background: #003366;
      color: white;
      text-decoration: none;
      border-radius: 4px;
      font-size: 14px;
    }
    .back-btn:hover {
      background: #002244;
    }
    .form-footer {
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
    }
  </style>
</head>
<body>
<div class="container">
  <a href="dashboard_hr.php" class="back-btn">Back to Dashboard/ወደ ዳሽቦርድ ተመለስ</a>
  
  <h2>Register Employee/የሰራተኛ ምዝገባ</h2>

  <?php if ($message): ?>
    <div class="message <?= strpos($message, 'Error') !== false ? 'error' : '' ?>">
      <?= htmlspecialchars($message) ?>
    </div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data" id="registrationForm">
    <label for="username">Username/የተጠቃሚ ስም *</label>
    <input type="text" name="username" id="username" required>

    <label for="password">Password/የይለፍ ቃል *</label>
    <input type="password" name="password" id="password" required>

    <label for="full_name">Full Name/ሙሉ ስም *</label>
    <input type="text" name="full_name" id="full_name" required>

    <label for="email">Email/ኢሜይል</label>
    <input type="email" name="email" id="email">

    <label for="phone">Phone/ስልክ</label>
    <input type="text" name="phone" id="phone">

    <label for="job_position">Job Position/የስራ መደብ</label>
    <input type="text" name="job_position" id="job_position">

    <label for="salary">Salary/ደሞዝ</label>
    <input type="number" name="salary" id="salary" step="0.01">

    <label for="hire_date">Hire Date/የቅጥር ቀን</label>
    <input type="date" name="hire_date" id="hire_date">

    <label for="photo_path">Photo/ፎቶ</label>
    <input type="file" name="photo_path" id="photo_path" accept="image/*">

    <label for="address">Address/አድራሻ</label>
    <textarea name="address" id="address" rows="3"></textarea>

    <h3>Face Recognition/ፊት እውቅና</h3>
    <video id="video" width="320" height="240" autoplay muted></video>
    <button type="button" id="captureBtn">Capture Face/ፊት ያንሱ</button>
    <input type="hidden" id="faceDescriptor" name="face_descriptor">
    <div id="faceStatus" style="margin-top:10px;"></div>

    <div class="form-footer">
      <button type="submit">Register/ይመዝገቡ</button>
    </div>
  </form>
</div>

<script>
  const MODEL_URL = "http://localhost/finalproject/models";

  async function initFaceAPI() {
    const faceStatus = document.getElementById('faceStatus');
    try {
      await faceapi.nets.tinyFaceDetector.loadFromUri('/finalproject/models');
      await faceapi.nets.faceLandmark68Net.loadFromUri('/finalproject/models');
      await faceapi.nets.faceRecognitionNet.loadFromUri('/finalproject/models');

      faceStatus.innerText = "Models loaded successfully! ሞዴሎች በተሳካ ሁኔታ ተጭነዋል!";
    } catch (e) {
      faceStatus.innerText = "Error loading models: " + e;
      return;
    }

    const video = document.getElementById('video');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: {} });
      video.srcObject = stream;
    } catch (err) {
      faceStatus.innerText = "Webcam error: " + err;
    }

    document.getElementById('captureBtn').addEventListener('click', async () => {
      faceStatus.innerText = "Capturing face...";
      const detection = await faceapi.detectSingleFace(video, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks()
        .withFaceDescriptor();

      if (!detection) {
        faceStatus.innerText = "No face detected. Try again.";
        return;
      }

      const descriptor = Array.from(detection.descriptor);
      document.getElementById('faceDescriptor').value = JSON.stringify(descriptor);
      faceStatus.innerText = "Face captured successfully!";
    });
  }

  document.addEventListener('DOMContentLoaded', initFaceAPI);
</script>
</body>
</html>