<?php
session_start();
$errorType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $accountType = $_POST['account_type'] ?? '';

    $conn = new mysqli('localhost', 'root', '', 'ddu_attendance');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Function to check user credentials in a given table
    function checkUser($conn, $table, $username, $password, $role = null) {
        if ($role !== null) {
            $stmt = $conn->prepare("SELECT * FROM $table WHERE username = ? AND role = ?");
            $stmt->bind_param("ss", $username, $role);
        } else {
            $stmt = $conn->prepare("SELECT * FROM $table WHERE username = ?");
            $stmt->bind_param("s", $username);
        }
        if (!$stmt) return false;

        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();

        if (!$user) return false;

        // Check active status columns (is_active or status)
        $isActive = 1;
        if (isset($user['is_active'])) {
            $isActive = (int)$user['is_active'];
        } elseif (isset($user['status'])) {
            $isActive = (int)$user['status'];
        }
        if ($isActive === 0) return 'deactivated';

        if (!password_verify($password, $user['password'])) return false;

        return $user;
    }

    $user = false;

    // First check in users table for username + role
    $user = checkUser($conn, 'users', $username, $password, $accountType);

    // If not found in users table, check role-specific table (no role column)
    if (!$user) {
        // Map roles to their specific tables
        $roleTables = [
            'student_dean' => 'student_deans',
            'student' => 'students',
            'hr' => 'hr_officers',
            'employee' => 'employees',
            // Add more role=>table mappings if needed
        ];

        if (isset($roleTables[$accountType])) {
            $table = $roleTables[$accountType];
            // Role column doesn't exist in these tables, so pass null for role
            $user = checkUser($conn, $table, $username, $password, null);
        }
    }

    if ($user === 'deactivated') {
        $errorType = 'deactivated';
    } elseif ($user) {
        $_SESSION['user'] = $user['username'];
        $_SESSION['role'] = $accountType;

        // Set student_id for student role
        if ($accountType === 'student') {
            $_SESSION['student_id'] = $user['id'] ?? null;
        }

        // Redirect based on role
        switch ($accountType) {
            case 'admin':
                header("Location: admin_dashboard.php");
                break;
            case 'hr':
                header("Location: dashboard_hr.php");
                break;
            case 'employee':
                header("Location: dashboard_employee.php");
                break;
            case 'student_dean':
                header("Location: student_dean_dashboard.php");
                break;
            case 'student':
                header("Location: student_dashboard.php");
                break;
            default:
                $errorType = 'invalid_credentials';
                session_destroy();
                break;
        }
        exit();
    } else {
        $errorType = 'invalid_credentials';
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dire Dawa University - Login</title>
  <style>
    :root {
      --ddu-primary: #003366;
      --ddu-secondary: #FFCC00;
      --ddu-accent: #1a4d6b;
      --ddu-white: #ffffff;
    }
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-image: linear-gradient(135deg, var(--ddu-primary), var(--ddu-accent));
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0;
    }
    .login-container {
      background-color: var(--ddu-white);
      padding: 2.5rem;
      border-radius: 10px;
      box-shadow: 0 4px 25px rgba(0, 0, 0, 0.15);
      max-width: 450px;
      width: 100%;
      border-top: 6px solid var(--ddu-secondary);
    }
    .login-header {
      text-align: center;
      margin-bottom: 2rem;
    }
    .login-header img {
      height: 70px;
      margin-bottom: 1rem;
    }
    .login-header h2 {
      color: var(--ddu-primary);
      font-size: 1.8rem;
      margin: 0;
    }
    .form-group {
      margin-bottom: 1.2rem;
    }
    label {
      font-weight: 600;
      color: var(--ddu-primary);
    }
    input, select {
      width: 100%;
      padding: 0.8rem;
      border: 2px solid #ddd;
      border-radius: 6px;
      font-size: 1rem;
    }
    input:focus, select:focus {
      border-color: var(--ddu-secondary);
      box-shadow: 0 0 0 3px rgba(255, 204, 0, 0.2);
      outline: none;
    }
    .login-btn {
      background-color: var(--ddu-primary);
      color: white;
      border: none;
      padding: 0.9rem;
      border-radius: 6px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      width: 100%;
      margin-top: 0.5rem;
    }
    .login-btn:hover {
      background-color: var(--ddu-accent);
    }
    .alert {
      padding: 1rem;
      border-radius: 6px;
      margin-top: 1.5rem;
      font-size: 0.95rem;
      display: flex;
      align-items: center;
      gap: 0.8rem;
    }
    .alert-danger {
      background-color: #fdecea;
      color: #c62828;
      border-left: 4px solid #c62828;
    }
    .modal {
      display: block;
      position: fixed;
      z-index: 1000;
      left: 0; top: 0;
      width: 100%; height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
    }
    .modal-content {
      background-color: white;
      margin: 15% auto;
      padding: 25px;
      border-radius: 8px;
      width: 80%;
      max-width: 400px;
      text-align: center;
      border-top: 5px solid var(--ddu-secondary);
    }
    .modal-title {
      color: var(--ddu-primary);
      font-size: 1.5rem;
      margin: 0;
    }
    .modal-message {
      margin: 20px 0;
      color: #555;
    }
    .modal-btn {
      background-color: var(--ddu-primary);
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 6px;
      font-size: 1rem;
      cursor: pointer;
    }
    .modal-btn:hover {
      background-color: var(--ddu-accent);
    }
  </style>
</head>
<body>
  <div class="login-container">
    <div class="login-header">
      <img src="images/ddu.jfif" alt="DDU Logo" />
      <h2>DIRE DAWA UNIVERSITY</h2>
      <p>Login to access the Attendance System</p>
    </div>

    <form class="login-form" action="login.php" method="POST">
      <div class="form-group">
        <label for="account_type">Account Type</label>
        <select name="account_type" required>
          <option value="">Select Account Type</option>
          <option value="admin">Administrator</option>
          <option value="hr">HR Officer</option>
          <option value="employee">Employee</option>
          <option value="student_dean">Student Dean</option>
          <option value="student">Student</option>
        </select>
      </div>
      <div class="form-group">
        <label for="username">Username</label>
        <input type="text" name="username" required />
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" name="password" required />
      </div>
      <button type="submit" class="login-btn">Login</button>
    </form>

    <?php if ($errorType === 'invalid_credentials'): ?>
      <div class="alert alert-danger">⚠️ Invalid username or password. Please try again.</div>
    <?php endif; ?>
  </div>

  <?php if ($errorType === 'deactivated'): ?>
    <div class="modal" id="deactivatedModal">
      <div class="modal-content">
        <h3 class="modal-title">Account Deactivated</h3>
        <p class="modal-message">Your account has been deactivated. Please contact the administration.</p>
        <button class="modal-btn" onclick="document.getElementById('deactivatedModal').style.display='none'">OK</button>
      </div>
    </div>
  <?php endif; ?>
</body>
</html>
