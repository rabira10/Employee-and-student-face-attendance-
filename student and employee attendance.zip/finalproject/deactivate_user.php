<?php
include 'dbe.php';
session_start();

// Verify admin role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Unauthorized access!";
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $action = trim($_POST['action']);
    
    // Validate inputs
    if (empty($username) || !in_array($action, ['activate', 'deactivate'])) {
        $_SESSION['error'] = "Invalid request parameters";
        header("Location: admin_dashboard.php");
        exit;
    }
    
    $new_status = ($action === 'activate') ? 1 : 0;
    
    try {
        // First check if user exists
        $check_stmt = $conn->prepare("SELECT username FROM users WHERE username = ?");
        $check_stmt->bind_param("s", $username);
        $check_stmt->execute();
        
        if ($check_stmt->get_result()->num_rows === 0) {
            $_SESSION['error'] = "User not found";
            header("Location: admin_dashboard.php");
            exit;
        }
        
        // Update status
        $update_stmt = $conn->prepare("UPDATE users SET is_active = ? WHERE username = ?");
        $update_stmt->bind_param("is", $new_status, $username);
        
        if ($update_stmt->execute()) {
            $action_text = ($action === 'activate') ? 'activated' : 'deactivated';
            $_SESSION['success'] = "User $username has been $action_text successfully!";
            
            // If deactivating current user, log them out
            if ($new_status === 0 && isset($_SESSION['user']) && $_SESSION['user'] === $username) {
                session_destroy();
                header("Location: login.php?message=account_deactivated");
                exit;
            }
        } else {
            $_SESSION['error'] = "Failed to update user status";
        }
    } catch (Exception $e) {
        $_SESSION['error'] = "Database error: " . $e->getMessage();
    }
    
    header("Location: admin_dashboard.php");
    exit;
}

$_SESSION['error'] = "Invalid request method";
header("Location: admin_dashboard.php");
?>