<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
var_dump($_POST);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: admin_login.php");
    exit;
}

// Retrieve and sanitize inputs
$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');
$role = trim($_POST['role'] ?? '');

// Check for empty fields
if (empty($username) || empty($password) || empty($role)) {
    header("Location: admin_login.php?error=missing_fields");
    exit;
}

// DB connection
$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Define table and dashboard based on role
$roleTables = [
    'admin' => ['table' => 'administrators', 'dashboard' => 'admin_dashboard.php'],
    'hr' => ['table' => 'hr_users', 'dashboard' => 'hr_dashboard.php'],
    'employee' => ['table' => 'employees', 'dashboard' => 'employee_dashboard.php']
];

if (!isset($roleTables[$role])) {
    header("Location: admin_login.php?error=invalid_role");
    exit;
}

$table = $roleTables[$role]['table'];
$dashboard = $roleTables[$role]['dashboard'];

// Query the user from the correct table
$stmt = $conn->prepare("SELECT id, username, password, full_name FROM $table WHERE username = ?");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    die("Query failed: " . $stmt->error);
}
if ($result->num_rows === 0) {
    header("Location: admin_login.php?error=invalid_credentials");
    exit;
}

// Validate user and password
$user = $result->fetch_assoc();

if (password_verify($password, $user['password'])) {
    $_SESSION['user'] = $user['username'];
    $_SESSION['role'] = $role;
    $_SESSION['full_name'] = $user['full_name'] ?? '';

    header("Location: $dashboard");
    exit;
}

// If login failed
header("Location: admin_login.php?error=invalid_credentials");
exit;
?>
