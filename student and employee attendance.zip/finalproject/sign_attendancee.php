<?php
session_start();

// Check if user is logged in and role is employee
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'employee') {
    header("Location: employee_login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];    // Numeric user ID from session
$username = $_SESSION['user'];       // For display only
$today = date("Y-m-d");

// Check if already signed attendance today
$stmt = $conn->prepare("SELECT * FROM attendance WHERE user_id = ? AND date = ?");
$stmt->bind_param("is", $user_id, $today);
$stmt->execute();
$result = $stmt->get_result();

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($result->num_rows > 0) {
        $message = "You already signed attendance today.";
    } else {
        $status = "present";

        $insert_stmt = $conn->prepare("INSERT INTO attendance (user_id, date, status) VALUES (?, ?, ?)");
        $insert_stmt->bind_param("iss", $user_id, $today, $status);
        if ($insert_stmt->execute()) {
            $message = "Attendance signed successfully for today ($today).";
        } else {
            $message = "Failed to sign attendance. Try again.";
        }
        $insert_stmt->close();
    }
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Sign Attendance</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 40px auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 0 8px rgba(0,0,0,0.1);
        }
        h2 {
            color: #145A32;
            text-align: center;
        }
        form {
            text-align: center;
            margin-top: 30px;
        }
        button {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 14px 28px;
            font-size: 16px;
            border-radius: 6px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #388E3C;
        }
        p.message {
            margin-top: 20px;
            font-weight: bold;
            color: #d9534f; /* red color */
            text-align: center;
        }
        a.back-link {
            display: block;
            text-align: center;
            margin-top: 30px;
            text-decoration: none;
            color: #145A32;
            font-weight: bold;
        }
        a.back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<h2>Sign Attendance for <?php echo htmlspecialchars($username); ?></h2>

<?php if ($message): ?>
    <p class="message"><?php echo htmlspecialchars($message); ?></p>
<?php endif; ?>

<form method="POST" action="">
    <button type="submit">Sign Attendance Today</button>
</form>

<a class="back-link" href="dashboard_employee.php">Back to Dashboard</a>

</body>
</html>
