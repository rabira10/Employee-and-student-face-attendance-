<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'hr') {
    header("Location: login.html");
    exit;
}

require 'db.php';

$startDate = $_POST['start_date'] ?? date('Y-m-d');
$endDate = $_POST['end_date'] ?? date('Y-m-d');
$exportType = $_POST['export'] ?? 'excel';

try {
    // Modified query to specify table for full_name
    $stmt = $pdo->prepare("
        SELECT a.id, e.full_name, a.date, a.status, a.session
        FROM attendance a
        JOIN employees e ON a.user_id = e.id
        WHERE a.date BETWEEN ? AND ?
        ORDER BY a.date ASC, e.full_name ASC, a.session ASC
    ");
    $stmt->execute([$startDate, $endDate]);
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Group by employee and date with AM/PM status
    $attendanceGrouped = [];
    foreach ($records as $record) {
        $key = $record['full_name'] . '_' . $record['date'];
        if (!isset($attendanceGrouped[$key])) {
            $attendanceGrouped[$key] = [
                'full_name' => $record['full_name'],
                'date' => $record['date'],
                'AM' => 'Absent',
                'PM' => 'Absent'
            ];
        }
        $attendanceGrouped[$key][$record['session']] = ucfirst($record['status']);
    }

    // Get all employees to include those without records
    $stmtAll = $pdo->query("SELECT id, full_name FROM employees ORDER BY full_name ASC");
    $allEmployees = $stmtAll->fetchAll(PDO::FETCH_ASSOC);

    // Modified query to properly join tables
    $stmtSigned = $pdo->prepare("
        SELECT DISTINCT e.full_name, a.date, a.session 
        FROM attendance a 
        JOIN employees e ON a.user_id = e.id 
        WHERE a.date BETWEEN ? AND ?
    ");
    $stmtSigned->execute([$startDate, $endDate]);
    $signed = $stmtSigned->fetchAll(PDO::FETCH_ASSOC);

    $signedMap = [];
    foreach ($signed as $row) {
        $signedMap[$row['date']][$row['session']][] = $row['full_name'];
    }

    $period = new DatePeriod(
        new DateTime($startDate),
        new DateInterval('P1D'),
        (new DateTime($endDate))->modify('+1 day')
    );

    foreach ($period as $dateObj) {
        $dateStr = $dateObj->format('Y-m-d');
        foreach (["AM", "PM"] as $session) {
            foreach ($allEmployees as $employee) {
                $key = $employee['full_name'] . '_' . $dateStr;
                if (!isset($attendanceGrouped[$key])) {
                    $attendanceGrouped[$key] = [
                        'full_name' => $employee['full_name'],
                        'date' => $dateStr,
                        'AM' => 'Absent',
                        'PM' => 'Absent'
                    ];
                }
                if (!in_array($employee['full_name'], $signedMap[$dateStr][$session] ?? [])) {
                    $attendanceGrouped[$key][$session] = 'Absent';
                }
            }
        }
    }

    // Sort by date and name
    usort($attendanceGrouped, function($a, $b) {
        return $a['date'] <=> $b['date'] ?: $a['full_name'] <=> $b['full_name'];
    });

    // Generate the export file
    if ($exportType === 'excel') {
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="attendance_'.date('Ymd').'.xls"');
        header('Cache-Control: max-age=0');
        
        echo "Employee Name\tDate\tAM Status\tPM Status\n";
        foreach ($attendanceGrouped as $record) {
            echo implode("\t", [
                $record['full_name'],
                $record['date'],
                $record['AM'],
                $record['PM']
            ]) . "\n";
        }
    } elseif ($exportType === 'word') {
        header('Content-Type: application/vnd.ms-word');
        header('Content-Disposition: attachment;filename="attendance_'.date('Ymd').'.doc"');
        header('Cache-Control: max-age=0');
        
        echo "<html><body>";
        echo "<table border='1'>";
        echo "<tr><th>Employee Name</th><th>Date</th><th>AM Status</th><th>PM Status</th></tr>";
        foreach ($attendanceGrouped as $record) {
            echo "<tr>";
            echo "<td>".htmlspecialchars($record['full_name'])."</td>";
            echo "<td>".htmlspecialchars($record['date'])."</td>";
            echo "<td>".htmlspecialchars($record['AM'])."</td>";
            echo "<td>".htmlspecialchars($record['PM'])."</td>";
            echo "</tr>";
        }
        echo "</table>";
        echo "</body></html>";
    }
} catch (PDOException $e) {
    die("Error exporting attendance: " . $e->getMessage());
}