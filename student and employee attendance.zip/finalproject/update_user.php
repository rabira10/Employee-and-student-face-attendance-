<?php
include 'dbe.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $new_name = $_POST['full_name'];
    $role = $_POST['role'];

    $stmt = $conn->prepare("UPDATE users SET full_name = ?, role = ? WHERE username = ?");
    $stmt->bind_param("sss", $new_name, $role, $username);
    $stmt->execute();

    echo "<p class='message'>✅ User updated successfully!</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Update User - Dire Dawa University</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #003366 0%, #1a4d6b 100%);
            min-height: 100vh;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 2rem;
        }

        /* Header */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: white;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border-bottom: 4px solid #FFCC00;
            padding: 1rem 0;
            z-index: 1000;
        }

        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .logo {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #003366, #004080);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
            box-shadow: 0 4px 15px rgba(0,51,102,0.3);
        }

        .university-info h1 {
            color: #003366;
            font-size: 1.5rem;
            margin-bottom: 0.2rem;
            font-weight: 700;
        }

        .university-info p {
            color: #666;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .hr-badge {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
            padding: 0.6rem 1rem;
            border-radius: 20px;
            font-weight: bold;
            font-size: 0.9rem;
            box-shadow: 0 4px 15px rgba(255,204,0,0.3);
        }

        /* Main Container */
        .container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 3rem;
            box-shadow: 0 15px 50px rgba(0,0,0,0.2);
            max-width: 500px;
            width: 100%;
            margin-top: 6rem;
            animation: slideIn 0.6s ease-out;
        }

        @keyframes slideIn {
            from { 
                opacity: 0; 
                transform: translateY(30px); 
            }
            to { 
                opacity: 1; 
                transform: translateY(0); 
            }
        }

        .form-title {
            text-align: center;
            color: #003366;
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .form-subtitle {
            text-align: center;
            color: #666;
            font-size: 1rem;
            margin-bottom: 2rem;
        }

        form {
            width: 100%;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #003366;
            font-size: 1rem;
        }

        input, select {
            width: 100%;
            padding: 1rem;
            border: 2px solid #e1e5e9;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: white;
            color: #333;
        }

        input:focus, select:focus {
            outline: none;
            border-color: #FFCC00;
            box-shadow: 0 0 0 3px rgba(255, 204, 0, 0.1);
            transform: translateY(-1px);
        }

        input:hover, select:hover {
            border-color: #003366;
        }

        select {
            cursor: pointer;
        }

        select option {
            padding: 0.5rem;
            background: white;
            color: #333;
        }

        button {
            width: 100%;
            background: linear-gradient(135deg, #003366, #004080);
            border: none;
            padding: 1.2rem;
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
            cursor: pointer;
            border-radius: 10px;
            transition: all 0.3s ease;
            margin-top: 1rem;
            box-shadow: 0 4px 15px rgba(0,51,102,0.3);
        }

        button:hover {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(255,204,0,0.4);
        }

        button:active {
            transform: translateY(0);
        }

        .message {
            text-align: center;
            font-weight: bold;
            margin-bottom: 1.5rem;
            padding: 1rem;
            border-radius: 10px;
            background: linear-gradient(135deg, #4CAF50, #45a049);
            color: white;
            box-shadow: 0 4px 15px rgba(76,175,80,0.3);
            animation: fadeIn 0.5s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.9); }
            to { opacity: 1; transform: scale(1); }
        }

        .back-link {
            text-align: center;
            margin-top: 1.5rem;
        }

        .back-link a {
            color: #003366;
            text-decoration: none;
            font-weight: 600;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .back-link a:hover {
            background: rgba(0,51,102,0.1);
            color: #FFCC00;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }

            .container {
                padding: 2rem;
                margin-top: 8rem;
            }

            .form-title {
                font-size: 1.6rem;
            }

            body {
                padding: 1rem;
            }
        }

        /* Loading animation for DDU logo */
        .logo {
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.8; }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-content">
            <div class="logo-section">
                <div class="logo">DDU</div>
                <div class="university-info">
                    <h1>Dire Dawa University</h1>
                    <p>User Management System</p>
                </div>
            </div>
            <div class="hr-badge">
                👤 Update User
            </div>
        </div>
    </div>

    <!-- Main Container -->
    <div class="container">
        <h1 class="form-title">Update User</h1>
        <p class="form-subtitle">Modify user information and roles</p>

        <form method="POST">
            <div class="form-group">
                <label for="username">Username (to update):</label>
                <input type="text" id="username" name="username" required placeholder="Enter username to update" />
            </div>

            <div class="form-group">
                <label for="full_name">New Full Name:</label>
                <input type="text" id="full_name" name="full_name" required placeholder="Enter new full name" />
            </div>

            <div class="form-group">
                <label for="role">New Role:</label>
                <select id="role" name="role" required>
                    <option value="">Select a role</option>
                    <option value="employee">Employee</option>
                    <option value="hr">HR Officer</option>
                    <option value="admin">Administrator</option>
                </select>
            </div>

            <button type="submit">
                🔄 Update User
            </button>
        </form>

        <div class="back-link">
            <a href="Admin_Dashboard.php">← Back to Admin Dashboard</a>
        </div>
    </div>
</body>
</html>
