<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'employee') {
    http_response_code(403);
    echo json_encode([
        "success" => false,
        "message" => "Access denied. Please log in. / መዳረሻ አይቻልም። እባክዎን ይግቡ።"
    ]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Invalid request method. / የተሳሳተ መመኪያ ዘዴ።"
    ]);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
if (!isset($data['verified']) || !$data['verified']) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Verification failed. / ማረጋገጥ አልተሳካም።"
    ]);
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Database connection failed. / የመረጃ ቋት ኮኔክሽን አልተሳካም።"
    ]);
    exit();
}

date_default_timezone_set('Africa/Addis_Ababa');
$username = $_SESSION['user'];
$now = new DateTime();
$currentTime = $now->format("H:i:s");
$currentDate = $now->format("Y-m-d");

// Load allowed time ranges
$settingQuery = $conn->query("SELECT * FROM attendance_settings WHERE id = 1");
$settings = $settingQuery->fetch_assoc();

$am_start = $settings['am_start'];
$am_end = $settings['am_end'];
$pm_start = $settings['pm_start'];
$pm_end = $settings['pm_end'];

$session = "";
if ($currentTime >= $am_start && $currentTime <= $am_end) {
    $session = "AM";
} elseif ($currentTime >= $pm_start && $currentTime <= $pm_end) {
    $session = "PM";
} else {
    function formatTime12($time24) {
        $dt = DateTime::createFromFormat('H:i:s', $time24);
        return $dt ? $dt->format('g:i A') : $time24;
    }

    echo json_encode([
        "success" => false,
        "message" => "❌ You are not within the allowed sign-in time range. / እርስዎ በተፈቀደው የመመዝገቢያ ጊዜ አውስላ አይደሉም።",
        "allowed" => [
            "AM" => formatTime12($am_start) . " - " . formatTime12($am_end),
            "PM" => formatTime12($pm_start) . " - " . formatTime12($pm_end),
            "now" => $now->format("g:i A")
        ]
    ]);
    exit();
}

// Prevent duplicate attendance per session
$check = $conn->prepare("SELECT id FROM attendance WHERE username = ? AND date = ? AND session = ?");
$check->bind_param("sss", $username, $currentDate, $session);
$check->execute();
$check->store_result();
if ($check->num_rows > 0) {
    echo json_encode([
        "success" => false,
        "message" => "⚠️ Already signed attendance for $session today. / ቀኑን በ$session ክፍል አስቀድሞ ተመዝግበዋል።"
    ]);
    exit();
}

// Insert attendance
$status = 'present';
$timeNow = $now->format("H:i:s");
$stmt = $conn->prepare("INSERT INTO attendance (username, date, status, time, session) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $username, $currentDate, $status, $timeNow, $session);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "✅ Attendance recorded successfully for $session at $timeNow. / በ$session ስር ተመዝግቧል።"
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "❌ Failed to record attendance. Try again. / መመዝገብ አልተሳካም። እባክዎ እንደገና ይሞክሩ።"
    ]);
}

$stmt->close();
$conn->close();
?>
