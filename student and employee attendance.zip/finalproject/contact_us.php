<?php
session_start();

// Language support
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

$default_lang = 'en'; // Default language
$current_lang = $_SESSION['lang'] ?? $default_lang;

// Load translations
$translations = [];
$lang_file = "languages/{$current_lang}.php";
if (file_exists($lang_file)) {
    $translations = require $lang_file;
}

// Helper function for translations
function t($key, $translations) {
    return $translations[$key] ?? $key;
}

// Check authentication and role
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student_dean') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo t('contact_us', $translations); ?> - <?php echo t('dire_dawa_university', $translations); ?></title>
    <style>
        /* Include all the CSS from your main dashboard */
        <?php include 'styles.php'; ?>
        
        .contact-container {
            max-width: 800px;
            margin: 2rem auto;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }
        
        .contact-methods {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }
        
        .contact-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .contact-card:hover {
            transform: translateY(-5px);
        }
        
        .contact-icon {
            font-size: 2rem;
            color: #003366;
            margin-bottom: 1rem;
        }
        
        .contact-form {
            margin-top: 2rem;
        }
        
        textarea {
            width: 100%;
            padding: 1rem;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            min-height: 150px;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <!-- Header (same as dashboard) -->
    <?php include 'header.php'; ?>

    <div class="container">
        <div class="contact-container">
            <div class="card-header">
                <div class="card-icon">📧</div>
                <div class="card-title"><?php echo t('contact_us', $translations); ?></div>
            </div>
            
            <p><?php echo t('contact_us_description', $translations); ?></p>
            
            <div class="contact-methods">
                <div class="contact-card">
                    <div class="contact-icon"><i class="fas fa-envelope"></i></div>
                    <h3><?php echo t('email_us', $translations); ?></h3>
                    <p>studentdean@ddu.edu.et</p>
                </div>
                
                <div class="contact-card">
                    <div class="contact-icon"><i class="fas fa-phone"></i></div>
                    <h3><?php echo t('call_us', $translations); ?></h3>
                    <p>+251 25 111 2233</p>
                    <p><?php echo t('working_hours', $translations); ?>: 8:30 AM - 5:00 PM (EAT)</p>
                </div>
                
                <div class="contact-card">
                    <div class="contact-icon"><i class="fas fa-map-marker-alt"></i></div>
                    <h3><?php echo t('visit_us', $translations); ?></h3>
                    <p><?php echo t('university_address', $translations); ?></p>
                </div>
            </div>
            
            <div class="contact-form">
                <h3><?php echo t('send_us_message', $translations); ?></h3>
                <form action="process_contact.php" method="POST">
                    <div class="form-group">
                        <label for="subject"><?php echo t('subject', $translations); ?>:</label>
                        <input type="text" id="subject" name="subject" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="message"><?php echo t('message', $translations); ?>:</label>
                        <textarea id="message" name="message" required></textarea>
                    </div>
                    
                    <button type="submit" class="btn">
                        <i class="fas fa-paper-plane"></i> <?php echo t('send_message', $translations); ?>
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
    
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>