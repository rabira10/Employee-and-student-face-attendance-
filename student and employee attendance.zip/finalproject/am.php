<?php
return [
    'welcome' => 'እንኳን ደህና መጡ የተማሪዎች ዲን!',
    'manage_records' => 'የተማሪዎችን ምግባር እና የትምህርት መዝገቦች ከማዕከላዊ ዳሽቦርድዎ �ስተዳድር',
    'student_management' => 'የተማሪ አስተዳደር',
    'quick_actions' => 'ፈጣን �ስራዎች',
    'view_students' => 'ሁሉንም ተማሪዎች ይመልከቱ',
    'attendance_reports' => 'የመገኘት ሪፖርቶች',
    'download_reports' => 'ሪፖርቶችን ያውርዱ',
    'send_notifications' => 'ማስታወቂያዎችን ላክ',
    'manage_accounts' => 'መለያዎችን ያስተዳድሩ',
    'register_student' => 'ተማሪ ይመዝግቡ',
    'change_password' => 'የይለፍ ቃል ቀይር',
    'logout' => 'ውጣ',
    'attendance_window' => 'የመገኘት ጊዜ መስኮት',
    'current_settings' => 'የአሁኑ ማቀናበሪያዎች',
    'start_time' => 'የመጀመሪያ ጊዜ',
    'end_time' => 'የመጨረሻ ጊዜ',
    'save_attendance' => 'የመገኘት ጊዜን አስቀምጥ',
    // Add all other text strings used in your application
];