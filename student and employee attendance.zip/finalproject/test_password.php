<?php
$plain = '1234'; // the testadmin password in plain text
$hash = password_hash($plain, PASSWORD_DEFAULT);
echo $hash;
?>
