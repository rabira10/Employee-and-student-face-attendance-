<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student') {
    header("Location: student_login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$student_id = $_SESSION['student_id'];

// Fetch attendance records for logged-in student
$stmt = $conn->prepare("SELECT date, status FROM student_attendance WHERE student_id = ? ORDER BY date DESC");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();

// Optional: fetch student info to display name, department, etc.
$stmt2 = $conn->prepare("SELECT full_name, department, year_of_study FROM students WHERE id = ?");
$stmt2->bind_param("i", $student_id);
$stmt2->execute();
$student_info = $stmt2->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>My Attendance</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: auto; }
        h1, h2 { color: #003366; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background-color: #003366; color: white; }
    </style>
</head>
<body>
    <h1>Welcome, <?php echo htmlspecialchars($student_info['full_name']); ?></h1>
    <h2>My Attendance Records</h2>
    <p><strong>Department:</strong> <?php echo htmlspecialchars($student_info['department']); ?></p>
    <p><strong>Year of Study:</strong> <?php echo htmlspecialchars($student_info['year_of_study']); ?></p>

    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['date']) . "</td>";
                    echo "<td>" . htmlspecialchars(ucfirst($row['status'])) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='2'>No attendance records found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>
