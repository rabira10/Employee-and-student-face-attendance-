<?php
include 'dbe.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['date'])) {
    $date = $_POST['date'];
    $stmt = $conn->prepare("SELECT full_name, username, status FROM attendance WHERE date = ?");
    $stmt->bind_param("s", $date);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<h2>Attendance Report for $date</h2>";
    echo "<table border='1'><tr><th>Full Name</th><th>Username</th><th>Status</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>{$row['full_name']}</td><td>{$row['username']}</td><td>{$row['status']}</td></tr>";
    }
    echo "</table>";
}
?>
