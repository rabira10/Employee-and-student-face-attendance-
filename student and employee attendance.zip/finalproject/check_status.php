<?php

include 'dbe.php';

if (isset($_SESSION['user'])) {
    $stmt = $conn->prepare("SELECT is_active FROM users WHERE username = ?");
    $stmt->bind_param("s", $_SESSION['user']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($user = $result->fetch_assoc()) {
        if ($user['is_active'] == 0) {
            // Return JSON response for AJAX
            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
                die(json_encode(['status' => 'deactivated']));
            }
            // For direct access
            session_unset();
            session_destroy();
            header("Location: login.php?error=deactivated");
            exit();
        }
    }
}
?>