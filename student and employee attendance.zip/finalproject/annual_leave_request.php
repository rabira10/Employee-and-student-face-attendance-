<?php
session_start();

if (!isset($_SESSION['user']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'employee') {
    header("Location: employee_login.html");
    exit();
}

// Set default language to English if not set
if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'en';
}

// Handle language change
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

// Language translations with combined labels
$translations = [
    'en' => [
        'title' => 'Send Annual Leave Request / ዓመታዊ ፈቃድ መጠየቂያ ላክ',
        'hello' => 'Hello / ሰላም, %s',
        'start_date' => 'Start Date / የመጀመሪያ ቀን',
        'end_date' => 'End Date / የመጨረሻ ቀን',
        'reason' => 'Reason / ምክንያት',
        'submit' => 'Submit Leave Request / የፈቃድ መጠየቂያ አስገባ',
        'back' => 'Back to Dashboard / ወደ ዳሽቦርድ ተመለስ',
        'success' => 'Success! / ተሳክቷል!',
        'error' => 'Error! / ስህተት!',
        'fill_fields' => 'Please fill in all fields. / እባክዎ ሁሉንም መስኮች ይሙሉ።',
        'date_error' => 'Start date must be before or equal to end date. / የመጀመሪያ ቀን ከመጨረሻ ቀን በፊት ወይም እኩል መሆን አለበት።',
        'submit_success' => 'Leave request submitted successfully! / የፈቃድ መጠየቂያ በተሳካ ሁኔታ ቀርቧል!',
        'submit_failed' => 'Submission failed: %s / ማስገባት አልተሳካም: %s',
        'ok' => 'OK / እሺ',
        'success_icon' => '✓',
        'error_icon' => '✗'
    ]
];

$lang = $_SESSION['lang'];
$t = $translations['en'];

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = trim($_SESSION['user']);
$message = '';
$message_type = '';

// Get full name and role from users table
$stmtUser = $conn->prepare("SELECT full_name, role FROM users WHERE username = ?");
$stmtUser->bind_param("s", $username);
$stmtUser->execute();
$stmtUser->store_result();

if ($stmtUser->num_rows === 0) {
    die("Error: Username '" . htmlspecialchars($username) . "' does NOT exist in users table.");
}

$stmtUser->bind_result($full_name, $role);
$stmtUser->fetch();
$stmtUser->close();

if ($role !== 'employee') {
    die("Access denied: Only employees can access this page.");
}

// Insert into employees table if missing
$stmtEmpCheck = $conn->prepare("SELECT 1 FROM employees WHERE username = ?");
$stmtEmpCheck->bind_param("s", $username);
$stmtEmpCheck->execute();
$stmtEmpCheck->store_result();

if ($stmtEmpCheck->num_rows === 0) {
    $stmtEmpCheck->close();
    $insertEmp = $conn->prepare("INSERT INTO employees (username, full_name) VALUES (?, ?)");
    $insertEmp->bind_param("ss", $username, $full_name);
    $insertEmp->execute();
    $insertEmp->close();
} else {
    $stmtEmpCheck->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $start_date = $_POST['start_date'] ?? '';
    $end_date = $_POST['end_date'] ?? '';
    $reason = $_POST['reason'] ?? '';

    if (!$start_date || !$end_date || !$reason) {
        $message = $t['fill_fields'];
        $message_type = 'error';
    } elseif ($start_date > $end_date) {
        $message = $t['date_error'];
        $message_type = 'error';
    } else {
        $stmt = $conn->prepare("INSERT INTO leave_requests (username, start_date, end_date, reason) VALUES (?, ?, ?, ?)");
        if (!$stmt) {
            $message = sprintf($t['submit_failed'], $conn->error);
            $message_type = 'error';
        } else {
            $stmt->bind_param("ssss", $username, $start_date, $end_date, $reason);
            if ($stmt->execute()) {
                $message = $t['submit_success'];
                $message_type = 'success';
            } else {
                $message = sprintf($t['submit_failed'], $stmt->error);
                $message_type = 'error';
            }
            $stmt->close();
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title><?php echo $t['title']; ?></title>
    <style>
        :root {
            --ddu-blue: #003366;
            --ddu-gold: #FFCC00;
            --light: #f9f9f9;
            --success-bg: #4BB543;
            --success-color: white;
            --error-bg: #FF3333;
            --error-color: white;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--light);
            margin: 0;
            padding: 0;
            animation: fadeIn 1s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        form {
            max-width: 500px;
            margin: 40px auto;
            background-color: white;
            padding: 30px;
            border: 2px solid var(--ddu-gold);
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            animation: slideIn 0.7s ease;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }

        h2 {
            text-align: center;
            color: var(--ddu-blue);
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-top: 20px;
            font-weight: bold;
            color: #555;
        }

        input[type="date"], textarea {
            width: 100%;
            padding: 12px;
            margin-top: 8px;
            border: 1px solid #ddd;
            border-radius: 6px;
            box-sizing: border-box;
            font-size: 16px;
            transition: border 0.3s;
        }

        input[type="date"]:focus, textarea:focus {
            border-color: var(--ddu-blue);
            outline: none;
            box-shadow: 0 0 0 2px rgba(0, 51, 102, 0.1);
        }

        textarea {
            resize: vertical;
            height: 120px;
            font-family: inherit;
        }

        .button-container {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        button[type="submit"] {
            flex: 1;
            background-color: var(--ddu-blue);
            color: white;
            padding: 14px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 16px;
            font-weight: 600;
        }

        button[type="submit"]:hover {
            background-color: #002244;
            transform: translateY(-2px);
        }

        .back-btn {
            flex: 1;
            background-color: white;
            color: var(--ddu-blue);
            padding: 14px 20px;
            border: 2px solid var(--ddu-blue);
            border-radius: 6px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            font-size: 16px;
        }

        .back-btn:hover {
            background-color: var(--ddu-blue);
            color: white;
            transform: translateY(-2px);
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.3s ease-out;
        }

        .modal-content {
            background-color: white;
            margin: 15% auto;
            padding: 40px 30px;
            border-radius: 10px;
            width: 90%;
            max-width: 400px;
            text-align: center;
            box-shadow: 0 5px 30px rgba(0,0,0,0.3);
            position: relative;
            animation: modalSlideIn 0.4s ease;
        }

        @keyframes modalSlideIn {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .modal-icon {
            font-size: 60px;
            margin-bottom: 20px;
            line-height: 1;
        }

        .success .modal-icon {
            color: var(--success-bg);
            animation: bounce 0.6s;
        }

        .error .modal-icon {
            color: var(--error-bg);
            animation: shake 0.5s;
        }

        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {transform: translateY(0);}
            40% {transform: translateY(-20px);}
            60% {transform: translateY(-10px);}
        }

        @keyframes shake {
            0%, 100% {transform: translateX(0);}
            10%, 30%, 50%, 70%, 90% {transform: translateX(-5px);}
            20%, 40%, 60%, 80% {transform: translateX(5px);}
        }

        .modal h3 {
            margin: 0 0 15px;
            font-size: 24px;
            color: #333;
        }

        .modal p {
            margin-bottom: 25px;
            font-size: 16px;
            line-height: 1.5;
            color: #555;
        }

        .modal-btn {
            background-color: var(--ddu-blue);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s;
        }

        .modal-btn:hover {
            background-color: #002244;
            transform: translateY(-2px);
        }

        .close {
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 24px;
            font-weight: bold;
            cursor: pointer;
            color: #aaa;
            transition: color 0.3s;
        }

        .close:hover {
            color: #333;
        }

        /* Language Switcher */
        .language-switcher {
            position: absolute;
            top: 1rem;
            right: 1rem;
            display: flex;
            background: #f0f0f0;
            border-radius: 30px;
            padding: 3px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            z-index: 10;
        }

        .language-btn {
            background: transparent;
            color: #666;
            border: none;
            padding: 0.5rem 1.2rem;
            border-radius: 25px;
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 600;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.3rem;
        }

        .language-btn:hover {
            color: var(--ddu-blue);
        }

        .language-btn.active {
            background: var(--ddu-blue);
            color: white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }

        .language-btn.active:hover {
            background: #1a4d6b;
        }

        .language-icon {
            font-size: 1rem;
        }
    </style>
</head>
<body>
    <!-- Language Switcher -->
    <div class="language-switcher">
        <a href="?lang=en" class="language-btn <?php echo $lang === 'en' ? 'active' : ''; ?>">
            <span class="language-icon">🌐</span>
            English
        </a>
        <a href="?lang=am" class="language-btn <?php echo $lang === 'am' ? 'active' : ''; ?>">
            <span class="language-icon">🇪🇹</span>
            አማርኛ
        </a>
    </div>

    <form method="POST" action="">
        <h2><?php echo $t['title']; ?></h2>
        <p><?php echo sprintf($t['hello'], htmlspecialchars($full_name)); ?></p>

        <label><?php echo $t['start_date']; ?>:
            <input type="date" name="start_date" required />
        </label>

        <label><?php echo $t['end_date']; ?>:
            <input type="date" name="end_date" required />
        </label>

        <label><?php echo $t['reason']; ?>:
            <textarea name="reason" required></textarea>
        </label>

        <div class="button-container">
            <button type="submit"><?php echo $t['submit']; ?></button>
            <a href="dashboard_employee.php" class="back-btn"><?php echo $t['back']; ?></a>
        </div>
    </form>

    <?php if ($message): ?>
    <div id="messageModal" class="modal" style="display: block;">
        <div class="modal-content <?php echo $message_type; ?>">
            <span class="close" onclick="document.getElementById('messageModal').style.display='none'">&times;</span>
            <div class="modal-icon"><?php echo $t[$message_type.'_icon']; ?></div>
            <h3><?php echo $t[$message_type]; ?></h3>
            <p><?php echo htmlspecialchars($message); ?></p>
            <button class="modal-btn" onclick="document.getElementById('messageModal').style.display='none'"><?php echo $t['ok']; ?></button>
        </div>
    </div>
    <script>
        // Auto-close modal after 5 seconds
        setTimeout(function() {
            var modal = document.getElementById('messageModal');
            if (modal) modal.style.display = 'none';
        }, 5000);
    </script>
    <?php endif; ?>
</body>
</html>