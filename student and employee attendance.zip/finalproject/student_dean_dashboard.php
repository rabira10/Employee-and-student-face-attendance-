<?php
session_start();

// Language support
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

$default_lang = 'en'; // Default language
$current_lang = $_SESSION['lang'] ?? $default_lang;

// Load translations
$translations = [];
$lang_file = "languages/{$current_lang}.php";
if (file_exists($lang_file)) {
    $translations = require $lang_file;
}

// Helper function for translations
function t($key, $translations) {
    return $translations[$key] ?? $key;
}

// Check authentication and role
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student_dean') {
    header("Location: login.php");
    exit();
}

// Database configuration
$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$msg = '';
$msgType = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $start = $_POST['start_time'];
    $end = $_POST['end_time'];

    // Validate time window
    if ($start >= $end) {
        $msg = t("end_time_must_be_after_start_time", $translations);
        $msgType = 'error';
    } else {
        // Check if the role column exists in attendance_settings table
        $roleColumnExists = false;
        $checkColumns = $conn->query("SHOW COLUMNS FROM attendance_settings LIKE 'role'");
        if ($checkColumns && $checkColumns->num_rows > 0) {
            $roleColumnExists = true;
        }

        // Query based on whether role column exists
        if ($roleColumnExists) {
            $check = $conn->query("SELECT * FROM attendance_settings WHERE role = 'student'");
        } else {
            $check = $conn->query("SELECT * FROM attendance_settings LIMIT 1");
        }
        
        if ($check && $check->num_rows > 0) {
            // Update existing record
            if ($roleColumnExists) {
                $stmt = $conn->prepare("UPDATE attendance_settings SET start_time = ?, end_time = ? WHERE role = 'student'");
            } else {
                $stmt = $conn->prepare("UPDATE attendance_settings SET start_time = ?, end_time = ?");
            }
            $stmt->bind_param("ss", $start, $end);
        } else {
            // Insert new record
            if ($roleColumnExists) {
                $stmt = $conn->prepare("INSERT INTO attendance_settings (role, start_time, end_time) VALUES ('student', ?, ?)");
                $stmt->bind_param("ss", $start, $end);
            } else {
                $stmt = $conn->prepare("INSERT INTO attendance_settings (start_time, end_time) VALUES (?, ?)");
                $stmt->bind_param("ss", $start, $end);
            }
        }

        if ($stmt->execute()) {
            $msg = t("attendance_time_window_set_successfully", $translations);
            $msgType = 'success';
        } else {
            $msg = t("error", $translations) . ": " . $conn->error;
            $msgType = 'error';
        }
    }
}

// Fetch current settings
$currentSettings = null;
$roleColumnExists = false;
$checkColumns = $conn->query("SHOW COLUMNS FROM attendance_settings LIKE 'role'");
if ($checkColumns && $checkColumns->num_rows > 0) {
    $roleColumnExists = true;
}

if ($roleColumnExists) {
    $settingsQuery = $conn->query("SELECT * FROM attendance_settings WHERE role = 'student' LIMIT 1");
} else {
    $settingsQuery = $conn->query("SELECT * FROM attendance_settings LIMIT 1");
}

if ($settingsQuery && $settingsQuery->num_rows > 0) {
    $currentSettings = $settingsQuery->fetch_assoc();
}

// Fetch dashboard statistics
$presentQuery = $conn->query("SELECT COUNT(*) as count FROM student_attendance WHERE attendance_date = CURDATE() AND status = 'present'");
$presentCount = $presentQuery->fetch_assoc()['count'];

$absentQuery = $conn->query("SELECT COUNT(*) as count FROM student_attendance WHERE attendance_date = CURDATE() AND status = 'absent'");
$absentCount = $absentQuery->fetch_assoc()['count'];

$totalQuery = $conn->query("SELECT COUNT(*) as count FROM students");
$totalCount = $totalQuery->fetch_assoc()['count'];


?>


<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo t('student_dean_dashboard', $translations); ?> - Dire Dawa University</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #003366 0%, #1a4d6b 100%);
            min-height: 100vh;
            color: #333;
            line-height: 1.6;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideIn {
            from { transform: translateX(-30px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes scaleIn {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        /* Header */
        .header {
            background: white;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border-bottom: 4px solid #FFCC00;
            padding: 1.5rem 0;
            animation: slideIn 0.6s ease-out;
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .logo {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #003366, #004080);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
            box-shadow: 0 4px 15px rgba(0,51,102,0.3);
        }

        .university-info h1 {
            color: #003366;
            font-size: 1.8rem;
            margin-bottom: 0.2rem;
            font-weight: 700;
        }

        .university-info p {
            color: #666;
            font-size: 1rem;
            font-weight: 500;
        }

        .dean-section {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .dean-badge {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
            padding: 0.8rem 1.5rem;
            border-radius: 25px;
            font-weight: bold;
            font-size: 1rem;
            box-shadow: 0 4px 15px rgba(255,204,0,0.3);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .language-switcher {
            display: flex;
            gap: 0.5rem;
            margin-left: 1rem;
        }

        .language-switcher a {
            padding: 0.5rem;
            border-radius: 4px;
            text-decoration: none;
            color: var(--primary-color);
            font-weight: 500;
            font-size: 0.9rem;
            transition: var(--transition);
            color: #003366;
        }

        .language-switcher a:hover {
            background: rgba(255, 204, 0, 0.2);
        }

        .language-switcher a.active {
            background: #FFCC00;
            color: #003366;
            font-weight: 600;
        }

        /* Header Navigation */
        .header-nav {
            display: flex;
            gap: 1.5rem;
            margin-left: 2rem;
        }

        .header-nav-item {
            position: relative;
        }

        .header-nav-link {
            padding: 0.75rem 1rem;
            border-radius: 8px;
            text-decoration: none;
            color: #003366;
            font-weight: 600;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .header-nav-link:hover {
            background: rgba(255, 204, 0, 0.2);
            transform: translateY(-2px);
        }

        .header-nav-link.active {
            background: #FFCC00;
            color: #003366;
            box-shadow: 0 2px 10px rgba(255, 204, 0, 0.3);
        }

        .header-dropdown {
            position: absolute;
            top: 100%;
            left: 0;
            background: white;
            border-radius: 8px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            padding: 1rem;
            min-width: 250px;
            z-index: 100;
            display: none;
            animation: fadeIn 0.3s ease-out;
        }

        .header-nav-item:hover .header-dropdown {
            display: block;
        }

        .header-dropdown-link {
            display: block;
            padding: 0.75rem 1rem;
            text-decoration: none;
            color: #003366;
            border-radius: 6px;
            transition: all 0.2s ease;
            margin-bottom: 0.5rem;
        }

        .header-dropdown-link:hover {
            background: rgba(255, 204, 0, 0.2);
            transform: translateX(5px);
        }

        .header-dropdown-link.logout {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }

        .header-dropdown-link.logout:hover {
            background: rgba(220, 53, 69, 0.2);
        }

        /* Main Container */
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
            animation: fadeIn 0.8s ease-out;
        }

        .welcome-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            text-align: center;
        }

        .welcome-section h2 {
            color: #003366;
            font-size: 2rem;
            margin-bottom: 0.5rem;
            font-weight: 700;
        }

        .welcome-section p {
            color: #666;
            font-size: 1.1rem;
        }

        /* Dashboard Grid */
        .dashboard-grid {
    width: 100%;
    display: block;
    margin-bottom: 2rem;
}


        .dashboard-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            animation: scaleIn 0.7s ease-out;
        }

        .card-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .card-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: #003366;
        }

        .card-title {
            color: #003366;
            font-size: 1.5rem;
            font-weight: 700;
        }

        /* Stats Cards */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1rem;
            margin-top: 1rem;
        }

        .stat-card {
            padding: 1.5rem;
            border-radius: 12px;
            text-align: center;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }

        .stat-card.present {
            background: rgba(40, 167, 69, 0.1);
            border: 1px solid rgba(40, 167, 69, 0.2);
        }

        .stat-card.absent {
            background: rgba(220, 53, 69, 0.1);
            border: 1px solid rgba(220, 53, 69, 0.2);
        }

        .stat-card.total {
            background: rgba(0, 123, 255, 0.1);
            border: 1px solid rgba(0, 123, 255, 0.2);
        }

        .stat-title {
            color: #555;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }

        .present .stat-value {
            color: #28a745;
        }

        .absent .stat-value {
            color: #dc3545;
        }

        .total .stat-value {
            color: #007bff;
        }

        .modern-block {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 20px;
    padding: 2rem;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
    animation: scaleIn 0.5s ease-out;
}

.modern-card-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 1.5rem;
    margin-top: 1rem;
}

.modern-card {
    text-align: center;
    background: white;
    border-radius: 15px;
    padding: 1.5rem 1rem;
    text-decoration: none;
    color: #003366;
    font-weight: 600;
    box-shadow: 0 6px 15px rgba(0, 51, 102, 0.08);
    transition: all 0.3s ease;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.modern-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 12px 24px rgba(0, 51, 102, 0.15);
    background: #f5f9ff;
}

.modern-icon {
    font-size: 2.3rem;
    margin-bottom: 0.6rem;
}

.modern-label {
    font-size: 1rem;
}

.logout-modern {
    background: #dc3545;
    color: white;
}

.logout-modern:hover {
    background: #c82333;
}


        /* Form Styling */
        .form-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #003366;
            font-size: 1rem;
        }

        input[type="time"] {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: white;
        }

        input[type="time"]:focus {
            outline: none;
            border-color: #FFCC00;
            box-shadow: 0 0 0 3px rgba(255, 204, 0, 0.1);
            transform: translateY(-1px);
        }

        .btn {
            background: linear-gradient(135deg, #003366, #004080);
            color: white;
            border: none;
            padding: 0.8rem 2rem;
            border-radius: 8px;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,51,102,0.3);
        }

        .btn:hover {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(255,204,0,0.4);
        }

        /* Messages */
        .message {
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin: 1rem 0;
            font-weight: 500;
            animation: fadeIn 0.5s ease-out;
        }

        .message.success {
            background: linear-gradient(135deg, #d4edda, #c3e6cb);
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.error {
            background: linear-gradient(135deg, #f8d7da, #f5c6cb);
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Current Settings Display */
        .current-settings {
            background: rgba(255, 204, 0, 0.1);
            border: 1px solid #FFCC00;
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1.5rem;
        }

        .current-settings h4 {
            color: #003366;
            margin-bottom: 0.5rem;
        }

        .time-display {
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .time-badge {
            background: #003366;
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        /* Footer Styles */
        footer {
            background: #003366;
            color: white;
            padding: 2rem 0;
            margin-top: 3rem;
        }

        .footer-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
        }

        .footer-content {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 2rem;
        }

        .footer-section {
            flex: 1;
            min-width: 250px;
        }

        .footer-section h3 {
            color: #FFCC00;
            margin-bottom: 1rem;
            font-size: 1.2rem;
        }

        .footer-section p, .footer-section address {
            line-height: 1.6;
        }

        .footer-section address {
            font-style: normal;
        }

        .footer-section ul {
            list-style: none;
            line-height: 2;
        }

        .footer-section a {
            color: white;
            text-decoration: none;
        }

        .footer-section a:hover {
            text-decoration: underline;
            color: #FFCC00;
        }

        .footer-bottom {
            border-top: 1px solid rgba(255, 204, 0, 0.3);
            margin-top: 2rem;
            padding-top: 1.5rem;
            text-align: center;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .header-content {
                flex-wrap: wrap;
                gap: 1rem;
            }

            .header-nav {
                order: 3;
                width: 100%;
                justify-content: center;
                margin-left: 0;
                margin-top: 1rem;
            }

            .language-switcher {
                margin-left: auto;
            }
        }

        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                text-align: center;
            }

            .logo-section {
                flex-direction: column;
                gap: 1rem;
            }

            .dean-section {
                flex-direction: column;
                gap: 1rem;
            }

            .language-switcher {
                margin-left: 0;
                margin-top: 0.5rem;
                justify-content: center;
                width: 100%;
            }

            .header-nav {
                flex-direction: column;
                align-items: center;
                gap: 0.5rem;
            }

            .header-nav-item {
                width: 100%;
                text-align: center;
            }

            .header-dropdown {
                position: static;
                box-shadow: none;
                display: none;
                width: 100%;
            }

            .header-nav-item:hover .header-dropdown {
                display: block;
            }

            .dashboard-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }

            .stats-container {
                grid-template-columns: 1fr;
            }

            .container {
                padding: 1rem;
            }

            .dashboard-card {
                padding: 1.5rem;
            }

            .university-info h1 {
                font-size: 1.5rem;
            }

            .time-display {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.5rem;
            }

            .footer-content {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-content">
            <div class="logo-section">
                <div class="logo">DDU</div>
                <div class="university-info">
                    <h1><?php echo t('dire_dawa_university', $translations); ?></h1>
                    <p><?php echo t('student_dean_portal', $translations); ?></p>
                </div>
            </div>

            <nav class="header-nav">
                <div class="header-nav-item">
                    <a href="#" class="header-nav-link">
                        🎓 <?php echo t('student_management', $translations); ?>
                    </a>
                    <div class="header-dropdown">
                        <a href="view_students.php" class="header-dropdown-link">
                            👥 <?php echo t('view_all_students', $translations); ?>
                        </a>
                        <a href="view_attendanced.php" class="header-dropdown-link">
                            📊 <?php echo t('attendance_reports', $translations); ?>
                        </a>
                        
                        <a href="send_notifications.php" class="header-dropdown-link">
                            📢 <?php echo t('send_notifications', $translations); ?>
                        </a>
                        <a href="manage_students.php" class="header-dropdown-link">
                            ⚙️ <?php echo t('manage_accounts', $translations); ?>
                        </a>
                        <a href="register_student.php" class="header-dropdown-link">
                            ➕ <?php echo t('register_student', $translations); ?>
                        </a>
                    </div>
                </div>

                <div class="header-nav-item">
                    <a href="#" class="header-nav-link">
                        ⚡ <?php echo t('quick_actions', $translations); ?>
                    </a>
                    <div class="header-dropdown">
                        <a href="changeD_password.php" class="header-dropdown-link">
                            🔒 <?php echo t('change_password', $translations); ?>
                        </a>
                        <a href="login.php" class="header-dropdown-link logout">
                            🚪 <?php echo t('logout', $translations); ?>
                        </a>
                        <a href="time.php" class="header-dropdown-link">
                            🕒 <?php echo t('attendance_time_Settings', $translations); ?>
                        </a>
                    </div>
                </div>
            </nav>

            <div class="dean-section">
                <div class="language-switcher">
                    <a href="?lang=en" class="<?php echo $current_lang === 'en' ? 'active' : ''; ?>">English</a>
                    <a href="?lang=am" class="<?php echo $current_lang === 'am' ? 'active' : ''; ?>">አማርኛ</a>
                </div>
                <div class="dean-badge">
                    <i class="fas fa-user-graduate"></i>
                    <?php echo t('student_dean', $translations); ?>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <!-- Welcome Section -->
        <div class="welcome-section">
    <h2>🎓 Welcome, Student Dean!</h2>
    <p>
        Welcome to the <strong>Student Dean Dashboard</strong> of <strong>Dire Dawa University</strong>. 
        Here, you can manage student attendance, review performance, and foster a supportive academic environment. 
        Thank you for your leadership and dedication to our students’ success.
    </p>
</div>

        </div>

        <!-- Dashboard Stats -->
        <div class="dashboard-grid">
            <div class="dashboard-card">
                <div class="card-header">
                    <div class="card-icon">📊</div>
                    <h3 class="card-title"><?php echo t('attendance_stats', $translations); ?></h3>
                </div>
                
                <div class="stats-container">
                    <!-- Present Today Card -->
                    <div class="stat-card present">
                        <div class="stat-title"><?php echo t('present_today', $translations); ?></div>
                        <div class="stat-value"><?php echo $presentCount; ?></div>
                        <div class="stat-desc">Students</div>
                    </div>
                    
                    <!-- Absent Today Card -->
                    <div class="stat-card absent">
                        <div class="stat-title"><?php echo t('absent_today', $translations); ?></div>
                        <div class="stat-value"><?php echo $absentCount; ?></div>
                        <div class="stat-desc">Students</div>
                    </div>
                    
                    <!-- Total Students Card -->
                    <div class="stat-card total">
                        <div class="stat-title"><?php echo t('total_students', $translations); ?></div>
                        <div class="stat-value"><?php echo $totalCount; ?></div>
                        <div class="stat-desc">Registered</div>
                    </div>
                </div>
            </div>
         <!-- 🎓 Student Management Section -->
<div class="dashboard-card modern-block" style="margin-top: 2rem;">
    <div class="card-header">
        <div class="card-icon">🎓</div>
        <h3 class="card-title"><?php echo t('student_management', $translations); ?></h3>
    </div>
    <div class="modern-card-grid">
        <a href="view_students.php" class="modern-card">
            <div class="modern-icon">👥</div>
            <div class="modern-label"><?php echo t('view_all_students', $translations); ?></div>
        </a>
        <a href="view_attendanced.php" class="modern-card">
            <div class="modern-icon">📊</div>
            <div class="modern-label"><?php echo t('attendance_reports', $translations); ?></div>
        </a>
       
        <a href="send_notifications.php" class="modern-card">
            <div class="modern-icon">📢</div>
            <div class="modern-label"><?php echo t('send_notifications', $translations); ?></div>
        </a>
        <a href="manage_students.php" class="modern-card">
            <div class="modern-icon">⚙️</div>
            <div class="modern-label"><?php echo t('manage_accounts', $translations); ?></div>
        </a>
        <a href="register_student.php" class="modern-card">
            <div class="modern-icon">➕</div>
            <div class="modern-label"><?php echo t('register_student', $translations); ?></div>
        </a>
    </div>
</div>

<!-- ⚡ Quick Actions Section -->
<div class="dashboard-card modern-block" style="margin-top: 2rem;">
    <div class="card-header">
        <div class="card-icon">⚡</div>
        <h3 class="card-title"><?php echo t('quick_actions', $translations); ?></h3>
    </div>
    <div class="modern-card-grid">
        <a href="changeD_password.php" class="modern-card">
            <div class="modern-icon">🔒</div>
            <div class="modern-label"><?php echo t('change_password', $translations); ?></div>
        </a>
        <a href="time.php" class="modern-card">
            <div class="modern-icon">🕒</div>
            <div class="modern-label"><?php echo t('attendance_time_Settings', $translations); ?></div>
        </a>
        <a href="login.php" class="modern-card logout-modern">
            <div class="modern-icon">🚪</div>
            <div class="modern-label"><?php echo t('logout', $translations); ?></div>
        </a>
    </div>
</div>



                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3><?php echo t('dire_dawa_university', $translations); ?></h3>
                    <p><?php echo t('footer_about_text', $translations); ?></p>
                </div>
                <div class="footer-section">
                    <h3><?php echo t('quick_links', $translations); ?></h3>
                    <ul>
                        <li><a href="https://www.ddu.edu.et"><?php echo t('university_website', $translations); ?></a></li>
                        <li><a href="contact.php"><?php echo t('contact_us', $translations); ?></a></li>
                        <li><a href="help.php"><?php echo t('help_center', $translations); ?></a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3><?php echo t('contact_info', $translations); ?></h3>
                    <address>
                        <p><i class="fas fa-map-marker-alt"></i> <?php echo t('university_address', $translations); ?></p>
                        <p><i class="fas fa-phone"></i> +251 25 111 2233</p>
                        <p><i class="fas fa-envelope"></i> studentdean@ddu.edu.et</p>
                    </address>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php echo t('dire_dawa_university', $translations); ?>. <?php echo t('all_rights_reserved', $translations); ?></p>
            </div>
        </div>
    </footer>

    <!-- Font Awesome for icons -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

    <script>
        // Auto-hide success messages after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const successMessages = document.querySelectorAll('.message.success');
            successMessages.forEach(function(message) {
                setTimeout(function() {
                    message.style.opacity = '0';
                    message.style.transform = 'translateY(-20px)';
                    setTimeout(function() {
                        message.style.display = 'none';
                    }, 300);
                }, 5000);
            });
        });

        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const startTime = document.getElementById('start_time').value;
            const endTime = document.getElementById('end_time').value;
            
            if (startTime && endTime && startTime >= endTime) {
                e.preventDefault();
                alert('<?php echo t("end_time_must_be_after_start_time", $translations); ?>');
            }
        });

        // Mobile menu toggle for dropdowns
        document.querySelectorAll('.header-nav-link').forEach(link => {
            link.addEventListener('click', function(e) {
                if (window.innerWidth <= 768) {
                    e.preventDefault();
                    const dropdown = this.nextElementSibling;
                    if (dropdown.style.display === 'block') {
                        dropdown.style.display = 'none';
                    } else {
                        dropdown.style.display = 'block';
                    }
                }
            });
        });
    </script>
</body>
</html>