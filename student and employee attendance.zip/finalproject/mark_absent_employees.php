<?php
file_put_contents('C:/xamp/htdocs/finalproject/log.txt', "Script started at " . date('Y-m-d H:i:s') . PHP_EOL, FILE_APPEND);

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

date_default_timezone_set('Africa/Addis_Ababa');

$today = date('Y-m-d');

// Define AM and PM end times (adjust as needed)
$now = time();
$am_end = strtotime($today . " 09:00:00");  // example: AM session ends at 9:00 AM
$pm_end = strtotime($today . " 17:00:00");  // PM session ends at 5:00 PM

if ($now < $am_end) {
    echo "Too early to mark AM absences.\n";
    file_put_contents('C:/xamp/htdocs/finalproject/log.txt', "Too early to mark AM absences at " . date('Y-m-d H:i:s') . PHP_EOL, FILE_APPEND);
    exit;
}

$session = ($now < $pm_end) ? 'AM' : 'PM';

// Check if absences already marked for this session
$checkSql = "SELECT COUNT(*) as cnt FROM attendance WHERE date = ? AND session = ? AND status = 'absent'";
$stmtCheck = $conn->prepare($checkSql);
$stmtCheck->bind_param("ss", $today, $session);
$stmtCheck->execute();
$result = $stmtCheck->get_result()->fetch_assoc();

if ($result['cnt'] > 0) {
    echo "Employee absences for session $session already marked.\n";
    file_put_contents('C:/xamp/htdocs/finalproject/log.txt', "Already marked for $session at " . date('Y-m-d H:i:s') . PHP_EOL, FILE_APPEND);
    exit;
}

// Get employees who have NOT signed attendance for this session
$sql = "
    SELECT e.username, e.full_name
    FROM employees e
    LEFT JOIN attendance a 
        ON e.username = a.username AND a.date = ? AND a.session = ?
    WHERE a.username IS NULL
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $today, $session);
$stmt->execute();
$result = $stmt->get_result();

$absent_employees = [];
while ($row = $result->fetch_assoc()) {
    $absent_employees[] = $row;
}

if (count($absent_employees) > 0) {
    $stmtInsert = $conn->prepare("
        INSERT INTO attendance (username, full_name, date, session, time_slot, status, method)
        VALUES (?, ?, ?, ?, ?, 'absent', 'Manual')
    ");
    foreach ($absent_employees as $user) {
        $stmtInsert->bind_param("sssss", $user['username'], $user['full_name'], $today, $session, $session);
        $stmtInsert->execute();
    }
    echo count($absent_employees) . " employees marked absent for $session session.\n";
    file_put_contents('C:/xamp/htdocs/finalproject/log.txt', count($absent_employees) . " employees marked absent for $session session.\n", FILE_APPEND);
} else {
    echo "No absent employees found for $session session.\n";
    file_put_contents('C:/xamp/htdocs/finalproject/log.txt', "No absentees for $session at " . date('Y-m-d H:i:s') . PHP_EOL, FILE_APPEND);
}

$conn->close();
file_put_contents('C:/xamp/htdocs/finalproject/log.txt', "Script ended at " . date('Y-m-d H:i:s') . PHP_EOL, FILE_APPEND);
?>
