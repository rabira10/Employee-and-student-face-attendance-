<?php
include 'dbe.php'; // Make sure $conn is defined in this file

$successMessage = '';
$errorMessage = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $full_name = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password_raw = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';

    if ($full_name && $username && $password_raw && $role) {
        $password = password_hash($password_raw, PASSWORD_DEFAULT);

        // Check if username already exists
        $check = $conn->prepare("SELECT id FROM users WHERE username = ?");
        if ($check) {
            $check->bind_param("s", $username);
            $check->execute();
            $check->store_result();

            if ($check->num_rows > 0) {
                $errorMessage = "Username already exists!";
            } else {
                $stmt = $conn->prepare("INSERT INTO users (full_name, username, password, role) VALUES (?, ?, ?, ?)");
                if ($stmt) {
                    $stmt->bind_param("ssss", $full_name, $username, $password, $role);
                    if ($stmt->execute()) {
                        $successMessage = "User added successfully!";
                    } else {
                        $errorMessage = "Error inserting user!";
                    }
                    $stmt->close();
                } else {
                    $errorMessage = "Failed to prepare insert statement.";
                }
            }
            $check->close();
        } else {
            $errorMessage = "Failed to prepare username check.";
        }
    } else {
        $errorMessage = "All fields are required.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New User</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 500px;
            margin: 0 auto;
            position: relative;
            padding-top: 60px;
        }
        .header-wrapper {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 25px;
        }
        .back-btn {
            position: absolute;
            right: 0;
            top: 50%;
            transform: translateY(-50%);
            text-decoration: none;
            color: #006400;
            font-weight: bold;
            border: 2px solid #006400;
            padding: 8px 16px;
            border-radius: 4px;
            background-color: #ffffff;
            cursor: pointer;
            z-index: 10;
        }
        .back-btn:hover {
            background-color: #e6ffe6;
            color: #004d00;
        }
        form {
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        label {
            display: inline-block;
            width: 100px;
            margin-bottom: 10px;
            color: #006400;
            font-weight: bold;
        }
        input, select {
            width: calc(100% - 120px);
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            background-color: #FFD700;
            color: #006400;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s;
            width: 100%;
        }
        button:hover {
            background-color: #e6c200;
        }
        .success {
            color: #006400;
            background-color: #dff0d8;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .error {
            color: #a94442;
            background-color: #f2dede;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        h1 {
            color: #006400;
            margin: 0;
            font-size: 1.8rem;
            user-select: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header-wrapper">
            <h1>Add New User</h1>
            <a href="javascript:history.back()" class="back-btn">← Back</a>
        </div>

        <?php if ($successMessage): ?>
            <div class="success"><?= htmlspecialchars($successMessage) ?></div>
        <?php elseif ($errorMessage): ?>
            <div class="error"><?= htmlspecialchars($errorMessage) ?></div>
        <?php endif; ?>

        <form method="POST" novalidate>
            <label for="full_name">Full Name:</label>
            <input id="full_name" name="full_name" required><br>

            <label for="username">Username:</label>
            <input id="username" name="username" required><br>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br>

            <label for="role">Role:</label>
            <select id="role" name="role" required>
                <option value="">Select Role</option>
                <option value="admin">Admin</option>
                <option value="hr">HR</option>
                <option value="employee">Employee</option>
                <option value="student">Student</option>
                <option value="student_dean">Student Dean</option>
            </select><br>

            <button type="submit">Add User</button>
        </form>
    </div>
</body>
</html>
