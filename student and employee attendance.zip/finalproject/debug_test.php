<?php
// SUPER DEBUGGING - Remove this after fixing
echo "<pre>";
echo "=== DEBUG START ===\n";

// 1. Test PHP is processing
echo "1. PHP is working\n";

// 2. Test session
session_start();
echo "2. Session started\n";
echo "   Session ID: " . session_id() . "\n";

// 3. Test database connection
$conn = null;
try {
    $conn = new PDO("mysql:host=localhost;dbname=ddu_attendance", "root", "");
    echo "3. Database connected\n";
    
    // 4. Test query
    $stmt = $conn->query("SELECT COUNT(*) FROM leave_requests WHERE status='pending'");
    $count = $stmt->fetchColumn();
    echo "4. Found $count pending requests\n";
    
    // 5. Test session role
    $_SESSION['user_id'] = 'TEST_HR'; // Simulate HR login
    $_SESSION['account_type'] = 'hr';
    echo "5. Set test HR session\n";
    
} catch(PDOException $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

echo "=== DEBUG END ===\n";
echo "</pre>";
?>