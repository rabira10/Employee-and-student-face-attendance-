<?php
date_default_timezone_set('Africa/Addis_Ababa');
session_start();

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'employee') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'DB connection error']);
    exit();
}

$username = $_SESSION['user'];
$today = date("Y-m-d");
$timeNow = date("H:i:s");

// Get user details from employees table
$stmt = $conn->prepare("SELECT id, full_name, username FROM employees WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'User not found']);
    exit();
}

$user = $result->fetch_assoc();
$stmt->close();

// Check if already signed today
$check = $conn->prepare("SELECT id FROM attendance WHERE user_id = ? AND date = ?");
$check->bind_param("is", $user['id'], $today);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Already signed today']);
    exit();
}

// Insert attendance record with all required fields
$insert = $conn->prepare("
    INSERT INTO attendance (user_id, full_name, username, date, status, time) 
    VALUES (?, ?, ?, ?, 'present', ?)
");
$insert->bind_param("issss", $user['id'], $user['full_name'], $user['username'], $today, $timeNow);

if ($insert->execute()) {
    echo json_encode(['success' => true, 'message' => 'Attendance recorded']);
} else {
    echo json_encode(['success' => false, 'message' => 'Insert failed']);
}
?>
