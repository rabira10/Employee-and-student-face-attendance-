<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'employee') {
    header("Location: employee_login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Change Password</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 500px; margin: 40px auto; }
        label { display: block; margin-top: 15px; }
        input { width: 100%; padding: 8px; margin-top: 5px; }
        button { margin-top: 20px; padding: 10px 15px; background-color: #003366; color: #FFCC00; border: none; cursor: pointer; border-radius: 5px; }
        button:hover { background-color: #FFCC00; color: #003366; }
        .back-link { margin-top: 20px; display: block; }
    </style>
</head>
<body>
    <?php if (!empty($_SESSION['change_pass_error'])): ?>
    <div style="color: red; font-weight: bold; margin-bottom: 15px;">
        <?php 
            echo htmlspecialchars($_SESSION['change_pass_error']); 
            unset($_SESSION['change_pass_error']); 
        ?>
    </div>
<?php endif; ?>

<?php if (!empty($_SESSION['change_pass_success'])): ?>
    <div style="color: green; font-weight: bold; margin-bottom: 15px;">
        <?php 
            echo htmlspecialchars($_SESSION['change_pass_success']); 
            unset($_SESSION['change_pass_success']); 
        ?>
    </div>
<?php endif; ?>

    <h2>Change Password</h2>
    <form method="POST" action="change_password.php">
        <label>Old Password:
            <input type="password" name="old_password" required />
        </label>

        <label>New Password:
            <input type="password" name="new_password" required />
        </label>

        <label>Confirm New Password:
            <input type="password" name="confirm_password" required />
        </label>

        <button type="submit">Change Password</button>
    </form>

    <a class="back-link" href="dashboard_employee.php">← Back to Dashboard</a>
</body>
</html>
