<?php
session_start();
include 'dbe.php';

// Check if user is admin
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username']) && isset($_POST['action'])) {
    $username = $_POST['username'];
    $action = $_POST['action'];
    
    // Prevent admin from deactivating themselves
    if ($username === $_SESSION['user'] && $action === 'deactivate') {
        $_SESSION['error'] = "You cannot deactivate your own account!";
        header("Location: admin_dashboard.php");
        exit;
    }
    
    // Determine new status
    $new_status = ($action === 'activate') ? 1 : 0;
    $action_text = ($action === 'activate') ? 'activated' : 'deactivated';
    
    try {
        // Update user status
        $stmt = $conn->prepare("UPDATE users SET is_active = ? WHERE username = ?");
        $stmt->bind_param("is", $new_status, $username);
        
        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                $_SESSION['success'] = "User '{$username}' has been successfully {$action_text}.";
            } else {
                $_SESSION['error'] = "User '{$username}' not found.";
            }
        } else {
            $_SESSION['error'] = "Failed to {$action} user '{$username}'.";
        }
        
        $stmt->close();
    } catch (Exception $e) {
        $_SESSION['error'] = "Database error: " . $e->getMessage();
    }
} else {
    $_SESSION['error'] = "Invalid request parameters.";
}

header("Location: admin_dashboard.php");
exit;
?>
