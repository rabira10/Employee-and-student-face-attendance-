<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student_dean') {
    header("Location: login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");

// Fetch filter values from GET
$student_id = $_GET['student_id'] ?? '';
$department = $_GET['department'] ?? '';
$year = $_GET['year'] ?? '';
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$export_type = $_GET['export_type'] ?? '';

// Build WHERE clauses and bind params dynamically (same as previous)
$whereClauses = [];
$params = [];
$types = '';

if ($student_id !== '') {
    $whereClauses[] = 'attendance.student_id = ?';
    $params[] = $student_id;
    $types .= 's';
}
if ($department !== '') {
    $whereClauses[] = 'students.department = ?';
    $params[] = $department;
    $types .= 's';
}
if ($year !== '') {
    $whereClauses[] = 'students.year = ?';
    $params[] = $year;
    $types .= 's';
}
if ($start_date !== '') {
    $whereClauses[] = 'attendance.date >= ?';
    $params[] = $start_date;
    $types .= 's';
}
if ($end_date !== '') {
    $whereClauses[] = 'attendance.date <= ?';
    $params[] = $end_date;
    $types .= 's';
}

$whereSQL = '';
if (count($whereClauses) > 0) {
    $whereSQL = 'WHERE ' . implode(' AND ', $whereClauses);
}

$sql = "SELECT attendance.date, attendance.status, students.id, students.full_name, students.department, students.year 
        FROM attendance 
        JOIN students ON attendance.id = students.id 
        $whereSQL 
        ORDER BY attendance.date DESC";

$stmt = $conn->prepare($sql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

if (!$export_type) {
    // Show export form with filters if no export type selected
    $deptResult = $conn->query("SELECT DISTINCT department FROM students ORDER BY department");
    $yearResult = $conn->query("SELECT DISTINCT year FROM students ORDER BY year");
    ?>

    <!DOCTYPE html>
    <html>
    <head>
        <title>Download Attendance Reports - Student Dean</title>
        <style>
            body { font-family: Arial; background-color: #eef2f7; padding: 20px; }
            form { background: #fff; padding: 15px; border-radius: 8px; }
            label { margin-right: 10px; }
            input, select { margin-right: 20px; padding: 5px; }
        </style>
    </head>
    <body>
        <h2>Download Attendance Reports</h2>
        <form method="GET" action="download_attendance.php">
            <label>Student ID: 
                <input type="text" name="student_id" value="<?= htmlspecialchars($student_id) ?>">
            </label>
            <label>Department: 
                <select name="department">
                    <option value="">--All--</option>
                    <?php while($row = $deptResult->fetch_assoc()): ?>
                        <option value="<?= htmlspecialchars($row['department']) ?>" <?= $row['department'] === $department ? 'selected' : '' ?>>
                            <?= htmlspecialchars($row['department']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </label>
            <label>Year: 
                <select name="year">
                    <option value="">--All--</option>
                    <?php while($row = $yearResult->fetch_assoc()): ?>
                        <option value="<?= htmlspecialchars($row['year']) ?>" <?= $row['year'] === $year ? 'selected' : '' ?>>
                            <?= htmlspecialchars($row['year']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </label>
            <label>From: <input type="date" name="start_date" value="<?= htmlspecialchars($start_date) ?>"></label>
            <label>To: <input type="date" name="end_date" value="<?= htmlspecialchars($end_date) ?>"></label>
            <br><br>
            <label>Export as: 
                <select name="export_type" required>
                    <option value="">--Select--</option>
                    <option value="csv">Excel (CSV)</option>
                    <option value="word">Word Document</option>
                </select>
            </label>
            <br><br>
            <button type="submit">Download</button>
        </form>
    </body>
    </html>

<?php
    exit();
}

// Process export data for CSV or Word

// Prepare data array
$data = [];
while($row = $result->fetch_assoc()) {
    $data[] = [
        'Date' => $row['date'],
        'Student ID' => $row['student_id'],
        'Full Name' => $row['full_name'],
        'Department' => $row['department'],
        'Year' => $row['year'],
        'Status' => $row['status'] == 1 ? 'Present' : 'Absent',
    ];
}

if ($export_type === 'csv') {
    // Export CSV
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="student_attendance_report.csv"');

    $output = fopen('php://output', 'w');
    // Output headers
    if (count($data) > 0) {
        fputcsv($output, array_keys($data[0]));
        foreach ($data as $row) {
            fputcsv($output, $row);
        }
    } else {
        fputcsv($output, ['No data found']);
    }
    fclose($output);
    exit();
}

if ($export_type === 'word') {
    // Export Word (simple HTML)
    header("Content-Type: application/vnd.ms-word");
    header("Content-Disposition: attachment; filename=student_attendance_report.doc");

    echo "<html><head><meta charset='UTF-8'><title>Student Attendance Report</title>";
    echo "<style>table {border-collapse: collapse;} td, th {border: 1px solid #000; padding: 5px;}</style>";
    echo "</head><body>";
    echo "<h2>Student Attendance Report</h2>";

    if (count($data) > 0) {
        echo "<table>";
        echo "<tr>";
        foreach (array_keys($data[0]) as $col) {
            echo "<th>" . htmlspecialchars($col) . "</th>";
        }
        echo "</tr>";
        foreach ($data as $row) {
            echo "<tr>";
            foreach ($row as $cell) {
                echo "<td>" . htmlspecialchars($cell) . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No data found.</p>";
    }

    echo "</body></html>";
    exit();
}

// If unknown export type
echo "Invalid export type.";
?>
