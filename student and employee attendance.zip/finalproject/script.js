// ================= script.js =================
function validateLoginForm() {
  const accountType = document.getElementById("account_type").value;
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();
  const errorMessage = document.getElementById("error-message");

  if (!accountType || !username || !password) {
    errorMessage.textContent = "All fields are required.";
    return false;
  }

  // Optionally reset error message
  errorMessage.textContent = "";
  return true;
}
