<?php
include 'db.php';

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=attendance_export.xls");

$range = $_POST['range'];
$query = "SELECT full_name, username, date, status FROM attendance";

if ($range === 'daily') {
    $query .= " WHERE date = CURDATE()";
} elseif ($range === 'weekly') {
    $query .= " WHERE WEEK(date) = WEEK(CURDATE())";
} elseif ($range === 'monthly') {
    $query .= " WHERE MONTH(date) = MONTH(CURDATE())";
}

$result = $conn->query($query);
echo "Full Name\tUsername\tDate\tStatus\n";
while ($row = $result->fetch_assoc()) {
    echo "{$row['full_name']}\t{$row['username']}\t{$row['date']}\t{$row['status']}\n";
}
?>
