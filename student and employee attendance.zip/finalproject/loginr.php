<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dire Dawa University - Login</title>
    <style>
        /* DDU Official Colors */
        :root {
            --ddu-primary: #003366;       /* Dark Blue */
            --ddu-secondary: #FFCC00;     /* Gold/Yellow */
            --ddu-accent: #1a4d6b;        /* Light Blue */
            --ddu-white: #ffffff;
            --ddu-light-gray: #f5f5f5;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--ddu-light-gray);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            background-image: linear-gradient(135deg, var(--ddu-primary) 0%, var(--ddu-accent) 100%);
        }

        .login-container {
            background-color: var(--ddu-white);
            padding: 2.5rem;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            width: 100%;
            max-width: 450px;
            border-top: 5px solid var(--ddu-secondary);
        }

        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .login-header img {
            height: 70px;
            margin-bottom: 1rem;
        }

        .login-header h2 {
            color: var(--ddu-primary);
            margin: 0;
            font-size: 1.8rem;
        }

        .login-header p {
            color: #666;
            margin-top: 0.5rem;
        }

        .login-form {
            display: flex;
            flex-direction: column;
            gap: 1.2rem;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .form-group label {
            font-weight: 600;
            color: var(--ddu-primary);
            font-size: 0.95rem;
        }

        .form-group input,
        .form-group select {
            padding: 0.8rem;
            border: 2px solid #ddd;
            border-radius: 6px;
            font-size: 1rem;
            transition: all 0.2s ease;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: var(--ddu-secondary);
            box-shadow: 0 0 0 3px rgba(255, 204, 0, 0.2);
        }

        .login-btn {
            background-color: var(--ddu-primary);
            color: white;
            border: none;
            padding: 0.9rem;
            border-radius: 6px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            margin-top: 0.5rem;
        }

        .login-btn:hover {
            background-color: var(--ddu-accent);
        }

        /* Error Messages */
        .alert {
            padding: 1rem;
            border-radius: 6px;
            margin-top: 1.5rem;
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }

        .alert-danger {
            background-color: #fdecea;
            color: #c62828;
            border-left: 4px solid #c62828;
        }

        .alert-warning {
            background-color: #fff8e1;
            color: #ff8f00;
            border-left: 4px solid #ff8f00;
        }

        .alert-info {
            background-color: #e3f2fd;
            color: #1565c0;
            border-left: 4px solid #1565c0;
        }

        .alert-icon {
            font-size: 1.3rem;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <img src="https://www.ddu.edu.et/wp-content/uploads/2022/05/ddu-logo.png" alt="DDU Logo">
            <h2>Attendance System</h2>
            <p>Dire Dawa University Human Resource Management</p>
        </div>

        <form class="login-form" action="login.php" method="POST">
            <div class="form-group">
                <label for="account_type">Account Type</label>
                <select id="account_type" name="account_type" required>
                    <option value="">Select Account Type</option>
                    <option value="admin">Administrator</option>
                    <option value="hr">HR Officer</option>
                    <option value="employee">Employee</option>
                </select>
            </div>

            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>

            <button type="submit" class="login-btn">Login</button>
        </form>

        <!-- Error Messages -->
        <?php if (isset($_GET['error'])): ?>
            <div class="alert <?php 
                echo $_GET['error'] === 'deactivated' ? 'alert-danger' : 
                     ($_GET['error'] === 'invalid_credentials' ? 'alert-warning' : 'alert-info'); 
            ?>">
                <span class="alert-icon">
                    <?php 
                    echo $_GET['error'] === 'deactivated' ? '⛔' : 
                         ($_GET['error'] === 'invalid_credentials' ? '⚠️' : 'ℹ️'); 
                    ?>
                </span>
                <span>
                    <?php
                    if ($_GET['error'] === 'deactivated') {
                        echo '<strong>Account Deactivated</strong><br>';
                        echo 'Your account has been deactivated by the administrator.';
                        echo '<br>Please contact HR department for assistance.';
                    } elseif ($_GET['error'] === 'invalid_credentials') {
                        echo 'Invalid username or password. Please try again.';
                    } else {
                        echo 'Please fill in all required fields.';
                    }
                    ?>
                </span>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>