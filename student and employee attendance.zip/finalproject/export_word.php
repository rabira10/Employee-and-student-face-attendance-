<?php
require 'db.php';

$selectedDate = $_POST['report_date'] ?? date('Y-m-d');

$stmt = $pdo->prepare("
    SELECT 
        e.full_name AS name,
        CASE WHEN a.status = 'present' THEN 1 ELSE 0 END AS present_count,
        CASE WHEN a.status = 'leave' THEN 1 ELSE 0 END AS leave_count,
        CASE WHEN a.status = 'absent' OR a.username IS NULL THEN 1 ELSE 0 END AS absent_count
    FROM employees e
    LEFT JOIN attendance a 
        ON e.username = a.username 
        AND a.role = 'employee' 
        AND a.date = :selected_date
    ORDER BY e.full_name
");
$stmt->execute(['selected_date' => $selectedDate]);
$report = $stmt->fetchAll(PDO::FETCH_ASSOC);

$presentTotal = $absentTotal = $leaveTotal = 0;

header("Content-Type: application/vnd.ms-word");
header("Content-Disposition: attachment; filename=attendance_report_$selectedDate.doc");

echo "<html><body>";
echo "<h2>Attendance Report - $selectedDate</h2>";
echo "<table border='1' cellpadding='8' cellspacing='0'>";
echo "<tr><th>Employee Name</th><th>Present</th><th>Absent</th><th>Leave</th></tr>";

foreach ($report as $row) {
    echo "<tr>
            <td>{$row['name']}</td>
            <td>{$row['present_count']}</td>
            <td>{$row['absent_count']}</td>
            <td>{$row['leave_count']}</td>
          </tr>";
    $presentTotal += $row['present_count'];
    $absentTotal  += $row['absent_count'];
    $leaveTotal   += $row['leave_count'];
}

echo "<tr>
        <th>TOTAL</th>
        <th>$presentTotal</th>
        <th>$absentTotal</th>
        <th>$leaveTotal</th>
      </tr>";

echo "</table></body></html>";
?>
