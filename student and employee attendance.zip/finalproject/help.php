<?php
session_start();

// Language support
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

$default_lang = 'en'; // Default language
$current_lang = $_SESSION['lang'] ?? $default_lang;

// Load translations
$translations = [];
$lang_file = "languages/{$current_lang}.php";
if (file_exists($lang_file)) {
    $translations = require $lang_file;
}

// Helper function for translations
function t($key, $translations) {
    return $translations[$key] ?? $key;
}

// Check authentication and role
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student_dean') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo t('help_center', $translations); ?> - <?php echo t('dire_dawa_university', $translations); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #003366 0%, #1a4d6b 100%);
            min-height: 100vh;
            color: #333;
            line-height: 1.6;
        }
        
        /* Header Styles */
        .header {
            background: white;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border-bottom: 4px solid #FFCC00;
            padding: 1.5rem 0;
        }
        
        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo-section {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }
        
        .logo {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #003366, #004080);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
            box-shadow: 0 4px 15px rgba(0,51,102,0.3);
        }
        
        .university-info h1 {
            color: #003366;
            font-size: 1.8rem;
            margin-bottom: 0.2rem;
            font-weight: 700;
        }
        
        .university-info p {
            color: #666;
            font-size: 1rem;
            font-weight: 500;
        }
        
        .dean-section {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .dean-badge {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
            padding: 0.8rem 1.5rem;
            border-radius: 25px;
            font-weight: bold;
            font-size: 1rem;
            box-shadow: 0 4px 15px rgba(255,204,0,0.3);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .language-switcher {
            display: flex;
            gap: 0.5rem;
            margin-left: 1rem;
        }
        
        .language-switcher a {
            padding: 0.5rem;
            border-radius: 4px;
            text-decoration: none;
            color: #003366;
            font-weight: 500;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }
        
        .language-switcher a:hover {
            background: rgba(255, 204, 0, 0.2);
        }
        
        .language-switcher a.active {
            background: #FFCC00;
            color: #003366;
            font-weight: 600;
        }
        
        /* Main Container */
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        /* Help Center Specific Styles */
        .help-container {
            max-width: 1000px;
            margin: 2rem auto;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }
        
        .card-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .card-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: #003366;
        }
        
        .card-title {
            color: #003366;
            font-size: 1.5rem;
            font-weight: 700;
        }
        
        .search-box {
            width: 100%;
            padding: 1rem;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            margin-bottom: 2rem;
            font-size: 1rem;
        }
        
        .help-categories {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin: 2rem 0;
        }
        
        .category-card {
            background: white;
            border-radius: 8px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            text-decoration: none;
            color: #003366;
        }
        
        .category-card:hover {
            transform: translateY(-5px);
        }
        
        .category-icon {
            font-size: 2rem;
            color: #003366;
            margin-bottom: 1rem;
        }
        
        .faq-section {
            margin-top: 2rem;
        }
        
        .faq-item {
            margin-bottom: 1rem;
            border: 1px solid #e1e5e9;
            border-radius: 8px;
            overflow: hidden;
        }
        
        .faq-question {
            padding: 1rem;
            background: #f8f9fa;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: 600;
        }
        
        .faq-answer {
            padding: 0 1rem;
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease;
        }
        
        .faq-item.active .faq-answer {
            padding: 1rem;
            max-height: 500px;
        }
        
        .still-need-help {
            margin-top: 2rem;
            text-align: center;
        }
        
        .btn {
            background: linear-gradient(135deg, #003366, #004080);
            color: white;
            border: none;
            padding: 0.8rem 2rem;
            border-radius: 8px;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,51,102,0.3);
            display: inline-block;
            margin-top: 1rem;
            text-decoration: none;
        }
        
        .btn:hover {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(255,204,0,0.4);
        }
        
        /* Footer Styles */
        footer {
            background: #003366;
            color: white;
            padding: 2rem 0;
            margin-top: 3rem;
        }
        
        .footer-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
        }
        
        .footer-content {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 2rem;
        }
        
        .footer-section {
            flex: 1;
            min-width: 250px;
        }
        
        .footer-section h3 {
            color: #FFCC00;
            margin-bottom: 1rem;
            font-size: 1.2rem;
        }
        
        .footer-section p, .footer-section address {
            line-height: 1.6;
        }
        
        .footer-section address {
            font-style: normal;
        }
        
        .footer-section ul {
            list-style: none;
            line-height: 2;
        }
        
        .footer-section a {
            color: white;
            text-decoration: none;
        }
        
        .footer-section a:hover {
            text-decoration: underline;
            color: #FFCC00;
        }
        
        .footer-bottom {
            border-top: 1px solid rgba(255, 204, 0, 0.3);
            margin-top: 2rem;
            padding-top: 1.5rem;
            text-align: center;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
            
            .dean-section {
                flex-direction: column;
            }
            
            .language-switcher {
                margin-left: 0;
                margin-top: 0.5rem;
                justify-content: center;
                width: 100%;
            }
            
            .help-categories {
                grid-template-columns: 1fr;
            }
            
            .footer-content {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-content">
            <div class="logo-section">
                <div class="logo">DDU</div>
                <div class="university-info">
                    <h1><?php echo t('dire_dawa_university', $translations); ?></h1>
                    <p><?php echo t('student_dean_portal', $translations); ?></p>
                </div>
            </div>
            <div class="dean-section">
                <div class="language-switcher">
                    <a href="?lang=en" class="<?php echo $current_lang === 'en' ? 'active' : ''; ?>">English</a>
                    <a href="?lang=am" class="<?php echo $current_lang === 'am' ? 'active' : ''; ?>">አማርኛ</a>
                </div>
                <div class="dean-badge">
                    <i class="fas fa-user-graduate"></i>
                    <?php echo t('student_dean', $translations); ?>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="help-container">
            <div class="card-header">
                <div class="card-icon">❓</div>
                <div class="card-title"><?php echo t('help_center', $translations); ?></div>
            </div>
            
            <p><?php echo t('help_center_description', $translations); ?></p>
            
            <input type="text" class="search-box" placeholder="<?php echo t('search_help_articles', $translations); ?>...">
            
            <h3><?php echo t('help_categories', $translations); ?></h3>
            <div class="help-categories">
                <a href="#attendance-help" class="category-card">
                    <div class="category-icon"><i class="fas fa-calendar-check"></i></div>
                    <h4><?php echo t('attendance', $translations); ?></h4>
                </a>
                
                <a href="#student-management" class="category-card">
                    <div class="category-icon"><i class="fas fa-users"></i></div>
                    <h4><?php echo t('student_management', $translations); ?></h4>
                </a>
                
                <a href="#reports" class="category-card">
                    <div class="category-icon"><i class="fas fa-chart-bar"></i></div>
                    <h4><?php echo t('reports', $translations); ?></h4>
                </a>
                
                <a href="#account" class="category-card">
                    <div class="category-icon"><i class="fas fa-user-cog"></i></div>
                    <h4><?php echo t('account_settings', $translations); ?></h4>
                </a>
            </div>
            
            <div class="faq-section">
                <h3><?php echo t('frequently_asked_questions', $translations); ?></h3>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <span><?php echo t('how_to_set_attendance_time', $translations); ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p><?php echo t('attendance_time_instructions', $translations); ?></p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <span><?php echo t('how_to_generate_reports', $translations); ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p><?php echo t('report_generation_instructions', $translations); ?></p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <span><?php echo t('how_to_register_student', $translations); ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p><?php echo t('student_registration_instructions', $translations); ?></p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <span><?php echo t('how_to_change_password', $translations); ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p><?php echo t('password_change_instructions', $translations); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="still-need-help">
                <h3><?php echo t('still_need_help', $translations); ?></h3>
                <p><?php echo t('contact_our_support_team', $translations); ?></p>
                <a href="contact_us.php" class="btn">
                    <i class="fas fa-headset"></i> <?php echo t('contact_support', $translations); ?>
                </a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3><?php echo t('dire_dawa_university', $translations); ?></h3>
                    <p><?php echo t('footer_about_text', $translations); ?></p>
                </div>
                <div class="footer-section">
                    <h3><?php echo t('quick_links', $translations); ?></h3>
                    <ul>
                        <li><a href="https://www.ddu.edu.et"><?php echo t('university_website', $translations); ?></a></li>
                        <li><a href="contact_us.php"><?php echo t('contact_us', $translations); ?></a></li>
                        <li><a href="help_center.php"><?php echo t('help_center', $translations); ?></a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3><?php echo t('contact_info', $translations); ?></h3>
                    <address>
                        <p><i class="fas fa-map-marker-alt"></i> <?php echo t('university_address', $translations); ?></p>
                        <p><i class="fas fa-phone"></i> +251 25 111 2233</p>
                        <p><i class="fas fa-envelope"></i> studentdean@ddu.edu.et</p>
                    </address>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php echo t('dire_dawa_university', $translations); ?>. <?php echo t('all_rights_reserved', $translations); ?></p>
            </div>
        </div>
    </footer>
    
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script>
        // FAQ toggle functionality
        document.querySelectorAll('.faq-question').forEach(question => {
            question.addEventListener('click', () => {
                const item = question.parentElement;
                item.classList.toggle('active');
                
                const icon = question.querySelector('i');
                if (item.classList.contains('active')) {
                    icon.classList.remove('fa-chevron-down');
                    icon.classList.add('fa-chevron-up');
                } else {
                    icon.classList.remove('fa-chevron-up');
                    icon.classList.add('fa-chevron-down');
                }
            });
        });
        
        // Search functionality
        const searchBox = document.querySelector('.search-box');
        searchBox.addEventListener('input', (e) => {
            const searchTerm = e.target.value.toLowerCase();
            const faqItems = document.querySelectorAll('.faq-item');
            
            faqItems.forEach(item => {
                const question = item.querySelector('.faq-question').textContent.toLowerCase();
                const answer = item.querySelector('.faq-answer').textContent.toLowerCase();
                
                if (question.includes(searchTerm) || answer.includes(searchTerm)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>