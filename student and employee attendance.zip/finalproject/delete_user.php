<?php
// Connect to DB
$conn = new mysqli('localhost', 'root', '', 'ddu_attendance');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$successMsg = '';
$searchTerm = '';

// Handle deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_users'])) {
    // Array of usernames to delete
    $usernamesToDelete = $_POST['usernames'] ?? [];
    
    if (count($usernamesToDelete) > 0) {
        // Prepare placeholders for IN clause
        $placeholders = implode(',', array_fill(0, count($usernamesToDelete), '?'));
        
        $types = str_repeat('s', count($usernamesToDelete));
        $stmt = $conn->prepare("DELETE FROM users WHERE username IN ($placeholders)");
        $stmt->bind_param($types, ...$usernamesToDelete);
        $stmt->execute();

        $successMsg = "Deleted " . $stmt->affected_rows . " user(s) successfully!";
    }
}

// Handle search
if (isset($_GET['search'])) {
    $searchTerm = trim($_GET['search']);
    $searchSQL = "WHERE username LIKE ?";
} else {
    $searchSQL = "";
}

if ($searchTerm !== '') {
    $stmt = $conn->prepare("SELECT username, full_name, role, is_active FROM users $searchSQL ORDER BY username");
    $likeTerm = "%$searchTerm%";
    $stmt->bind_param("s", $likeTerm);
} else {
    $stmt = $conn->prepare("SELECT username, full_name, role, is_active FROM users ORDER BY username");
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Delete Users - Dire Dawa University</title>
<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f8f9fa;
        margin: 0;
        padding: 20px;
        color: #333;
    }
    .container {
        max-width: 700px;
        margin: 0 auto;
        position: relative;
    }
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 25px;
    }
    .form-container {
        padding: 30px;
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
    .form-group {
        display: flex;
        margin-bottom: 20px;
        align-items: center;
    }
    label {
        width: 150px;
        color: #006400; /* Dire Dawa green */
        font-weight: 600;
        font-size: 15px;
    }
    input[type="text"] {
        flex: 1;
        padding: 10px 12px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 15px;
        transition: border 0.3s;
    }
    input[type="text"]:focus {
        border-color: #006400;
        outline: none;
        box-shadow: 0 0 0 2px rgba(0,100,0,0.1);
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
        font-size: 15px;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 10px 15px;
        text-align: left;
    }
    th {
        background-color: #006400;
        color: white;
        font-weight: 600;
    }
    .checkbox-cell {
        width: 40px;
        text-align: center;
    }
    .button-group {
        display: flex;
        justify-content: space-between;
        margin-top: 10px;
    }
    .back-btn {
        display: inline-flex;
        align-items: center;
        text-decoration: none;
        color: white;
        font-weight: bold;
        border: none;
        padding: 12px 24px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 15px;
        transition: all 0.3s;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        background-color: #006400; /* Dire Dawa green */
    }
    .back-btn:hover {
        background-color: #004d00;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.15);
    }
    button.delete-btn {
        background-color: #FFD700; /* Dire Dawa gold */
        color: #006400; /* Green text */
        border: none;
        padding: 12px 24px;
        border-radius: 6px;
        cursor: pointer;
        font-weight: bold;
        font-size: 15px;
        transition: all 0.3s;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    button.delete-btn:hover {
        background-color: #e6c200;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.15);
    }
    .success {
        color: #006400;
        background-color: #e8f5e9;
        padding: 12px 15px;
        border-radius: 6px;
        margin-bottom: 20px;
        border-left: 4px solid #006400;
    }
    h1 {
        color: #006400; /* Dire Dawa green */
        margin: 0;
        font-size: 28px;
        position: relative;
    }
    h1:after {
        content: "";
        display: block;
        width: 80px;
        height: 3px;
        background: #FFD700; /* Dire Dawa gold */
        margin: 15px 0 0;
    }
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>Delete Users</h1>
    </div>

    <div class="form-container">
        <?php if ($successMsg): ?>
            <div class="success"><?= htmlspecialchars($successMsg) ?></div>
        <?php endif; ?>

        <!-- Search form -->
        <form method="GET" style="margin-bottom: 20px;">
            <div class="form-group">
                <label for="search">Search by username:</label>
                <input type="text" id="search" name="search" value="<?= htmlspecialchars($searchTerm) ?>" placeholder="Type to search...">
                <button type="submit" style="margin-left: 10px;">Search</button>
            </div>
        </form>

        <!-- User list & delete form -->
        <form method="POST" onsubmit="return confirm('Are you sure you want to delete selected user(s)?');">
            <table>
                <thead>
                    <tr>
                        <th class="checkbox-cell"><input type="checkbox" id="selectAll" onclick="toggleAll(this)"></th>
                        <th>Username</th>
                        <th>Full Name</th>
                        <th>Role</th>
                        <th>Active</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td class="checkbox-cell">
                                    <input type="checkbox" name="usernames[]" value="<?= htmlspecialchars($row['username']) ?>">
                                </td>
                                <td><?= htmlspecialchars($row['username']) ?></td>
                                <td><?= htmlspecialchars($row['full_name']) ?></td>
                                <td><?= htmlspecialchars(ucfirst($row['role'])) ?></td>
                                <td><?= $row['is_active'] ? 'Yes' : 'No' ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" style="text-align:center;">No users found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="button-group">
                <a href="javascript:history.back()" class="back-btn">
                    &larr; Back
                </a>
                <button type="submit" name="delete_users" class="delete-btn">Delete Selected Users</button>
            </div>
        </form>
    </div>
</div>

<script>
function toggleAll(source) {
    const checkboxes = document.querySelectorAll('input[name="usernames[]"]');
    checkboxes.forEach(checkbox => checkbox.checked = source.checked);
}
</script>
</body>
</html>
