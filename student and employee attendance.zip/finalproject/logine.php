<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DDU Attendance System - Login</title>
  <link rel="stylesheet" href="style.css">
</head>
<script>
  const urlParams = new URLSearchParams(window.location.search);
  const error = urlParams.get('error');
  if (error) {
    const errorMessage = {
      empty: "Please fill in all fields.",
      invalid_role: "Invalid role selected.",
      invalid_credentials: "Incorrect username or password.",
    }[error] || "Unknown error occurred.";
    document.getElementById("error-message").textContent = errorMessage;
    document.getElementById("error-message").style.color = "red";
  }
</script>

<body>
  <div class="login-container">
    <h2>DDU Attendance System Login</h2>
    <form action="login.php" method="POST" onsubmit="return validateLoginForm()">
      <label for="account_type">Account Type</label>
      <select id="account_type" name="account_type" required>
        <option value="">Select Account Type</option>
        <option value="admin">Administrator</option>
        <option value="hr">HR Officer</option>
        <option value="student_dean">Student Dean</option>
        <option value="employee">Employee</option>
        <option value="student">Student</option>
      </select>

      <label for="username">Username</label>
      <input type="text" id="username" name="username" required>

      <label for="password">Password</label>
      <input type="password" id="password" name="password" required>

      <button type="submit">Login</button>
    </form>
    <p id="error-message"></p>
  </div>

  <script src="script.js"></script>
</body>
</html>
