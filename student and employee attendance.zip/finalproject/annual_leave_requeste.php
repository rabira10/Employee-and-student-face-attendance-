<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'employee') {
    header("Location: employee_login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['user'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $start_date = $_POST['start_date'] ?? '';
    $end_date = $_POST['end_date'] ?? '';
    $reason = $_POST['reason'] ?? '';

    if (!$start_date || !$end_date || !$reason) {
        $message = "Please fill in all fields.";
    } elseif ($start_date > $end_date) {
        $message = "Start date must be before or equal to end date.";
    } else {
        $stmt = $conn->prepare("INSERT INTO leave_requests (username, start_date, end_date, reason) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $username, $start_date, $end_date, $reason);
        if ($stmt->execute()) {
            $message = "Leave request submitted successfully.";
        } else {
            $message = "Failed to submit leave request.";
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Send Annual Leave Request</title>
</head>
<body>
    <h2>Send Annual Leave Request</h2>
    <?php if ($message) echo "<p><strong>$message</strong></p>"; ?>
    <form method="POST" action="">
        <label>Start Date:<br />
            <input type="date" name="start_date" required />
        </label><br /><br />

        <label>End Date:<br />
            <input type="date" name="end_date" required />
        </label><br /><br />

        <label>Reason:<br />
            <textarea name="reason" rows="4" cols="40" required></textarea>
        </label><br /><br />

        <button type="submit">Submit Leave Request</button>
    </form>
    <p><a href="dashboard_employee.php">Back to Dashboard</a></p>
</body>
</html>
