<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'hr') {
    header("Location: login.html");
    exit;
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $start = $_POST['start_time'];
    $end = $_POST['end_time'];

    $stmt = $conn->prepare("UPDATE attendance_settings SET start_time = ?, end_time = ? WHERE id = 1");
    $stmt->bind_param("ss", $start, $end);
    if ($stmt->execute()) {
        $message = "✅ Attendance time updated successfully!";
    } else {
        $message = "❌ Failed to update time.";
    }
    $stmt->close();
}

$result = $conn->query("SELECT * FROM attendance_settings WHERE id = 1");
$row = $result->fetch_assoc();
$start_time = $row['start_time'];
$end_time = $row['end_time'];
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Set Attendance Time</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        label, input { display: block; margin-top: 10px; }
        input[type="time"] { padding: 5px; }
        button { margin-top: 15px; padding: 8px 15px; }
        .message { margin-top: 15px; color: green; }
    </style>
</head>
<body>
    <h2>Set Allowed Attendance Time</h2>
    <?php if ($message): ?><p class="message"><?= $message ?></p><?php endif; ?>
    <form method="POST">
        <label>Start Time:</label>
        <input type="time" name="start_time" value="<?= $start_time ?>" required>

        <label>End Time:</label>
        <input type="time" name="end_time" value="<?= $end_time ?>" required>

        <button type="submit">Update Time</button>
    </form>
    <p><a href="dashboard_hr.php">Back to Dashboard</a></p>
</body>
</html>
