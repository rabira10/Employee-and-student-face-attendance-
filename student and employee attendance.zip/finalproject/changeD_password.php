<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student_dean') {
    header("Location: login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");

$message = '';
$error = '';

$username = $_SESSION['user'];  // Assuming username is stored in session as 'user'

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = "All fields are required.";
    } elseif ($new_password !== $confirm_password) {
        $error = "New password and confirmation do not match.";
    } else {
        // Fetch current hashed password from database
        $stmt = $conn->prepare("SELECT password FROM student_deans WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->bind_result($hashed_password);
        if ($stmt->fetch()) {
            $stmt->close();

            if (password_verify($current_password, $hashed_password)) {
                // Hash new password
                $new_hashed = password_hash($new_password, PASSWORD_DEFAULT);

                // Update password in DB
                $update_stmt = $conn->prepare("UPDATE student_deans SET password = ? WHERE username = ?");
                $update_stmt->bind_param("ss", $new_hashed, $username);
                if ($update_stmt->execute()) {
                    $message = "Password updated successfully.";
                } else {
                    $error = "Failed to update password. Please try again.";
                }
                $update_stmt->close();
            } else {
                $error = "Current password is incorrect.";
            }
        } else {
            $error = "User not found.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Change Password - Student Dean</title>
    <style>
        body { font-family: Arial; background-color: #eef2f7; padding: 20px; }
        form { background: white; padding: 20px; border-radius: 8px; max-width: 400px; }
        label { display: block; margin-bottom: 8px; font-weight: bold; }
        input { width: 100%; padding: 8px; margin-bottom: 15px; }
        button { background-color: #003366; color: white; padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background-color: #002244; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 5px; }
        .success { background-color: #d4edda; color: #155724; }
        .error { background-color: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <h2>Change Password</h2>

    <?php if ($message): ?>
        <div class="message success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="message error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="change_password.php">
        <label for="current_password">Current Password:</label>
        <input type="password" id="current_password" name="current_password" required>

        <label for="new_password">New Password:</label>
        <input type="password" id="new_password" name="new_password" required>

        <label for="confirm_password">Confirm New Password:</label>
        <input type="password" id="confirm_password" name="confirm_password" required>

        <button type="submit">Update Password</button>
    </form>
</body>
</html>
