<?php
session_start();
date_default_timezone_set('Africa/Addis_Ababa');
header('Content-Type: application/json');

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'employee') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'DB connection failed']);
    exit();
}

$today = date("Y-m-d");
$currentTime24 = date("H:i:s");

// Get user id
$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt->bind_param("s", $_SESSION['user']);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'User not found']);
    exit();
}
$user_id = $result->fetch_assoc()['id'];

// Check if attendance already exists today
$check = $conn->prepare("SELECT id FROM attendance WHERE user_id = ? AND date = ?");
$check->bind_param("is", $user_id, $today);
$check->execute();
if ($check->get_result()->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Already signed attendance today']);
    exit();
}

// Insert attendance
$insert = $conn->prepare("INSERT INTO attendance (user_id, date, time) VALUES (?, ?, ?)");
$insert->bind_param("iss", $user_id, $today, $currentTime24);
if ($insert->execute()) {
    echo json_encode(['success' => true, 'time' => date("g:i:s A")]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to record attendance']);
}
