<?php
session_start();

// Check if user logged in as employee
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'employee') {
    header("Location: employee_login.html");
    exit();
}

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: change_password_form.php");
    exit();
}

$username = $_SESSION['user'];
$old_password = trim($_POST['old_password'] ?? '');
$new_password = trim($_POST['new_password'] ?? '');
$confirm_password = trim($_POST['confirm_password'] ?? '');

// Check new passwords match
if ($new_password !== $confirm_password) {
    $_SESSION['change_pass_error'] = "New passwords do not match.";
    header("Location: change_password_form.php");
    exit();
}

// Connect to DB (adjust host, user, pass, db as needed)
$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare select statement
$stmt = $conn->prepare("SELECT password FROM employees WHERE username = ?");
if (!$stmt) {
    $_SESSION['change_pass_error'] = "Database error: " . $conn->error;
    header("Location: change_password_form.php");
    exit();
}
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->bind_result($hashed_password);
if (!$stmt->fetch()) {
    $stmt->close();
    $conn->close();
    $_SESSION['change_pass_error'] = "User not found.";
    header("Location: change_password_form.php");
    exit();
}
$stmt->close();

// Verify old password
if (!password_verify($old_password, $hashed_password)) {
    $conn->close();
    $_SESSION['change_pass_error'] = "Old password is incorrect.";
    header("Location: change_password_form.php");
    exit();
}

// Hash new password
$new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

// Update password in DB
$update_stmt = $conn->prepare("UPDATE employees SET password = ? WHERE username = ?");
if (!$update_stmt) {
    $_SESSION['change_pass_error'] = "Database error: " . $conn->error;
    $conn->close();
    header("Location: change_password_form.php");
    exit();
}
$update_stmt->bind_param("ss", $new_hashed_password, $username);

if ($update_stmt->execute()) {
    $_SESSION['change_pass_success'] = "Password changed successfully.";
} else {
    $_SESSION['change_pass_error'] = "Failed to update password. Please try again.";
}

$update_stmt->close();
$conn->close();

header("Location: change_password_form.php");
exit();
?>
