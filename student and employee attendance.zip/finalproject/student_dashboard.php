<?php
session_start();

// Check authentication and role
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit();
}

// Language selection logic
$available_languages = ['en' => 'English', 'am' => 'አማርኛ'];
$default_language = 'en'; // Default to English

// Check if language is set in session or GET parameter
if (isset($_GET['lang']) && array_key_exists($_GET['lang'], $available_languages)) {
    $_SESSION['lang'] = $_GET['lang'];
    // Redirect to same page without lang parameter to avoid resubmission
    header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
    exit();
} elseif (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = $default_language;
}

$current_lang = $_SESSION['lang'];

// Amharic translations
$translations = [
    'en' => [
        'title' => 'Student Dashboard - Dire Dawa University',
        'welcome' => 'Welcome',
        'student_id' => 'Student ID',
        'account_created' => 'Account created on',
        'days_since_reg' => 'Days Since Registration',
        'total_school_days' => 'Total School Days',
        'present_days' => 'Present Days',
        'absent_days' => 'Absent Days',
        'attendance_rate' => 'Attendance Rate',
        'mark_attendance' => 'Mark Attendance',
        'sign_attendance' => 'Sign Today\'s Attendance',
        'attendance_progress' => 'Attendance Progress',
        'quick_actions' => 'Quick Actions',
        'change_password' => 'Change Password',
        'logout' => 'Logout',
        'attendance_records' => 'Your Attendance Records',
        'date' => 'Date',
        'status' => 'Status',
        'day' => 'Day',
        'present' => 'Present',
        'absent' => 'Absent',
        'no_records' => 'No attendance records found. Start marking your attendance!',
        'recent_notifications' => 'Recent Notifications',
        'no_notifications' => 'No notifications at this time.',
        'time_message' => 'The time is now %s. You can only sign attendance between %s and %s',
        'no_settings' => 'No attendance settings found for your role',
        'system_not_configured' => 'Attendance system not configured',
        'system_issue' => 'Temporary system issue - signing allowed',
        'already_signed' => 'You have already signed today\'s attendance.',
        'sign_success' => 'Attendance signed successfully!',
        'sign_failed' => 'Failed to sign attendance. Please try again.',
        'menu' => '☰ Menu',
        'university_name' => 'Dire Dawa University',
        'portal_name' => 'Student Attendance Portal',
        'face_verification' => 'Face Verification',
        'capture_face' => 'Capture Face',
        'verifying_face' => 'Verifying Face...',
        'face_verified' => 'Face Verified!',
        'verification_failed' => 'Verification Failed',
        'footer_text' => 'Dire Dawa University Student Attendance System',
        'copyright' => '© ' . date('Y') . ' All Rights Reserved',
        'contact_us' => 'Contact Us',
        'privacy_policy' => 'Privacy Policy',
        'terms_of_service' => 'Terms of Service',
        'developed_by' => 'Developed by ICT Directorate',
        'address' => 'P.O. Box 1362, Dire Dawa, Ethiopia',
        'phone' => 'Phone: +251 25 111 2233',
        'email' => 'Email: info@ddu.edu.et',
        'working_hours' => 'Working Hours',
        'follow_us' => 'Follow Us',
        'emergency' => 'Emergency',
        'scroll_to_top' => 'Scroll to Top',
        'home' => 'Home',
    ],
    'am' => [
        'title' => 'የተማሪ ዳሽቦርድ - ድሬዳዋ ዩኒቨርሲቲ',
        'welcome' => 'እንኳን ደህና መጡ',
        'student_id' => 'የተማሪ መታወቂያ',
        'account_created' => 'መለያ የተፈጠረበት ቀን',
        'days_since_reg' => 'ከምዝገባ ወዲህ ያለፉት ቀኖች',
        'total_school_days' => 'ጠቅላላ የትምህርት ቀኖች',
        'present_days' => 'የተገኙት ቀኖች',
        'absent_days' => 'ያልተገኙት ቀኖች',
        'attendance_rate' => 'የመገኘት መጠን',
        'mark_attendance' => 'መገኛ ምዝገባ',
        'sign_attendance' => 'የዛሬውን መገኛ ምዝገባ ይፈርሙ',
        'attendance_progress' => 'የመገኘት እድገት',
        'quick_actions' => 'ፈጣን እርምጃዎች',
        'change_password' => 'የይለፍ ቃል ቀይር',
        'logout' => 'ውጣ',
        'attendance_records' => 'የመገኘት ቀኖች ምዝገባ',
        'date' => 'ቀን',
        'status' => 'ሁኔታ',
        'day' => 'የሳምንት ቀን',
        'present' => 'ተገኝቷል',
        'absent' => 'አልተገኘም',
        'no_records' => 'ምንም የመገኘት ምዝገባ አልተገኘም። መገኛ ምዝገባዎትን መምዝግብ ይጀምሩ!',
        'recent_notifications' => 'የቅርብ ማስታወቂያዎች',
        'no_notifications' => 'ምንም ማስታወቂያ የለም።',
        'time_message' => 'አሁን ያለው ሰዓት %s ነው። መገኛ ምዝገባ በ%s እና %s መካከል ብቻ ይችላሉ።',
        'no_settings' => 'ለሚንቀሳቀሱበት ሚና ምንም ቅንብሮች አልተገኙም',
        'system_not_configured' => 'የመገኘት ስርዓት አልተዋቀረም',
        'system_issue' => 'የጊዜያዊ ስርዓት ችግር - መፈረም ይቻላል',
        'already_signed' => 'የዛሬውን መገኛ ምዝገባ አስቀድመው ፈርመዋል።',
        'sign_success' => 'መገኛ ምዝገባ በተሳካ ሁኔታ ተፈርሟል!',
        'sign_failed' => 'መገኛ ምዝገባ ማድረግ አልተቻለም። እባክዎ ደግመው ይሞክሩ።',
        'menu' => '☰ ምናሌ',
        'university_name' => 'ድሬዳዋ ዩኒቨርሲቲ',
        'portal_name' => 'የተማሪ መገኘት ምዝገባ ፖርታል',
        'face_verification' => 'ፊት ማረጋገጫ',
        'capture_face' => 'ፊት ያንሱ',
        'verifying_face' => 'ፊት እየተረጋገጠ ነው...',
        'face_verified' => 'ፊት ተረጋግጧል!',
        'verification_failed' => 'ማረጋገጫ አልተሳካም',
        'footer_text' => 'ድሬዳዋ ዩኒቨርሲቲ የተማሪ መገኘት ምዝገባ ስርዓት',
        'copyright' => '© ' . date('Y') . ' ሁሉም መብቶች የተጠበቁ ናቸው',
        'contact_us' => 'አግኙን',
        'privacy_policy' => 'የግላዊነት ፖሊሲ',
        'terms_of_service' => 'የአገልግሎት ውሎች',
        'developed_by' => 'የተሰራው በ ICT ዳይሬክቶሬት',
        'address' => 'ፖ.ቁ. 1362, ድሬዳዋ, ኢትዮጵያ',
        'phone' => 'ስልክ: +251 25 111 2233',
        'email' => 'ኢሜይል: info@ddu.edu.et',
        'working_hours' => 'የስራ ሰዓት',
        'follow_us' => 'ተከተሉን',
        'emergency' => 'አደጋ',
        'scroll_to_top' => 'ወደ ላይ ይሸብልሉ',
        'home' => 'መነሻ',
    ]
];

function t($key) {
    global $translations, $current_lang;
    return $translations[$current_lang][$key] ?? $translations['en'][$key] ?? $key;
}

// Database configuration
$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$student_id = $_SESSION['student_id'];
$attendanceMessage = '';
$messageType = '';

// Set timezone
date_default_timezone_set('Africa/Addis_Ababa');

// Initialize allow_sign
$allow_sign = true;
$current_time = date('H:i:s');

// Check attendance settings
try {
    $tableCheck = $conn->query("SHOW TABLES LIKE 'attendance_settings'");

    if ($tableCheck && $tableCheck->num_rows > 0) {
        $columnCheck = $conn->query("SHOW COLUMNS FROM attendance_settings LIKE 'role'");
        $hasRoleColumn = ($columnCheck && $columnCheck->num_rows > 0);
        
        $timeSettingQuery = $hasRoleColumn 
            ? "SELECT * FROM attendance_settings WHERE role = 'student' LIMIT 1" 
            : "SELECT * FROM attendance_settings LIMIT 1";
        
        $timeSetting = $conn->query($timeSettingQuery);
        
        if ($timeSetting && $timeSetting->num_rows > 0) {
            $setting = $timeSetting->fetch_assoc();
            
            if (empty($setting['start_time']) || empty($setting['end_time'])) {
                throw new Exception("Start time or end time not set in attendance settings");
            }
            
            $display_start = date("g:i A", strtotime($setting['start_time']));
            $display_end = date("g:i A", strtotime($setting['end_time']));
            
            $current_time_obj = new DateTime($current_time);
            $start_time_obj = DateTime::createFromFormat('H:i:s', $setting['start_time']);
            $end_time_obj = DateTime::createFromFormat('H:i:s', $setting['end_time']);
            
            if ($current_time_obj < $start_time_obj || $current_time_obj > $end_time_obj) {
                $allow_sign = false;
                $current_display = date("g:i A");
                $attendanceMessage = sprintf(t('time_message'), $current_display, $display_start, $display_end);
                $messageType = 'warning';
            }
        } else {
            $attendanceMessage = t('no_settings');
            $messageType = 'warning';
        }
    } else {
        $attendanceMessage = t('system_not_configured');
        $messageType = 'warning';
    }
} catch (Exception $e) {
    $allow_sign = true;
    $attendanceMessage = t('system_issue');
    $messageType = 'warning';
}

// Fetch attendance records with pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$stmt = $conn->prepare("SELECT attendance_date, status FROM student_attendance WHERE student_id = ? ORDER BY attendance_date DESC LIMIT ? OFFSET ?");
$stmt->bind_param("sii", $student_id, $limit, $offset);
$stmt->execute();
$attendanceRecords = $stmt->get_result();

// Get total attendance count for pagination
$countStmt = $conn->prepare("SELECT COUNT(*) as total FROM student_attendance WHERE student_id = ?");
$countStmt->bind_param("s", $student_id);
$countStmt->execute();
$totalRecords = $countStmt->get_result()->fetch_assoc()['total'];
$totalPages = ceil($totalRecords / $limit);

// Fetch notifications
$notifications = [];
try {
    $noti_check = $conn->query("SHOW COLUMNS FROM notifications LIKE 'target_role'");
    
    if ($noti_check && $noti_check->num_rows > 0) {
        $noti_stmt = $conn->prepare("
            SELECT message, MAX(created_at) as created_at 
            FROM notifications 
            WHERE target_role IN ('student', 'all') 
            GROUP BY message 
            ORDER BY created_at DESC 
            LIMIT 5
        ");
    } else {
        $noti_stmt = $conn->prepare("
            SELECT message, MAX(created_at) as created_at 
            FROM notifications 
            GROUP BY message 
            ORDER BY created_at DESC 
            LIMIT 5
        ");
    }
    
    $noti_stmt->execute();
    $notifications = $noti_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    $notifications = [];
}

// Fetch unread notification count
$unreadCount = 0;
try {
    $unreadStmt = $conn->prepare("
        SELECT COUNT(*) as unread_count 
        FROM notifications 
        WHERE (target_role IN ('student', 'all') OR target_id = ?)
        AND (read_status = 0 OR read_status IS NULL)
    ");
    $unreadStmt->bind_param("s", $student_id);
    $unreadStmt->execute();
    $unreadResult = $unreadStmt->get_result()->fetch_assoc();
    $unreadCount = $unreadResult['unread_count'] ?? 0;
} catch (Exception $e) {
    $unreadCount = 0;
}

// Get student account creation date
$studentStmt = $conn->prepare("SELECT created_at FROM students WHERE id = ?");
$studentStmt->bind_param("s", $student_id);
$studentStmt->execute();
$studentResult = $studentStmt->get_result()->fetch_assoc();

if ($studentResult) {
    $accountCreationDate = new DateTime($studentResult['created_at']);
    $currentDate = new DateTime();
    $daysSinceCreation = $currentDate->diff($accountCreationDate)->days;
} else {
    $accountCreationDate = new DateTime();
    $daysSinceCreation = 0;
}

// Calculate total school days (assuming 5 days per week)
$startDate = new DateTime($studentResult ? $studentResult['created_at'] : date('Y-m-d'));
$endDate = new DateTime();
$interval = new DateInterval('P1D');
$period = new DatePeriod($startDate, $interval, $endDate);

$totalSchoolDays = 0;
foreach ($period as $date) {
    if ($date->format('N') < 6) {
        $totalSchoolDays++;
    }
}

// Calculate present days
$presentStmt = $conn->prepare("SELECT COUNT(*) as present_days FROM student_attendance WHERE student_id = ? AND status = 'Present'");
$presentStmt->bind_param("s", $student_id);
$presentStmt->execute();
$presentResult = $presentStmt->get_result()->fetch_assoc();
$present_days = $presentResult['present_days'] ?? 0;

// Calculate absent days
$absent_days = max(0, $totalSchoolDays - $present_days);
$attendancePercentage = $totalSchoolDays > 0 ? round(($present_days / $totalSchoolDays) * 100, 1) : 0;
?>

<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo t('title'); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #003366 0%, #1a4d6b 100%);
            min-height: 100vh;
            color: #333;
            line-height: 1.6;
            position: relative;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideIn {
            from { transform: translateX(-30px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes scaleIn {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(255, 204, 0, 0.4); }
            70% { box-shadow: 0 0 0 15px rgba(255, 204, 0, 0); }
            100% { box-shadow: 0 0 0 0 rgba(255, 204, 0, 0); }
        }

        /* Header */
        .header {
            background: white;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border-bottom: 4px solid #FFCC00;
            padding: 1.5rem 0;
            animation: slideIn 0.6s ease-out;
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .logo {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        .logo img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }

        .university-info h1 {
            color: #003366;
            font-size: 1.8rem;
            margin-bottom: 0.2rem;
            font-weight: 700;
        }

        .university-info p {
            color: #666;
            font-size: 1rem;
            font-weight: 500;
        }

        .student-badge {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
            padding: 0.8rem 1.5rem;
            border-radius: 25px;
            font-weight: bold;
            font-size: 1rem;
            box-shadow: 0 4px 15px rgba(255,204,0,0.3);
        }

        /* Main Navigation */
        .main-nav {
            flex-grow: 1;
            margin: 0 2rem;
        }

        .main-nav ul {
            display: flex;
            list-style: none;
            justify-content: center;
            gap: 1.5rem;
        }

        .main-nav a {
            color: #003366;
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            transition: all 0.3s ease;
            position: relative;
        }

        .main-nav a:hover {
            background: rgba(0, 51, 102, 0.1);
        }

        .main-nav a.active {
            background: #003366;
            color: white;
        }

        /* Notification Badge */
        .notification-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background-color: #dc3545;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 12px;
            line-height: 1;
            min-width: 18px;
            text-align: center;
        }

        /* Language Switcher */
        .language-switcher {
            display: flex;
            gap: 0.5rem;
            margin-right: 1rem;
            align-items: center;
        }

        .language-switcher a {
            color: #003366;
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 0.8rem;
            border-radius: 4px;
            transition: all 0.3s ease;
            border: 1px solid #003366;
        }

        .language-switcher a:hover {
            background: rgba(0, 51, 102, 0.1);
        }

        .language-switcher a.active {
            background: #003366;
            color: white;
        }

        /* Dropdown Menu */
        .dropdown {
            position: relative;
            display: inline-block;
        }
        
        .dropdown-toggle {
            background: linear-gradient(135deg, #003366, #004080);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,51,102,0.3);
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        
        .dropdown-toggle:hover {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(255,204,0,0.4);
        }
        
        .dropdown-menu {
            display: none;
            position: absolute;
            background-color: white;
            min-width: 200px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 8px;
            overflow: hidden;
            right: 0;
        }
        
        .dropdown-menu a, .dropdown-menu button {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            text-align: left;
            width: 100%;
            border: none;
            background: none;
            font-family: inherit;
            font-size: inherit;
            cursor: pointer;
        }
        
        .dropdown-menu a:hover, .dropdown-menu button:hover {
            background-color: rgba(255, 204, 0, 0.2);
        }
        
        .dropdown.show .dropdown-menu {
            display: block;
            animation: fadeIn 0.3s ease-out;
        }

        /* Main Container */
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
            animation: fadeIn 0.8s ease-out;
        }

        .welcome-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            text-align: center;
        }

        .welcome-section h2 {
            color: #003366;
            font-size: 2rem;
            margin-bottom: 0.5rem;
            font-weight: 700;
        }

        .welcome-section p {
            color: #666;
            font-size: 1.1rem;
        }

        /* Grid Layout */
        .dashboard-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .dashboard-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            animation: scaleIn 0.7s ease-out;
        }

        .card-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .card-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: #003366;
        }

        .card-title {
            color: #003366;
            font-size: 1.5rem;
            font-weight: 700;
        }

        /* Attendance Stats */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 15px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 45px rgba(0,0,0,0.15);
        }

        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: #003366;
            margin-bottom: 0.3rem;
        }

        .stat-label {
            color: #666;
            font-size: 0.9rem;
            font-weight: 500;
        }

        /* Buttons */
        .btn {
            background: linear-gradient(135deg, #003366, #004080);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,51,102,0.3);
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }

        .btn:hover {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(255,204,0,0.4);
        }

        .btn:disabled {
            background: #6c757d;
            cursor: not-allowed;
            transform: none;
        }

        .btn:disabled:hover {
            background: #6c757d;
            color: white;
            transform: none;
        }

        .btn-large {
            font-size: 1.2rem;
            padding: 1.2rem 2.5rem;
            width: 100%;
            margin-bottom: 1rem;
        }

        .btn-secondary {
            background: linear-gradient(135deg, #6c757d, #5a6268);
        }

        .btn-logout {
            background: linear-gradient(135deg, #dc3545, #c82333);
        }

        .btn-logout:hover {
            background: linear-gradient(135deg, #ff6b6b, #ff5252);
            color: white;
        }

        /* Messages */
        .message {
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin: 1rem 0;
            font-weight: 500;
            animation: fadeIn 0.5s ease-out;
        }

        .message.success {
            background: linear-gradient(135deg, #d4edda, #c3e6cb);
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.warning {
            background: linear-gradient(135deg, #fff3cd, #ffeaa7);
            color: #856404;
            border: 1px solid #ffeaa7;
        }

        .message.error {
            background: linear-gradient(135deg, #f8d7da, #f5c6cb);
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Tables */
        .table-container {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-top: 1rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #e1e5e9;
        }

        th {
            background: linear-gradient(135deg, #003366, #004080);
            color: white;
            font-weight: 600;
        }

        td {
            background: white;
            transition: background-color 0.3s ease;
        }

        tr:hover td {
            background: rgba(255, 204, 0, 0.1);
        }

        .status-present {
            color: #28a745;
            font-weight: 600;
        }

        .status-absent {
            color: #dc3545;
            font-weight: 600;
        }

        /* Notifications */
        .notifications {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .notification-item {
            padding: 1rem;
            margin-bottom: 1rem;
            background: rgba(255, 204, 0, 0.1);
            border-radius: 8px;
            border-left: 4px solid #FFCC00;
        }

        .notification-item:last-child {
            margin-bottom: 0;
        }

        .notification-message {
            color: #003366;
            font-weight: 500;
            margin-bottom: 0.5rem;
        }

        .notification-time {
            font-size: 0.85em;
            color: #666;
        }

        /* Progress Bar */
        .progress-container {
            margin: 1rem 0;
        }

        .progress-bar {
            width: 100%;
            height: 20px;
            background: #e1e5e9;
            border-radius: 10px;
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(135deg, #28a745, #20c997);
            border-radius: 10px;
            transition: width 0.5s ease;
        }

        .progress-text {
            text-align: center;
            margin-top: 0.5rem;
            font-weight: 600;
            color: #003366;
        }

        /* Footer Styles */
        .footer {
            background: linear-gradient(135deg, #003366 0%, #1a4d6b 100%);
            color: white;
            padding: 2rem 0;
            margin-top: 3rem;
            border-top: 4px solid #FFCC00;
        }

        .footer-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 2rem;
        }

        .footer-logo {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .footer-logo .logo {
            width: 40px;
            height: 40px;
            background: white;
            color: #003366;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2rem;
        }

        .footer-about p {
            margin-bottom: 1rem;
            line-height: 1.6;
        }

        .footer-links h3, .footer-contact h3 {
            font-size: 1.2rem;
            margin-bottom: 1.5rem;
            position: relative;
            padding-bottom: 0.5rem;
        }

        .footer-links h3::after, .footer-contact h3::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 50px;
            height: 3px;
            background: #FFCC00;
        }

        .footer-links ul {
            list-style: none;
        }

        .footer-links li {
            margin-bottom: 0.8rem;
        }

        .footer-links a {
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-block;
        }

        .footer-links a:hover {
            color: #FFCC00;
            transform: translateX(5px);
        }

        .footer-contact i {
            width: 20px;
            text-align: center;
            margin-right: 8px;
        }

        .contact-hours {
            margin: 1rem 0;
            padding: 0.8rem;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
        }

        .social-media {
            margin: 1.5rem 0;
        }

        .social-media h4 {
            margin-bottom: 0.8rem;
            font-size: 1rem;
        }

        .social-icons {
            display: flex;
            gap: 12px;
        }

        .social-icons a {
            color: white;
            background: rgba(255, 255, 255, 0.2);
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .social-icons a:hover {
            background: #FFCC00;
            color: #003366;
            transform: translateY(-3px);
        }

        .emergency-contact {
            margin-top: 1rem;
            padding: 0.8rem;
            background: rgba(220, 53, 69, 0.2);
            border-radius: 8px;
            border-left: 4px solid #dc3545;
        }

        .footer-bottom {
            text-align: center;
            padding-top: 2rem;
            margin-top: 2rem;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* Scroll to Top Button */
        .scroll-to-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            z-index: 99;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }

        .scroll-to-top.active {
            opacity: 1;
            visibility: visible;
        }

        .scroll-to-top:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 20px rgba(255, 204, 0, 0.4);
        }

        .scroll-to-top .tooltip {
            position: absolute;
            top: -40px;
            background: #003366;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.8rem;
            white-space: nowrap;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .scroll-to-top:hover .tooltip {
            opacity: 1;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .header-content {
                flex-direction: column;
                gap: 1.5rem;
            }
            
            .main-nav {
                margin: 1rem 0;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .footer-content {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .main-nav ul {
                flex-direction: column;
                gap: 0.5rem;
                align-items: center;
            }
            
            .dashboard-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .container {
                padding: 1rem;
            }

            .dashboard-card {
                padding: 1.5rem;
            }

            .university-info h1 {
                font-size: 1.5rem;
            }

            table {
                font-size: 0.9rem;
            }

            th, td {
                padding: 0.5rem;
            }
            
            .footer-content {
                grid-template-columns: 1fr;
                gap: 1.5rem;
            }

            .scroll-to-top {
                width: 40px;
                height: 40px;
                font-size: 1rem;
                bottom: 20px;
                right: 20px;
            }
        }

        /* Full Width Sections */
        .full-width-section {
            grid-column: 1 / -1;
        }

        .no-data {
            text-align: center;
            color: #666;
            font-style: italic;
            padding: 2rem;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-content">
            <div class="logo-section">
                <div class="logo">
                    <img src="images/ddu.jfif" alt="Dire Dawa University Logo">
                </div>
                <div class="university-info">
                    <h1><?php echo t('university_name'); ?></h1>
                    <p><?php echo t('portal_name'); ?></p>
                </div>
            </div>
            
            <nav class="main-nav">
                <ul>
                    <li><a href="student_dashboard.php"><?php echo t('home'); ?></a></li>
                    <li><a href="student_face_attendance.php"><?php echo t('sign_attendance'); ?></a></li>
                    <li><a href="student_change_password.php"><?php echo t('change_password'); ?></a></li>
                    <li><a href="student_attendance_records.php"><?php echo t('attendance_records'); ?></a></li>
                    <li>
                        <a href="student_notifications.php" class="notification-link">
                            <?php echo t('recent_notifications'); ?>
                            <?php if ($unreadCount > 0): ?>
                                <span class="notification-badge" id="notificationBadge"><?php echo $unreadCount; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                </ul>
            </nav>
            
            <div style="display: flex; align-items: center;">
                <!-- Updated Language Switcher -->
                <div class="language-switcher">
                    <?php foreach ($available_languages as $code => $name): ?>
                        <a href="?lang=<?php echo $code; ?>" class="<?php echo $current_lang === $code ? 'active' : ''; ?>">
                            <?php echo $name; ?>
                        </a>
                    <?php endforeach; ?>
                </div>
                
                <div class="student-badge"><?php echo htmlspecialchars($_SESSION['user']); ?></div>
            </div>
        </div>
    </div>

    <div class="container">
        <!-- Welcome Section -->
        <div class="welcome-section">
            <h2><?php echo t('welcome'); ?>, <?php echo htmlspecialchars($_SESSION['user']); ?>!</h2>
            <p><?php echo t('student_id'); ?>: <?php echo htmlspecialchars($student_id); ?></p>
            <p><?php echo t('account_created'); ?>: <?php echo $accountCreationDate->format('F j, Y'); ?></p>
        </div>

        <!-- Statistics Overview -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?php echo $daysSinceCreation; ?></div>
                <div class="stat-label"><?php echo t('days_since_reg'); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $totalSchoolDays; ?></div>
                <div class="stat-label"><?php echo t('total_school_days'); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $present_days; ?></div>
                <div class="stat-label"><?php echo t('present_days'); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $absent_days; ?></div>
                <div class="stat-label"><?php echo t('absent_days'); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $attendancePercentage; ?>%</div>
                <div class="stat-label"><?php echo t('attendance_rate'); ?></div>
            </div>
        </div>

        <!-- Dashboard Grid -->
        <div class="dashboard-grid">
            <!-- Attendance Signing Card -->
            <div class="dashboard-card">
                <div class="card-header">
                    <div class="card-icon">✓</div>
                    <div class="card-title"><?php echo t('mark_attendance'); ?></div>
                </div>
                
                <a href="student_face_attendance.php" class="btn btn-large" <?php echo !$allow_sign ? 'disabled' : ''; ?>>
                    📝 <?php echo t('sign_attendance'); ?>
                </a>
                
                <?php if ($attendanceMessage): ?>
                    <div class="message <?php echo $messageType; ?>">
                        <?php echo htmlspecialchars($attendanceMessage); ?>
                    </div>
                <?php endif; ?>

                <div class="progress-container">
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: <?php echo $attendancePercentage; ?>%"></div>
                    </div>
                    <div class="progress-text">
                        <?php echo t('attendance_progress'); ?>: <?php echo $attendancePercentage; ?>%
                    </div>
                </div>
            </div>

            <!-- Quick Actions Card -->
            <div class="dashboard-card">
                <div class="card-header">
                    <div class="card-icon">⚙️</div>
                    <div class="card-title"><?php echo t('quick_actions'); ?></div>
                </div>
                
                <a href="student_change_password.php" class="btn btn-secondary" style="width: 100%; margin-bottom: 1rem;">
                    🔒 <?php echo t('change_password'); ?>
                </a>
                
                <form method="POST" action="login.php">
                    <button type="submit" class="btn btn-logout" style="width: 100%;">
                        🚪 <?php echo t('logout'); ?>
                    </button>
                </form>
            </div>

           
                    
               
        </div>
    </div>
    
    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-about">
                <div class="footer-logo">
                    <div class="logo">DDU</div>
                    <span><?php echo t('university_name'); ?></span>
                </div>
                <p><?php echo t('footer_text'); ?></p>
                <p><?php echo t('developed_by'); ?></p>
            </div>
            
            <div class="footer-links">
                <h3><?php echo t('quick_links'); ?></h3>
                <ul>
                    <li><a href="student_dashboard.php"><?php echo t('home'); ?></a></li>
                    <li><a href="#"><?php echo t('contact_us'); ?></a></li>
                    <li><a href="#"><?php echo t('privacy_policy'); ?></a></li>
                    <li><a href="#"><?php echo t('terms_of_service'); ?></a></li>
                </ul>
            </div>
            
            <div class="footer-contact">
                <h3><?php echo t('contact_us'); ?></h3>
                <p><i class="fas fa-map-marker-alt"></i> <?php echo t('address'); ?></p>
                <p><i class="fas fa-phone"></i> <?php echo t('phone'); ?></p>
                <p><i class="fas fa-envelope"></i> <?php echo t('email'); ?></p>
                
                <div class="contact-hours">
                    <p><i class="fas fa-clock"></i> <?php echo t('working_hours'); ?>: 8:00 AM - 5:00 PM (Mon-Fri)</p>
                </div>
                
                <div class="social-media">
                    <h4><?php echo t('follow_us'); ?></h4>
                    <div class="social-icons">
                        <a href="https://www.facebook.com/DireDawaUniversity" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="https://twitter.com/DireDawaUni" target="_blank" rel="noopener noreferrer" aria-label="Twitter">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="https://www.linkedin.com/school/dire-dawa-university" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        <a href="https://www.youtube.com/c/DireDawaUniversity" target="_blank" rel="noopener noreferrer" aria-label="YouTube">
                            <i class="fab fa-youtube"></i>
                        </a>
                        <a href="https://t.me/DireDawaUniversity" target="_blank" rel="noopener noreferrer" aria-label="Telegram">
                            <i class="fab fa-telegram-plane"></i>
                        </a>
                    </div>
                </div>
                
                <div class="emergency-contact">
                    <p><i class="fas fa-exclamation-triangle"></i> <strong><?php echo t('emergency'); ?>:</strong> +251 25 111 1199</p>
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p><?php echo t('copyright'); ?></p>
        </div>
    </footer>
    
    <!-- Scroll to Top Button -->
    <div class="scroll-to-top" id="scrollToTop" title="<?php echo t('scroll_to_top'); ?>">
        <i class="fas fa-arrow-up"></i>
        <span class="tooltip"><?php echo t('scroll_to_top'); ?></span>
    </div>
    
    <script>
        // Auto-hide success messages after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const successMessages = document.querySelectorAll('.message.success');
            successMessages.forEach(function(message) {
                setTimeout(function() {
                    message.style.opacity = '0';
                    message.style.transform = 'translateY(-20px)';
                    setTimeout(function() {
                        message.style.display = 'none';
                    }, 300);
                }, 5000);
            });

            // Start checking for new notifications
            checkForNewNotifications();
            setInterval(checkForNewNotifications, 30000); // Check every 30 seconds
        });

        // Function to check for new notifications
        function checkForNewNotifications() {
            fetch('check_notifications.php')
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    const badge = document.getElementById('notificationBadge');
                    const notificationLink = document.querySelector('.notification-link');
                    
                    if (data.unreadCount > 0) {
                        if (!badge) {
                            // Create badge if it doesn't exist
                            const newBadge = document.createElement('span');
                            newBadge.id = 'notificationBadge';
                            newBadge.className = 'notification-badge';
                            newBadge.textContent = data.unreadCount;
                            notificationLink.appendChild(newBadge);
                            
                            // Add pulse animation to highlight new notification
                            notificationLink.style.animation = 'none';
                            setTimeout(() => {
                                notificationLink.style.animation = 'pulse 1s 2';
                            }, 10);
                        } else if (badge.textContent != data.unreadCount) {
                            // Update existing badge if count changed
                            badge.textContent = data.unreadCount;
                            
                            // Add pulse animation to highlight new notification
                            notificationLink.style.animation = 'none';
                            setTimeout(() => {
                                notificationLink.style.animation = 'pulse 1s 2';
                            }, 10);
                        }
                    } else if (badge) {
                        // Remove badge if no unread notifications
                        badge.remove();
                    }
                })
                .catch(error => console.error('Error checking notifications:', error));
        }

        function toggleDropdown() {
            document.getElementById('dropdownMenu').parentElement.classList.toggle('show');
        }
        
        function showNotifications() {
            document.querySelector('.notifications').scrollIntoView({
                behavior: 'smooth'
            });
            
            document.getElementById('dropdownMenu').parentElement.classList.remove('show');
            
            const notifications = document.querySelector('.notifications');
            notifications.style.animation = 'none';
            setTimeout(() => {
                notifications.style.animation = 'pulse 1s 2';
            }, 10);
        }
        
        // Close dropdown when clicking outside
        window.onclick = function(event) {
            if (!event.target.matches('.dropdown-toggle')) {
                const dropdowns = document.getElementsByClassName("dropdown");
                for (let i = 0; i < dropdowns.length; i++) {
                    const openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');
                    }
                }
            }
        }
        
        // Scroll to top functionality
        const scrollToTopBtn = document.getElementById('scrollToTop');
        
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                scrollToTopBtn.classList.add('active');
            } else {
                scrollToTopBtn.classList.remove('active');
            }
        });
        
        scrollToTopBtn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    </script>
</body>
</html>