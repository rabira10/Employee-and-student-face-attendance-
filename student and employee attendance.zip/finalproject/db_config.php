<?php
// Database configuration - XAMPP DEFAULT CREDENTIALS
$servername = "localhost";
$dbname = "ddu_attendance"; // Make sure this database exists
$db_username = "root";      // XAMPP default username
$db_password = "";          // XAMPP default is empty password

// Test function
function test_db_connection() {
    global $servername, $dbname, $db_username, $db_password;
    
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $db_username, $db_password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return "Connection successful!";
    } catch(PDOException $e) {
        return "Connection failed: " . $e->getMessage();
    }
}

// Uncomment to test immediately
// echo test_db_connection(); exit();
?>