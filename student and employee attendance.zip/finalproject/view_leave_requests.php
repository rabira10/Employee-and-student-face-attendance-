<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'employee') {
    header("Location: employee_login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['user'];

// Use request_date for ordering
$stmt = $conn->prepare("SELECT start_date, end_date, reason, status FROM leave_requests WHERE username = ? ORDER BY request_date DESC");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>View Leave Requests - Dire Dawa University</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f4f8;
            color: #003366; /* dark blue */
            margin: 20px;
        }
        h2 {
            color: #004080; /* university blue */
            text-align: center;
            margin-bottom: 25px;
        }
        table {
            border-collapse: collapse;
            width: 90%;
            max-width: 900px;
            margin: 0 auto 30px auto;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #ffcc00; /* university yellow */
            color: #003366; /* dark blue text */
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        tr:hover {
            background-color: #e6f0ff; /* light blue highlight */
        }
        .status-approved {
            color: #006600; /* dark green */
            font-weight: bold;
        }
        .status-rejected {
            color: #cc0000; /* strong red */
            font-weight: bold;
        }
        .status-pending {
            color: #e67e22; /* orange */
            font-weight: bold;
        }
        p {
            text-align: center;
        }
        a {
            color: #004080;
            text-decoration: none;
            font-weight: bold;
            border: 2px solid #004080;
            padding: 8px 16px;
            border-radius: 6px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        a:hover {
            background-color: #004080;
            color: #ffcc00;
        }
    </style>
</head>
<body>
    <h2>Your Leave Requests</h2>
    <table>
        <thead>
            <tr>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Reason</th>
                <th>HR Decision</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()):
                $status = strtolower($row['status']);
                $class = '';
                if ($status === 'approved') $class = 'status-approved';
                else if ($status === 'rejected') $class = 'status-rejected';
                else if ($status === 'pending') $class = 'status-pending';
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['start_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['end_date']); ?></td>
                    <td><?php echo nl2br(htmlspecialchars($row['reason'])); ?></td>
                    <td class="<?php echo $class; ?>"><?php echo ucfirst($status); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <p><a href="dashboard_employee.php">Back to Dashboard</a></p>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
