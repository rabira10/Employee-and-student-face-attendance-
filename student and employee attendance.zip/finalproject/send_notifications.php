<?php
session_start();
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$username = $_SESSION['user'];
$role = $_SESSION['role'];
$notifications = [];
$students = [];
$message = '';
$error = '';

// Handle delete requests (for dean)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $role === 'student_dean') {
    if (isset($_POST['delete_id'])) {
        $delete_id = intval($_POST['delete_id']);
        $stmt = $conn->prepare("DELETE FROM notifications WHERE id = ?");
        $stmt->bind_param("i", $delete_id);
        if ($stmt->execute()) {
            $message = "Notification deleted successfully.";
        } else {
            $error = "Failed to delete notification.";
        }
        $stmt->close();
    } elseif (isset($_POST['delete_all'])) {
        $stmt = $conn->prepare("DELETE FROM notifications");
        if ($stmt->execute()) {
            $message = "All notifications deleted successfully.";
        } else {
            $error = "Failed to delete all notifications.";
        }
        $stmt->close();
    }
}

// Fetch active students (for dean)
if ($role === 'student_dean') {
    $query = "SELECT username, full_name FROM users WHERE role = 'student' AND is_active = 1 
              UNION 
              SELECT username, full_name FROM students WHERE status = 1 
              ORDER BY full_name";
    $result = $conn->query($query);

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $students[$row['username']] = $row['full_name'];
        }
    }
}

// Handle send notification (for dean)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $role === 'student_dean' && isset($_POST['student_username']) && isset($_POST['message']) && !isset($_POST['delete_id']) && !isset($_POST['delete_all'])) {
    $student_username = $_POST['student_username'] ?? '';
    $msg = trim($_POST['message'] ?? '');

    if (empty($msg)) {
        $error = "Message cannot be empty.";
    } elseif (empty($student_username)) {
        $error = "Please select a student or 'All Students'.";
    } else {
        if ($student_username === 'all') {
            // For "All Students", create one notification with target_role='all'
            $stmt = $conn->prepare("INSERT INTO notifications (username, message, is_read, created_at, status, target_role) 
                                  VALUES ('', ?, 0, NOW(), 'unread', 'all')");
            if ($stmt) {
                $stmt->bind_param("s", $msg);
                if ($stmt->execute()) {
                    $message = "Notification sent to all students successfully.";
                } else {
                    $error = "Failed to send notification to all students: " . $conn->error;
                }
                $stmt->close();
            }
        } else {
            // For individual students
            if (array_key_exists($student_username, $students)) {
                $stmt = $conn->prepare("INSERT INTO notifications (username, message, is_read, created_at, status, target_role) 
                                      VALUES (?, ?, 0, NOW(), 'unread', 'individual')");
                if ($stmt) {
                    $stmt->bind_param("ss", $student_username, $msg);
                    if ($stmt->execute()) {
                        $message = "Notification sent successfully to: " . htmlspecialchars($students[$student_username]);
                    } else {
                        $error = "Failed to send notification. Error: " . $conn->error;
                    }
                    $stmt->close();
                }
            } else {
                $error = "Selected student not found in records.";
            }
        }
    }
}

// Get notifications for the current user
if ($role === 'student') {
    $query = "
        SELECT 
            n.id,
            n.message,
            n.is_read,
            n.created_at,
            n.status,
            n.target_role,
            IFNULL(u.full_name, 'System') AS sender_name
        FROM notifications n
        LEFT JOIN users u ON n.username = u.username
        WHERE (n.username = ? AND n.target_role = 'individual') 
           OR (n.target_role = 'all')
        ORDER BY n.created_at DESC
        LIMIT 50";
    
    $stmt = $conn->prepare($query);
    if ($stmt) {
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $notifications = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    }

    // Mark unread notifications as read
    if (!empty($notifications)) {
        $update_query = "UPDATE notifications SET is_read = 1 
                        WHERE (username = ? AND target_role = 'individual' AND is_read = 0)
                           OR (target_role = 'all' AND is_read = 0)";
        
        $update_stmt = $conn->prepare($update_query);
        if ($update_stmt) {
            $update_stmt->bind_param("s", $username);
            $update_stmt->execute();
            $update_stmt->close();
        }
    }
}

// Fetch all sent notifications (for dean)
if ($role === 'student_dean') {
    $notif_query = "SELECT 
                        n.id, 
                        n.username, 
                        n.message, 
                        n.created_at,
                        n.target_role,
                        IF(n.target_role = 'all', 'All Students', 
                          IFNULL(u.full_name, IFNULL(s.full_name, n.username))
                        ) AS recipient_name
                    FROM notifications n
                    LEFT JOIN users u ON n.username = u.username
                    LEFT JOIN students s ON n.username = s.username
                    ORDER BY n.created_at DESC";
    $notif_result = $conn->query($notif_query);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title><?= $role === 'student_dean' ? 'Send Notification' : 'My Notifications' ?> | DDU</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .notification.unread {
            background-color: #f0f9ff;
            border-left: 4px solid #3b82f6;
        }
        .notification.important {
            border-left: 4px solid #ef4444;
        }
        .recipient-badge {
            display: inline-block;
            padding: 0.2rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.75rem;
            font-weight: 600;
            margin-left: 0.5rem;
        }
        .badge-individual {
            background-color: #e0f2fe;
            color: #0369a1;
        }
        .badge-all {
            background-color: #dcfce7;
            color: #166534;
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto px-4 py-8">
        <!-- Error/Success Messages -->
        <?php if (!empty($message)): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6">
                <p><?= htmlspecialchars($message) ?></p>
            </div>
        <?php endif; ?>
        <?php if (!empty($error)): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6">
                <p><?= htmlspecialchars($error) ?></p>
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold text-gray-800">
                <?= $role === 'student_dean' ? 'Send Notifications' : 'My Notifications' ?>
            </h1>
            <div class="flex items-center space-x-4">
                <span class="text-gray-600"><?= htmlspecialchars($username) ?> (<?= $role === 'student_dean' ? 'Dean' : 'Student' ?>)</span>
                <a href="<?= $role === 'student_dean' ? 'dean_dashboard.php' : 'student_dashboard.php' ?>" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition">
                    <i class="fas fa-arrow-left mr-2"></i> Dashboard
                </a>
            </div>
        </div>

        <?php if ($role === 'student_dean'): ?>
            <!-- Dean's Notification Sending Interface -->
            <div class="bg-white rounded-lg shadow-md p-6 mb-8">
                <form method="POST" action="">
                    <div class="mb-4">
                        <label for="student_username" class="block text-gray-700 font-bold mb-2">Select Recipient:</label>
                        <select name="student_username" id="student_username" class="w-full p-2 border rounded" required>
                            <option value="">-- Select a recipient --</option>
                            <option value="all" <?= (isset($_POST['student_username']) && $_POST['student_username'] === 'all') ? 'selected' : '' ?>>All Students</option>
                            <?php foreach ($students as $username => $full_name): ?>
                                <option value="<?= htmlspecialchars($username) ?>" <?= (isset($_POST['student_username']) && $_POST['student_username'] === $username) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($full_name . " ($username)") ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-4">
                        <label for="message" class="block text-gray-700 font-bold mb-2">Notification Message:</label>
                        <textarea name="message" id="message" class="w-full p-2 border rounded" rows="5" required><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
                    </div>
                    <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded">
                        Send Notification
                    </button>
                </form>
            </div>

            <!-- Dean's Sent Notifications List -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-bold text-gray-800">Sent Notifications</h2>
                    <form method="POST" onsubmit="return confirm('Are you sure you want to delete ALL notifications?');">
                        <input type="hidden" name="delete_all" value="1">
                        <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-sm">
                            Delete All
                        </button>
                    </form>
                </div>
                
                <?php if ($notif_result && $notif_result->num_rows > 0): ?>
                    <div class="space-y-4">
                        <?php while ($notif = $notif_result->fetch_assoc()): ?>
                            <div class="border rounded p-4">
                                <div class="flex justify-between items-start mb-2">
                                    <div>
                                        <span class="font-bold">To: <?= htmlspecialchars($notif['recipient_name']) ?></span>
                                        <span class="recipient-badge <?= $notif['target_role'] === 'all' ? 'badge-all' : 'badge-individual' ?>">
                                            <?= $notif['target_role'] === 'all' ? 'All Students' : 'Individual' ?>
                                        </span>
                                    </div>
                                    <span class="text-sm text-gray-500">
                                        <?= date('M j, Y g:i A', strtotime($notif['created_at'])) ?>
                                    </span>
                                </div>
                                <p class="mb-2"><?= htmlspecialchars($notif['message']) ?></p>
                                <form method="POST" onsubmit="return confirm('Delete this notification?');" class="text-right">
                                    <input type="hidden" name="delete_id" value="<?= $notif['id'] ?>">
                                    <button type="submit" class="text-red-500 hover:text-red-700 text-sm">
                                        <i class="fas fa-trash mr-1"></i> Delete
                                    </button>
                                </form>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center text-gray-500 py-4">
                        <i class="fas fa-inbox text-4xl mb-2 text-gray-300"></i>
                        <p>No notifications sent yet</p>
                    </div>
                <?php endif; ?>
            </div>

        <?php else: ?>
            <!-- Student's Notification Viewing Interface -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center mb-4">
                    <i class="fas fa-bell text-blue-500 text-xl mr-3"></i>
                    <div>
                        <span class="font-medium">
                            <?= count($notifications) ?> notification(s)
                        </span>
                        <?php 
                        $unread_count = array_reduce($notifications, function($carry, $item) {
                            return $carry + ($item['is_read'] ? 0 : 1);
                        }, 0);
                        if ($unread_count > 0): ?>
                            <span class="ml-2 bg-blue-500 text-white text-xs px-2 py-1 rounded-full">
                                <?= $unread_count ?> new
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if (!empty($notifications)): ?>
                    <div class="space-y-4">
                        <?php foreach ($notifications as $notification): ?>
                            <div class="notification border rounded p-4
                                <?= $notification['is_read'] ? '' : 'unread' ?>
                                <?= $notification['status'] === 'important' ? 'important' : '' ?>">
                                
                                <div class="flex justify-between items-start mb-2">
                                    <div class="flex items-center">
                                        <?php if ($notification['status'] === 'important'): ?>
                                            <i class="fas fa-exclamation-circle text-red-500 mr-2"></i>
                                        <?php endif; ?>
                                        <h3 class="font-bold">
                                            <?= htmlspecialchars($notification['message']) ?>
                                            <span class="recipient-badge <?= $notification['target_role'] === 'all' ? 'badge-all' : 'badge-individual' ?>">
                                                <?= $notification['target_role'] === 'all' ? 'All Students' : 'Personal' ?>
                                            </span>
                                        </h3>
                                    </div>
                                    <span class="text-sm text-gray-500">
                                        <?= date('M j, Y g:i A', strtotime($notification['created_at'])) ?>
                                    </span>
                                </div>
                                
                                <div class="text-sm text-gray-500">
                                    From: <?= htmlspecialchars($notification['sender_name']) ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center text-gray-500 py-4">
                        <i class="fas fa-inbox text-4xl mb-2 text-gray-300"></i>
                        <p>No notifications found</p>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Auto-refresh every 5 minutes (300000ms)
        setTimeout(() => {
            window.location.reload();
        }, 300000);
    </script>
</body>
</html>