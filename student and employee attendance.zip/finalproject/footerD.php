    </div> <!-- End container -->

    <footer>
        <p>&copy; <?php echo date('Y'); ?> <?php echo t('dire_dawa_university', $translations); ?>. <?php echo t('all_rights_reserved', $translations); ?></p>
    </footer>

    <script>
        // Auto-hide success messages
        document.addEventListener('DOMContentLoaded', function () {
            const successMessages = document.querySelectorAll('.message.success');
            successMessages.forEach(function (msg) {
                setTimeout(() => {
                    msg.style.opacity = '0';
                    msg.style.transform = 'translateY(-20px)';
                    setTimeout(() => {
                        msg.style.display = 'none';
                    }, 300);
                }, 5000);
            });
        });

        // Form validation example
        const form = document.querySelector('form');
        if (form) {
            form.addEventListener('submit', function (e) {
                const startTime = document.getElementById('start_time')?.value;
                const endTime = document.getElementById('end_time')?.value;

                if (startTime && endTime && startTime >= endTime) {
                    e.preventDefault();
                    alert('<?php echo t("end_time_must_be_after_start_time", $translations); ?>');
                }
            });
        }

        // Mobile dropdown toggle
        document.querySelectorAll('.header-nav-link').forEach(link => {
            link.addEventListener('click', function (e) {
                if (window.innerWidth <= 768) {
                    e.preventDefault();
                    const dropdown = this.nextElementSibling;
                    if (dropdown.style.display === 'block') {
                        dropdown.style.display = 'none';
                    } else {
                        dropdown.style.display = 'block';
                    }
                }
            });
        });
    </script>
</body>
</html>
