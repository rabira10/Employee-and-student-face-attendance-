<?php
session_start();
include 'dbe.php';
require 'check_status.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Language switching logic
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
    header("Location: ".strtok($_SERVER['REQUEST_URI'], '?'));
    exit;
}

$lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : 'en';

// Language strings
$translations = [
    'en' => [
        'title' => 'Admin Dashboard - Dire Dawa University',
        'university_name' => 'Dire Dawa University',
        'portal_name' => 'Administrative Management Portal',
        'admin_badge' => '⚙️ Administrator',
        'nav_users' => '👥 View Users',
        'nav_reports' => '📊 Attendance Reports',
        'nav_manage' => '🔧 Manage Accounts',
        'nav_export' => '📋 Export Data',
        'nav_logout' => '🚪 Logout',
        'stats_total_users' => 'Total Users',
        'stats_active_users' => 'Active Users',
        'stats_inactive_users' => 'Inactive Users',
        'stats_employees' => 'Employees',
        'stats_hr' => 'HR Officers',
        'section_users' => 'Registered Users',
        'section_reports' => 'Attendance Reports',
        'section_manage' => 'Manage User Accounts',
        'section_export' => 'Export Attendance Data',
        'table_name' => 'Full Name',
        'table_username' => 'Username',
        'table_role' => 'Role',
        'table_status' => 'Status',
        'table_actions' => 'Actions',
        'status_active' => 'Active',
        'status_inactive' => 'Inactive',
        'action_deactivate' => '🚫 Deactivate',
        'action_activate' => '✅ Activate',
        'label_date' => 'Select Date:',
        'button_view' => '📈 View Report',
        'button_add' => '➕ Add New User',
        'button_update' => '✏️ Update User',
        'button_delete' => '🗑️ Delete User',
        'label_range' => 'Select Range:',
        'option_daily' => '📅 Daily',
        'option_weekly' => '📊 Weekly',
        'option_monthly' => '📈 Monthly',
        'button_export_excel' => '📊 Export Excel',
        'button_export_word' => '📄 Export Word',
        'account_deactivated' => 'Account Deactivated',
        'deactivation_message' => 'Your account has been deactivated by an administrator.',
        'logout_message' => 'You will be logged out automatically.',
        'button_ok' => 'OK',
        'language' => 'Language',
        'quick_links' => 'Quick Links',
        'contact_us' => 'Contact Us',
        'all_rights_reserved' => 'All rights reserved'
    ],
    'am' => [
        'title' => 'የአስተዳዳሪ ዳሽቦርድ - ድሬዳዋ ዩኒቨርሲቲ',
        'university_name' => 'ድሬዳዋ ዩኒቨርሲቲ',
        'portal_name' => 'የአስተዳደር አስተዳደር ፖርታል',
        'admin_badge' => '⚙️ አስተዳዳሪ',
        'nav_users' => '👥 ተጠቃሚዎችን ይተይ',
        'nav_reports' => '📊 የመገኘት ሪፖርቶች',
        'nav_manage' => '🔧 መለያዎችን አስተዳድር',
        'nav_export' => '📋 ውሂብ ወደ �ጪ ላክ',
        'nav_logout' => '🚪 ውጣ',
        'stats_total_users' => 'ጠቅላላ ተጠቃሚዎች',
        'stats_active_users' => 'የሚሰራ አካውንት',
        'stats_inactive_users' => 'የተዘጉ አካውንት',
        'stats_employees' => 'ሰራተኞች',
        'stats_hr' => 'HR ባለሙያዎች',
        'section_users' => 'የተመዘገቡ ተጠቃሚዎች',
        'section_reports' => 'የመገኘት ሪፖርት',
        'section_manage' => 'የተጠቃሚ መለያዎችን አስተዳድር',
        'section_export' => 'የመገኘት ውሂብ �ለ ጪ ላክ',
        'table_name' => 'ሙሉ ስም',
        'table_username' => 'የተጠቃሚ ስም',
        'table_role' => 'ሚና',
        'table_status' => 'ሁኔታ',
        'table_actions' => 'ድርጊቶች',
        'status_active' => 'ንቁ',
        'status_inactive' => 'እንቅልፍ',
        'action_deactivate' => '🚫 ዝጋ',
        'action_activate' => '✅ ክፈት',
        'label_date' => 'ቀን ይምረጡ:',
        'button_view' => '📈 ሪፖርት ይመልከቱ',
        'button_add' => '➕ አዲስ ተጠቃሚ ያክሉ',
        'button_update' => '✏️ ተጠቃሚ �ሻሽሉ',
        'button_delete' => '🗑️ ተጠቃሚ ያስወግዱ',
        'label_range' => 'ክልል ይምረጡ:',
        'option_daily' => '📅 በቀን',
        'option_weekly' => '📊 በሳምንት',
        'option_monthly' => '📈 በወር',
        'button_export_excel' => '📊 �ለ Excel ላክ',
        'button_export_word' => '📄 ወደ Word ላክ',
        'account_deactivated' => 'መለያ ተሰናክሏል',
        'deactivation_message' => 'መለያዎ በአስተዳዳሪ ተሰናክሏል።',
        'logout_message' => 'በራስ-ሰር ከስርዓቱ ይወጣሉ።',
        'button_ok' => 'እሺ',
        'language' => 'ቋንቋ',
        'quick_links' => 'ፈጣን አገናኞች',
        'contact_us' => 'አግኙን',
        'all_rights_reserved' => 'ሁሉም መብቶች የተጠበቁ ናቸው'
    ]
];

function t($key) {
    global $translations, $lang;
    return $translations[$lang][$key] ?? $key;
}
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo t('title'); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #003366 0%, #1a4d6b 100%);
            min-height: 100vh;
            color: #333;
            display: flex;
            flex-direction: column;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideIn {
            from { transform: translateX(-30px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes scaleIn {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        /* Header */
        header {
            background: white;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border-bottom: 4px solid #FFCC00;
            padding: 1.5rem 0;
            animation: slideIn 0.6s ease-out;
            width: 100%;
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .logo {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, #003366, #004080);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.4rem;
            box-shadow: 0 4px 15px rgba(0,51,102,0.3);
        }

        .university-info h1 {
            color: #003366;
            font-size: 2.2rem;
            margin-bottom: 0.3rem;
            font-weight: 700;
        }

        .university-info p {
            color: #666;
            font-size: 1rem;
            font-weight: 500;
        }

        .admin-badge {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
            padding: 0.8rem 1.5rem;
            border-radius: 25px;
            font-weight: bold;
            font-size: 1rem;
            box-shadow: 0 4px 15px rgba(255,204,0,0.3);
        }

        /* Language Button in Header */
        .language-btn {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #003366;
        }

        .language-btn:hover {
            background: white;
            color: #003366;
            transform: scale(1.1);
        }

        /* Navigation */
        nav {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 1rem 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            animation: fadeIn 0.8s ease-out;
            width: 100%;
        }

        .nav-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: center;
            gap: 2rem;
            flex-wrap: wrap;
            width: 100%;
        }

        nav a {
            color: #003366;
            text-decoration: none;
            font-weight: 600;
            padding: 0.8rem 1.5rem;
            border-radius: 25px;
            transition: all 0.3s ease;
            background: rgba(255, 204, 0, 0.1);
            border: 2px solid transparent;
        }

        nav a:hover {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(255,204,0,0.3);
        }

        nav a.logout {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }

        nav a.logout:hover {
            background: #dc3545;
            color: white;
        }

        /* Dropdown styles */
        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: white;
            min-width: 200px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 8px;
            overflow: hidden;
            top: 100%;
            left: 0;
        }

        .dropdown-content a {
            display: block;
            padding: 12px 16px;
            text-decoration: none;
            color: #003366;
            border-bottom: 1px solid #e1e5e9;
            border-radius: 0;
            background: white;
            margin: 0;
        }

        .dropdown-content a:hover {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Main Content */
        main {
            width: 100%;
            padding: 2rem;
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .content-container {
            width: 100%;
            max-width: 1400px;
        }

        section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 2.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            animation: scaleIn 0.7s ease-out;
            width: 100%;
        }

        h2 {
            color: #003366;
            font-size: 1.8rem;
            margin-bottom: 1.5rem;
            font-weight: 700;
            border-bottom: 3px solid #FFCC00;
            padding-bottom: 0.5rem;
            display: inline-block;
        }

        /* Tables */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #e1e5e9;
        }

        th {
            background: linear-gradient(135deg, #003366, #004080);
            color: white;
            font-weight: 600;
            font-size: 1rem;
        }

        td {
            background: white;
            transition: background-color 0.3s ease;
        }

        tr:hover td {
            background: rgba(255, 204, 0, 0.1);
        }

        tr:last-child td {
            border-bottom: none;
        }

        /* Forms */
        form {
            display: flex;
            align-items: end;
            gap: 1rem;
            flex-wrap: wrap;
            margin-top: 1rem;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        label {
            font-weight: 600;
            color: #003366;
            font-size: 1rem;
        }

        input, select {
            padding: 0.8rem;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: white;
            min-width: 150px;
        }

        input:focus, select:focus {
            outline: none;
            border-color: #FFCC00;
            box-shadow: 0 0 0 3px rgba(255, 204, 0, 0.1);
            transform: translateY(-1px);
        }

        /* Buttons */
        button {
            background: linear-gradient(135deg, #003366, #004080);
            color: white;
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 8px;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,51,102,0.3);
        }

        button:hover {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(255,204,0,0.4);
        }

        .button-group {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            margin-top: 1rem;
        }

        .button-group button {
            flex: 1;
            min-width: 150px;
        }

        /* Special button styles */
        .btn-add {
            background: linear-gradient(135deg, #28a745, #20c997);
        }

        .btn-add:hover {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
        }

        .btn-update {
            background: linear-gradient(135deg, #007bff, #0056b3);
        }

        .btn-update:hover {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
        }

        .btn-delete {
            background: linear-gradient(135deg, #dc3545, #c82333);
        }

        .btn-delete:hover {
            background: linear-gradient(135deg, #ff6b6b, #ff5252);
            color: white;
        }

        .btn-export {
            background: linear-gradient(135deg, #6f42c1, #5a3a9a);
        }

        .btn-export:hover {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 15px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 45px rgba(0,0,0,0.15);
        }

        .stat-icon {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }

        .stat-number {
            font-size: 1.8rem;
            font-weight: bold;
            color: #003366;
            margin-bottom: 0.3rem;
        }

        .stat-label {
            color: #666;
            font-size: 0.9rem;
            font-weight: 500;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }

            .nav-content {
                flex-direction: column;
                gap: 0.5rem;
            }

            main {
                padding: 1rem;
            }

            section {
                padding: 1.5rem;
            }

            .university-info h1 {
                font-size: 1.8rem;
            }

            form {
                flex-direction: column;
                align-items: stretch;
            }

            .button-group {
                flex-direction: column;
            }

            table {
                font-size: 0.9rem;
            }

            th, td {
                padding: 0.5rem;
            }

            /* Adjust dropdown for mobile */
            .dropdown-content {
                position: static;
                width: 100%;
                box-shadow: none;
            }
        }
        
        /* Additional styles for notifications */
        .notification {
            padding: 1rem 1.5rem;
            margin-bottom: 1rem;
            border-radius: 10px;
            font-weight: 600;
            animation: slideIn 0.5s ease-out;
            width: 100%;
            max-width: 1400px;
        }
        
        .notification.success {
            background: linear-gradient(135deg, #d4edda, #c3e6cb);
            color: #155724;
            border-left: 4px solid #28a745;
        }
        
        .notification.error {
            background: linear-gradient(135deg, #f8d7da, #f5c6cb);
            color: #721c24;
            border-left: 4px solid #dc3545;
        }

        /* Status badges */
        .status-badge {
            padding: 0.3rem 0.8rem;
            border-radius: 15px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .status-active {
            background: linear-gradient(135deg, #d4edda, #c3e6cb);
            color: #155724;
        }

        .status-inactive {
            background: linear-gradient(135deg, #f8d7da, #f5c6cb);
            color: #721c24;
        }

        /* Action buttons in table */
        .action-btn {
            padding: 0.4rem 0.8rem;
            font-size: 0.85rem;
            margin: 0 0.2rem;
            min-width: auto;
        }
        
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        
        .modal-content {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            max-width: 500px;
            width: 90%;
            text-align: center;
        }
        
        .modal h3 {
            margin-bottom: 1rem;
            color: #003366;
        }
        
        .modal p {
            margin-bottom: 1.5rem;
        }
        
        .modal button {
            padding: 0.8rem 1.5rem;
        }

        /* Footer styles */
        footer {
            background: linear-gradient(135deg, #002244 0%, #003366 100%);
            color: white;
            padding: 2rem 0;
            margin-top: auto;
            border-top: 4px solid #FFCC00;
            width: 100%;
        }

        .footer-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
        }

        .footer-column h3 {
            color: #FFCC00;
            margin-bottom: 1rem;
            font-size: 1.3rem;
        }

        .footer-column p {
            line-height: 1.6;
            opacity: 0.9;
        }

        .footer-column ul {
            list-style: none;
            line-height: 2;
        }

        .footer-column a {
            color: white;
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-column a:hover {
            color: #FFCC00;
        }

        .footer-bottom {
            text-align: center;
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 1px solid rgba(255,255,255,0.1);
            font-size: 0.9rem;
            opacity: 0.8;
        }

        @media (max-width: 768px) {
            .footer-content {
                grid-template-columns: 1fr;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="header-content">
            <div class="logo-section">
                <div class="logo">
                    <img src="images/ddu.jfif" alt="DDU Logo" style="width: 100%; height: 100%; object-fit: contain; border-radius: 50%;">
                </div>
                <div class="university-info">
                    <h1><?php echo t('university_name'); ?></h1>
                    <p><?php echo t('portal_name'); ?></p>
                </div>
            </div>
            
            <!-- Language Switcher + Admin Badge Container -->
            <div style="display: flex; align-items: center; gap: 10px;">
                <!-- Language Switcher -->
                <button class="language-btn" onclick="toggleLanguage()" title="<?php echo t('language'); ?>">
                    <?php echo $lang === 'en' ? 'አማ' : 'EN'; ?>
                </button>
                
                <!-- Admin Badge -->
                <div class="admin-badge">
                    <?php echo t('admin_badge'); ?>
                </div>
            </div>
        </div>
    </header>

    <!-- Navigation -->
    <nav>
        <div class="nav-content">
            <a href="#viewUsers"><?php echo t('nav_users'); ?></a>
            <div class="dropdown">
                <a href="#manageAccounts" class="dropdown-toggle"><?php echo t('nav_manage'); ?></a>
                <div class="dropdown-content">
                    <a href="add_user.php"><?php echo t('button_add'); ?></a>
                    <a href="update_user.php"><?php echo t('button_update'); ?></a>
                    <a href="delete_user.php"><?php echo t('button_delete'); ?></a>
                </div>
            </div>
            <a href="login.php" class="logout"><?php echo t('nav_logout'); ?></a>
        </div>
    </nav>

    <main>
        <div class="content-container">
            <!-- Notification Messages -->
            <?php if (isset($_SESSION['success'])): ?>
                <div class="notification success">
                    ✅ <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="notification error">
                    ❌ <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                </div>
            <?php endif; ?>

            <!-- Statistics Overview -->
            <div class="stats-grid">
                <?php
                $total_users = $conn->query("SELECT COUNT(*) as total FROM users")->fetch_assoc()['total'];
                $active_users = $conn->query("SELECT COUNT(*) as total FROM users WHERE is_active = 1")->fetch_assoc()['total'];
                $inactive_users = $total_users - $active_users;
                $total_employees = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'employee'")->fetch_assoc()['total'];
                $total_hr = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'hr'")->fetch_assoc()['total'];
                ?>
                <div class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div class="stat-number"><?php echo $total_users; ?></div>
                    <div class="stat-label"><?php echo t('stats_total_users'); ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">✅</div>
                    <div class="stat-number"><?php echo $active_users; ?></div>
                    <div class="stat-label"><?php echo t('stats_active_users'); ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">🚫</div>
                    <div class="stat-number"><?php echo $inactive_users; ?></div>
                    <div class="stat-label"><?php echo t('stats_inactive_users'); ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">👨‍💼</div>
                    <div class="stat-number"><?php echo $total_employees; ?></div>
                    <div class="stat-label"><?php echo t('stats_employees'); ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">👔</div>
                    <div class="stat-number"><?php echo $total_hr; ?></div>
                    <div class="stat-label"><?php echo t('stats_hr'); ?></div>
                </div>
            </div>

            <section id="viewUsers">
                <h2><?php echo t('section_users'); ?></h2>
                <?php
                $result = $conn->query("SELECT full_name, username, role, is_active FROM users ORDER BY role, full_name");
                echo "<table><tr><th>".t('table_name')."</th><th>".t('table_username')."</th><th>".t('table_role')."</th><th>".t('table_status')."</th><th>".t('table_actions')."</th></tr>";
                while ($row = $result->fetch_assoc()) {
                    $role_icon = $row['role'] == 'admin' ? '⚙️' : ($row['role'] == 'hr' ? '👔' : '👨‍💼');
                    $status = $row['is_active'] ? 
                        "<span class='status-badge status-active'>".t('status_active')."</span>" : 
                        "<span class='status-badge status-inactive'>".t('status_inactive')."</span>";
                    
                    $action_btn = $row['is_active'] ? 
                        "<button class='action-btn btn-delete' onclick='toggleUserStatus(\"{$row['username']}\", \"deactivate\")'>".t('action_deactivate')."</button>" :
                        "<button class='action-btn btn-add' onclick='toggleUserStatus(\"{$row['username']}\", \"activate\")'>".t('action_activate')."</button>";
                    
                    echo "<tr>
                        <td>{$role_icon} {$row['full_name']}</td>
                        <td>{$row['username']}</td>
                        <td>" . ucfirst($row['role']) . "</td>
                        <td>{$status}</td>
                        <td>{$action_btn}</td>
                    </tr>";
                }
                echo "</table>";
                ?>
            </section>

            <section id="manageAccounts">
                <h2><?php echo t('section_manage'); ?></h2>
                <div class="button-group">
                    <button class="btn-add" onclick="location.href='add_user.php'"><?php echo t('button_add'); ?></button>
                    <button class="btn-update" onclick="location.href='update_user.php'"><?php echo t('button_update'); ?></button>
                    <button class="btn-delete" onclick="location.href='delete_user.php'"><?php echo t('button_delete'); ?></button>
                </div>
            </section>
        </div>
    </main>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-column">
                <h3><?php echo t('university_name'); ?></h3>
                <p>Dire Dawa, Ethiopia<br>
                P.O.Box: 1362<br>
                Phone: +251 25 111 1234</p>
            </div>
            
            <div class="footer-column">
                <h3><?php echo t('quick_links'); ?></h3>
                <ul>
                    <li><a href="https://www.ddu.edu.et">University Website</a></li>
                    <li><a href="#">Help Center</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                </ul>
            </div>
            
            <div class="footer-column">
                <h3><?php echo t('contact_us'); ?></h3>
                <p>Email: admin@ddu.edu.et<br>
                IT Support: itsupport@ddu.edu.et<br>
                HR Department: hr@ddu.edu.et</p>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> <?php echo t('university_name'); ?>. <?php echo t('all_rights_reserved'); ?></p>
        </div>
    </footer>

    <script>
        function toggleUserStatus(username, action) {
            if (confirm(`Are you sure you want to ${action} user "${username}"?`)) {
                // Create a form and submit it
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'toggle_user_status.php';
                
                const usernameInput = document.createElement('input');
                usernameInput.type = 'hidden';
                usernameInput.name = 'username';
                usernameInput.value = username;
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = action;
                
                form.appendChild(usernameInput);
                form.appendChild(actionInput);
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        function toggleLanguage() {
            const currentLang = '<?php echo $lang; ?>';
            const newLang = currentLang === 'en' ? 'am' : 'en';
            window.location.href = `?lang=${newLang}`;
        }
        
        // Check account status every 30 seconds
        setInterval(checkAccountStatus, 30000);

        function checkAccountStatus() {
            fetch('check_status.php')
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'deactivated') {
                        showDeactivationModal();
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        function showDeactivationModal() {
            // Create modal HTML
            const modalHTML = `
            <div class="modal" id="deactivationModal" style="display:block">
                <div class="modal-content">
                    <h3><?php echo t('account_deactivated'); ?></h3>
                    <p><?php echo t('deactivation_message'); ?></p>
                    <p><?php echo t('logout_message'); ?></p>
                    <button onclick="logout()"><?php echo t('button_ok'); ?></button>
                </div>
            </div>
            `;
            
            // Add to body
            document.body.insertAdjacentHTML('beforeend', modalHTML);
            
            // Auto logout after 5 seconds
            setTimeout(logout, 5000);
        }

        function logout() {
            window.location.href = 'login.php';
        }

        // Dropdown functionality
        document.addEventListener('DOMContentLoaded', function() {
            const dropdowns = document.querySelectorAll('.dropdown');
            
            dropdowns.forEach(dropdown => {
                const toggle = dropdown.querySelector('.dropdown-toggle');
                const content = dropdown.querySelector('.dropdown-content');
                
                toggle.addEventListener('click', function(e) {
                    e.preventDefault();
                    content.style.display = content.style.display === 'block' ? 'none' : 'block';
                });
                
                // Close when clicking outside
                document.addEventListener('click', function(e) {
                    if (!dropdown.contains(e.target)) {
                        content.style.display = 'none';
                    }
                });
            });
        });
    </script>
</body>
</html>