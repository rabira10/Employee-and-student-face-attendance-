<?php
session_start();
include 'dbe.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// Check if user is still active
$stmt = $conn->prepare("SELECT is_active FROM users WHERE username = ?");
$stmt->bind_param("s", $_SESSION['user']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0 || !$result->fetch_assoc()['is_active']) {
    session_destroy();
    header("Location: login.php?message=account_deactivated");
    exit;
}
?>