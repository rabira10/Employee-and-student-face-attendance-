<?php
return [
    // Header & General
    'student_dean_dashboard' => 'የተማሪ ዲን ዳሽቦርድ',
    'dire_dawa_university' => 'ድሬ ዳዋ ዩኒቨርሲቲ',
    'student_dean_portal' => 'የተማሪ ዲን ፖርታል',
    'student_dean' => 'የተማሪ ዲን',
    
    'welcome_student_dean' => '🎓 እንኳን ደህና መጡ ፣ የተማሪዎች ዳኛ!',
    'welcome_message' => 'ይህ የደሬ ዳዋ ዩኒቨርሲቲ የተማሪዎች ዳኛ መስክ ነው። እዚህ ተማሪዎችን መቆጣጠር፣ የትምህርት አፈጻጸምን ማረጋገጥ እና የማበረታታ አካባቢ መፍጠር ትችላለህ። ለመሪነትዎ እናመሰግናለን!',
    
    // Navigation
    'student_management' => 'የተማሪ አስተዳደር',
    'student_management_options' => 'የተማሪ አስተዳደር አማራጮች',
    'view_all_students' => 'ሁሉንም ተማሪዎች ይመልከቱ',
    'attendance_reports' => 'የመገኘት ሪፖርቶች',
    'download_reports' => 'ሪፖርቶችን ያውርዱ',
    'send_notifications' => 'ማስታወቂያዎችን ላክ',
    'manage_accounts' => 'መለያዎችን አስተዳድር',
    'register_student' => 'ተማሪ ይመዝገቡ',
    'quick_actions' => 'ፈጣን እርምጃዎች',
    'quick_actions_menu' => 'ፈጣን እርምጃዎች ምናሌ',
    
    // Attendance
    'attendance_time_window' => 'የመገኘት ጊዜ መስኮት',
    'current_settings' => 'አሁን ያሉት ማቀናበሪያዎች',
    'start_time' => 'የመጀመሪያ ጊዜ',
    'end_time' => 'የመጨረሻ ጊዜ',
    'save_attendance_time' => 'የመገኘት ጊዜ አስቀምጥ',
    'end_time_must_be_after_start_time' => 'የመጨረሻ ጊዜ ከመጀመሪያ ጊዜ በኋላ መሆን አለበት',
    'attendance_time_window_set_successfully' => 'የመገኘት ጊዜ በተሳካ ሁኔታ ተቀምጧል',
    
    // Account
    'change_password' => 'የይለፍ ቃል ቀይር',
    'logout' => 'ውጣ',
    'login' => 'ግባ',
    'profile' => 'መገለጫ',
    
    // Status Messages
    'success' => 'በተሳካ ሁኔታ',
    'error' => 'ስህተት',
    'warning' => 'ማስጠንቀቂያ',
    'info' => 'መረጃ',
    
    // Buttons
    'save' => 'አስቀምጥ',
    'cancel' => 'ይቅር',
    'update' => 'አዘምን',
    'delete' => 'ሰርዝ',
    'edit' => 'አርም',
    'view' => 'ይመልከቱ',
    'search' => 'ፈልግ',
    
    // Days (for reports)
    'monday' => 'ሰኞ',
    'tuesday' => 'ማክሰኞ',
    'wednesday' => 'ረቡዕ',
    'thursday' => 'ሐሙስ',
    'friday' => 'አርብ',
    'saturday' => 'ቅዳሜ',
    'sunday' => 'እሁድ',

   
    'dire_dawa_university' => 'ድሬ ዳዋ ዩኒቨርሲቲ',
    'student_dean_portal' => 'የተማሪዎች ዲን ፖርታል',
    'student_dean' => 'የተማሪዎች ዲን',
    'help_center' => 'የእርዳታ ማዕከል',
    'help_center_description' => 'ለተለመዱ ጥያቄዎች መልሶችን ያግኙ እና የተማሪ ዲን ፖርታልን በብቃት እንዴት መጠቀም እንደሚቻል ይማሩ።',
    'search_help_articles' => 'የእርዳታ ጽሑፎችን ይፈልጉ',
    'help_categories' => 'የእርዳታ ምድቦች',
    'attendance' => 'ተገኝነት',
    'student_management' => 'የተማሪ አስተዳደር',
    'reports' => 'ሪፖርቶች',
    'account_settings' => 'የመለያ ቅንብሮች',
    'frequently_asked_questions' => 'በተደጋጋሚ የሚጠየቁ ጥያቄዎች',
    'how_to_set_attendance_time' => 'የተገኝነት ጊዜን እንዴት ማዘጋጀት ይቻላል?',
    'attendance_time_instructions' => 'ወደ ተገኝነት ክፍል ይሂዱ፣ ኮርሱን ይምረጡ እና ለተገኝነት የጊዜ መስኮት ያዘጋጁ። �ለተለያዩ የሳምንት ቀናት የተለያዩ ጊዜዎችን መግለጽ ይችላሉ።',
    'how_to_generate_reports' => 'ሪፖርቶችን እንዴት ማመንጨት ይቻላል?',
    'report_generation_instructions' => 'ወደ ሪፖርቶች ክፍል ይሂዱ፣ የሚፈልጉትን የሪፖርት አይነት ይምረጡ (ተገኝነት፣ የትምህርት አፈጻጸም፣ ወዘተ)፣ የቀን ክልልን ያዘጋጁ እና ማመንጨት ይጫኑ።',
    'how_to_register_student' => 'አዲስ ተማሪ እንዴት መመዝገብ ይቻላል?',
    'student_registration_instructions' => 'በተማሪ አስተዳደር �ፍል፣ "አዲስ ተማሪ ጨምር" ላይ ጠቅ ያድርጉ፣ ሁሉንም የሚያስፈልጉ መረጃዎችን ይሙሉ እና ያስገቡ። ስርዓቱ የተማሪ የይለፍ ቃላትን በራስ-ሰር ያመነጫል።',
    'how_to_change_password' => 'የይለፍ ቃሌን እንዴት መቀየር እችላለሁ?',
    'password_change_instructions' => 'በላይኛው ቀኝ ጥግ ላይ ያለውን የመገለጫ አዶ ላይ ጠቅ ያድርጉ፣ "የመለያ ቅንብሮች"ን ይምረጡ፣ ከዚያም "የይለፍ ቃል ቀይር"። የአሁኑን የይለፍ ቃልዎን እና አዲሱን የይለፍ ቃል ሁለት ጊዜ ያስገቡ።',
    'still_need_help' => 'አሁንም እርዳታ ይፈልጋሉ?',
    'contact_our_support_team' => 'ለተጨማሪ እርዳታ የእርዳታ ቡድናችንን ያግኙ።',
    'contact_support' => 'እርዳታ ያግኙ',
    'footer_about_text' => 'በትምህርት እና በተማሪ አገልግሎቶች ውስጥ ለልህቀት ቁርጠኛ።',
    'quick_links' => 'ፈጣን አገናኞች',
    'university_website' => 'ዩኒቨርሲቲ ድረ-ገጽ',
    'contact_us' => 'አግኙን',
    'contact_info' => 'የግንኙነት መረጃ',
    'university_address' => 'ፖ.ሳጥን 1362, ድሬ ዳዋ, ኢትዮጵያ',
    'all_rights_reserved' => 'ሁሉም መብቶች የተጠበቁ ናቸው።',

    // Months
    'january' => 'ጃንዩወሪ',
    'february' => 'ፌብሩወሪ',
    'march' => 'ማርች',
    'april' => 'ኤፕሪል',
    'may' => 'ሜይ',
    'june' => 'ጁን',
    'july' => 'ጁላይ',
    'august' => 'ኦገስት',
    'september' => 'ሴፕቴምበር',
    'october' => 'ኦክቶበር',
    'november' => 'ኖቬምበር',
    'december' => 'ዲሴምበር',
    
    // New additions for student management
    'student_id' => 'የተማሪ መለያ',
    'full_name' => 'ሙሉ ስም',
    'department' => 'ዲፓርትመንት',
    'year' => 'ዓመት',
    'semester' => 'ሴሚስተር',
    'status' => 'ሁኔታ',
    'active' => 'ንቁ',
    'inactive' => 'እንቅስቃሴ የለውም',
    'attendance_rate' => 'የመገኘት መጠን',
    'last_login' => 'የመጨረሻ ግባ',
    
    // For forms
    'required_field' => 'ይህ መስክ አስፈላጊ ነው',
    'invalid_email' => 'ትክክል ያልሆነ ኢሜይል',
    'password_mismatch' => 'የይለፍ ቃል አይመሳሰልም'
];