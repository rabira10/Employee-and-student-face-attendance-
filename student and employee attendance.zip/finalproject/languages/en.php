<?php
return [
    'contact_us' => 'Contact Us',
    'dire_dawa_university' => 'Dire Dawa University',
    'contact_us_description' => 'Feel free to reach out to us anytime via email, phone, or visit us at the campus.',
    'email_us' => 'Email Us',
    'call_us' => 'Call Us',
    'working_hours' => 'Working Hours',
    'visit_us' => 'Visit Us',
    'university_address' => '123 University Road, Dire Dawa, Ethiopia',
    'contact_information' => 'Contact Information',
    'email' => 'Email',
    'phone' => 'Phone',
    'address' => 'Address',
];
