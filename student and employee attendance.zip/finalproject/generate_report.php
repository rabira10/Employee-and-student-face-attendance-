<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'hr') {
    header("Location: login.html");
    exit;
}

require 'db.php';

$error = '';
$report = [];
$today = date('Y-m-d');
$minDate = $today;

try {
    $stmtMin = $pdo->query("SELECT MIN(date) AS min_date FROM attendance");
    $resultMin = $stmtMin->fetch(PDO::FETCH_ASSOC);
    if ($resultMin && $resultMin['min_date']) {
        $minDate = $resultMin['min_date'];
    }
} catch (PDOException $e) {
    $error = "Error fetching date range: " . $e->getMessage();
}

$selectedDate = $_POST['report_date'] ?? $today;
$filter = $_POST['report_filter'] ?? 'daily';

if ($selectedDate < $minDate) {
    $error = "Selected date is earlier than the first attendance record ($minDate).";
} elseif ($selectedDate > $today) {
    $error = "Selected date cannot be in the future.";
} else {
    try {
        if ($filter === 'weekly') {
            $start = date('Y-m-d', strtotime($selectedDate . ' -6 days'));
        } elseif ($filter === 'monthly') {
            $start = date('Y-m-01', strtotime($selectedDate));
        } else {
            $start = $selectedDate;
        }

        $stmt = $pdo->prepare("
            SELECT 
                e.username,
                e.full_name AS name,
                SUM(CASE WHEN LOWER(a.status) = 'present' THEN 1 ELSE 0 END) AS present_count,
                SUM(CASE WHEN LOWER(a.status) = 'leave' THEN 1 ELSE 0 END) AS leave_count,
                SUM(CASE 
                    WHEN LOWER(a.status) = 'absent' THEN 1
                    WHEN a.username IS NULL THEN 1
                    ELSE 0 END) AS absent_count
            FROM employees e
            LEFT JOIN attendance a 
                ON e.username = a.username 
                AND a.role = 'employee' 
                AND a.date BETWEEN :start AND :end
            GROUP BY e.username, e.full_name
            ORDER BY e.full_name
        ");
        $stmt->execute(['start' => $start, 'end' => $selectedDate]);
        $report = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $total_present = 0;
        $total_absent = 0;
        $total_leave = 0;

        foreach ($report as $row) {
            $total_present += $row['present_count'];
            $total_absent += $row['absent_count'];
            $total_leave += $row['leave_count'];
        }

    } catch (PDOException $e) {
        $error = "Error generating report: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Attendance Report - Dire Dawa University</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f9f9f9;
      padding: 20px;
      color: #003366;
    }
    h2 {
      color: #003366;
      margin-bottom: 15px;
    }
    form {
      margin-bottom: 20px;
    }
    label {
      font-weight: bold;
      margin-right: 8px;
      color: #003366;
    }
    input[type="date"], select {
      padding: 8px;
      font-size: 15px;
      border-radius: 6px;
      border: 1px solid #003366;
      background-color: #fff;
      color: #003366;
      margin-right: 10px;
    }
    button {
      background-color: #003366;
      color: #FFCC00;
      padding: 10px 20px;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
      margin-right: 10px;
      transition: background-color 0.3s ease, transform 0.2s ease;
    }
    button:hover {
      background-color: #FFCC00;
      color: #003366;
      transform: translateY(-2px);
    }
    button:active {
      transform: translateY(1px);
    }
    table {
      width: 100%;
      border-collapse: collapse;
      background: white;
      box-shadow: 0 0 8px rgba(0,0,0,0.1);
    }
    th, td {
      padding: 12px;
      border: 1px solid #ddd;
      text-align: left;
    }
    th {
      background-color: #003366;
      color: #FFCC00;
    }
    tbody tr:nth-child(even) {
      background-color: #f0f5ff;
    }
    .error {
      color: red;
      margin-bottom: 15px;
      font-weight: bold;
    }
    .container {
      max-width: 900px;
      margin: auto;
      background: white;
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    a {
      color: #003366;
      text-decoration: none;
      font-weight: bold;
    }
    a:hover {
      text-decoration: underline;
    }
    small {
      display: block;
      margin-top: 5px;
      color: #666;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Attendance Report</h2>

    <?php if (!empty($error)): ?>
      <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="post" action="">
      <label for="report_date">Select Date:</label>
      <input 
        type="date" 
        name="report_date" 
        value="<?= htmlspecialchars($selectedDate) ?>" 
        min="<?= htmlspecialchars($minDate) ?>" 
        max="<?= htmlspecialchars($today) ?>" 
        required 
      />

      <label for="report_filter">Filter:</label>
      <select name="report_filter">
        <option value="daily" <?= $filter === 'daily' ? 'selected' : '' ?>>Daily</option>
        <option value="weekly" <?= $filter === 'weekly' ? 'selected' : '' ?>>Weekly</option>
        <option value="monthly" <?= $filter === 'monthly' ? 'selected' : '' ?>>Monthly</option>
      </select>

      <button type="submit">View Report</button>
    </form>

    <form method="post" action="export_excel.php" style="display:inline;">
      <input type="hidden" name="report_date" value="<?= htmlspecialchars($selectedDate) ?>" />
      <input type="hidden" name="report_filter" value="<?= htmlspecialchars($filter) ?>" />
      <button type="submit">Download Excel</button>
    </form>
    <form method="post" action="export_word.php" style="display:inline;">
      <input type="hidden" name="report_date" value="<?= htmlspecialchars($selectedDate) ?>" />
      <input type="hidden" name="report_filter" value="<?= htmlspecialchars($filter) ?>" />
      <button type="submit">Download Word</button>
    </form>
    <form method="post" action="export_pdf.php" style="display:inline;">
      <input type="hidden" name="report_date" value="<?= htmlspecialchars($selectedDate) ?>" />
      <input type="hidden" name="report_filter" value="<?= htmlspecialchars($filter) ?>" />
      <button type="submit">Download PDF</button>
    </form>

    <br><br>

    <table>
      <thead>
        <tr>
          <th>Employee Name</th>
          <th>Present</th>
          <th>Absent</th>
          <th>Leave</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($report)): ?>
          <tr><td colspan="4" style="text-align:center;">No attendance data found.</td></tr>
        <?php else: ?>
          <?php foreach ($report as $row): ?>
            <tr>
              <td><?= htmlspecialchars($row['name']) ?></td>
              <td><?= (int)$row['present_count'] ?></td>
              <td><?= (int)$row['absent_count'] ?></td>
              <td><?= (int)$row['leave_count'] ?></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>

    <?php if (!empty($report)): ?>
      <br>
      <h3 style="color:#003366;">Summary</h3>
      <ul style="font-size: 18px;">
        <li><strong>Total Present:</strong> <?= $total_present ?></li>
        <li><strong>Total Absent:</strong> <?= $total_absent ?></li>
        <li><strong>Total Leave:</strong> <?= $total_leave ?></li>
      </ul>
    <?php endif; ?>

    <p>
      <a href="dashboard_hr.php">&#8592; Back to Dashboard</a>
    </p>
  </div>
</body>
</html>
