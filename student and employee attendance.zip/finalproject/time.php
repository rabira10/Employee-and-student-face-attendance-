<?php
session_start();

// SESSION CHECK for student dean role
if (!isset($_SESSION['user']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'student_dean') {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$msg = '';
$msgType = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $am_start = $_POST['am_start'] ?? '';
    $am_end = $_POST['am_end'] ?? '';
    $pm_start = $_POST['pm_start'] ?? '';
    $pm_end = $_POST['pm_end'] ?? '';
    $active_session = $_POST['active_session'] ?? 'AM';
    $am_enabled = isset($_POST['am_enabled']) ? 1 : 0;
    $pm_enabled = isset($_POST['pm_enabled']) ? 1 : 0;

    if ($am_enabled && $am_start >= $am_end) {
        $msg = "AM start time must be before AM end time.";
        $msgType = 'error';
    } elseif ($pm_enabled && $pm_start >= $pm_end) {
        $msg = "PM start time must be before PM end time.";
        $msgType = 'error';
    } elseif (!in_array($active_session, ['AM', 'PM'])) {
        $msg = "Invalid active session selected.";
        $msgType = 'error';
    } else {
        $res = $conn->query("SELECT id FROM student_attendance_settings LIMIT 1");
        if ($res && $res->num_rows > 0) {
            $stmt = $conn->prepare("UPDATE student_attendance_settings SET am_start=?, am_end=?, pm_start=?, pm_end=?, active_session=?, am_enabled=?, pm_enabled=? WHERE id=(SELECT id FROM student_attendance_settings LIMIT 1)");
            $stmt->bind_param("sssssss", $am_start, $am_end, $pm_start, $pm_end, $active_session, $am_enabled, $pm_enabled);
        } else {
            $stmt = $conn->prepare("INSERT INTO student_attendance_settings (am_start, am_end, pm_start, pm_end, active_session, am_enabled, pm_enabled) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssssss", $am_start, $am_end, $pm_start, $pm_end, $active_session, $am_enabled, $pm_enabled);
        }

        if ($stmt->execute()) {
            $msg = "Attendance settings saved successfully.";
            $msgType = 'success';
        } else {
            $msg = "Database error: " . $conn->error;
            $msgType = 'error';
        }
    }
}

// Fetch settings
$res = $conn->query("SELECT * FROM student_attendance_settings LIMIT 1");
$settings = $res && $res->num_rows > 0 ? $res->fetch_assoc() : [];

$am_start = $settings['am_start'] ?? '08:00:00';
$am_end = $settings['am_end'] ?? '10:00:00';
$pm_start = $settings['pm_start'] ?? '13:00:00';
$pm_end = $settings['pm_end'] ?? '15:00:00';
$active_session = $settings['active_session'] ?? 'AM';
$am_enabled = isset($settings['am_enabled']) ? (bool)$settings['am_enabled'] : true;
$pm_enabled = isset($settings['pm_enabled']) ? (bool)$settings['pm_enabled'] : true;

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Set Attendance Time Window - Student Dean</title>
<style>
    body { font-family: Arial; background: #f9f9f9; padding: 20px; }
    .container { max-width: 400px; margin: auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px #ccc; }
    h2 { text-align: center; color: #003366; }
    label { display: block; margin-top: 15px; font-weight: bold; }
    input[type="time"], select { width: 100%; padding: 8px; margin-top: 5px; border: 1px solid #ccc; border-radius: 4px; }
    button { margin-top: 20px; width: 100%; padding: 12px; background: #003366; color: white; border: none; border-radius: 6px; }
    button:hover { background: #00509e; }
    .message { margin-top: 20px; padding: 12px; border-radius: 6px; }
    .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    .back-btn {
        display: inline-block;
        margin-top: 15px;
        text-align: center;
        width: 100%;
        padding: 12px;
        background: #007bff;
        color: white;
        border-radius: 6px;
        text-decoration: none;
        font-weight: bold;
    }
    .back-btn:hover {
        background: #0056b3;
    }
</style>
</head>
<body>

<div class="container">
    <h2>Set Attendance Time Window</h2>

    <?php if ($msg): ?>
        <div class="message <?php echo $msgType === 'success' ? 'success' : 'error'; ?>">
            <?php echo htmlspecialchars($msg); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <label><input type="checkbox" name="am_enabled" <?php echo $am_enabled ? 'checked' : ''; ?>> Enable AM Session</label>
        <label for="am_start">AM Start Time</label>
        <input type="time" id="am_start" name="am_start" value="<?php echo htmlspecialchars($am_start); ?>">

        <label for="am_end">AM End Time</label>
        <input type="time" id="am_end" name="am_end" value="<?php echo htmlspecialchars($am_end); ?>">

        <label><input type="checkbox" name="pm_enabled" <?php echo $pm_enabled ? 'checked' : ''; ?>> Enable PM Session</label>
        <label for="pm_start">PM Start Time</label>
        <input type="time" id="pm_start" name="pm_start" value="<?php echo htmlspecialchars($pm_start); ?>">

        <label for="pm_end">PM End Time</label>
        <input type="time" id="pm_end" name="pm_end" value="<?php echo htmlspecialchars($pm_end); ?>">

        <button type="submit">Save Settings</button>
    </form>

    <a href="student_dean_dashboard.php" class="back-btn">← Back to Dashboard</a>
</div>

</body>
</html>
