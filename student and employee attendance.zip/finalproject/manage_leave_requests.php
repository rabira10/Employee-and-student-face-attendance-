<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'hr') {
    header("Location: hr_login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Approve or Reject action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_id'], $_POST['action'])) {
    $request_id = intval($_POST['request_id']);
    $action = $_POST['action']; // 'approve' or 'reject'

    // Validate action
    if (!in_array($action, ['approve', 'reject'])) {
        die("Invalid action.");
    }

    // Update leave request status in database
    $status = $action === 'approve' ? 'approved' : 'rejected';
    $update_stmt = $conn->prepare("UPDATE leave_requests SET status = ? WHERE id = ?");
    $update_stmt->bind_param("si", $status, $request_id);
    $update_stmt->execute();

    // Get username to notify
    $user_stmt = $conn->prepare("SELECT username FROM leave_requests WHERE id = ?");
    $user_stmt->bind_param("i", $request_id);
    $user_stmt->execute();
    $result = $user_stmt->get_result();
    $row = $result->fetch_assoc();
    $username = $row['username'] ?? '';

    if ($username) {
        // Insert notification for the user
        $msg = "Your leave request (ID: $request_id) has been " . ($status === 'approved' ? 'approved' : 'rejected') . ".";
        $notif_stmt = $conn->prepare("INSERT INTO notifications (username, message, is_read) VALUES (?, ?, 0)");
        $notif_stmt->bind_param("ss", $username, $msg);
        $notif_stmt->execute();
    }

    header("Location: manage_leave_requests.php");
    exit();
}

// Fetch leave requests to display
$result = $conn->query("SELECT id, username, leave_type, start_date, end_date, status FROM leave_requests ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Manage Leave Requests</title>
    <style>
        table { border-collapse: collapse; width: 100%; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }
        button.approve { background-color: #28a745; color: white; border: none; padding: 6px 12px; cursor: pointer; }
        button.reject { background-color: #dc3545; color: white; border: none; padding: 6px 12px; cursor: pointer; }
        button.approve:hover { background-color: #218838; }
        button.reject:hover { background-color: #c82333; }
    </style>
</head>
<body>
    <h1>Manage Leave Requests</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Leave Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                    <td><?php echo htmlspecialchars($row['leave_type']); ?></td>
                    <td><?php echo htmlspecialchars($row['start_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['end_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                    <td>
                        <?php if ($row['status'] === 'pending'): ?>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="request_id" value="<?php echo $row['id']; ?>">
                            <button type="submit" name="action" value="approve" class="approve">Approve</button>
                        </form>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="request_id" value="<?php echo $row['id']; ?>">
                            <button type="submit" name="action" value="reject" class="reject">Reject</button>
                        </form>
                        <?php else: ?>
                            <em>No actions available</em>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
