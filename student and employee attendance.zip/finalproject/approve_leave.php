<?php
session_start();

// Check HR login
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'hr') {
    header("Location: employee_login.html");
    exit();
}

// DB connection
$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle approve/reject
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['leave_id'], $_POST['action'])) {
    $leave_id = intval($_POST['leave_id']);
    $action = $_POST['action'];

    if (in_array($action, ['approve', 'reject'])) {
        $status = ($action === 'approve') ? 'Approved' : 'Rejected';
        $stmt = $conn->prepare("UPDATE leave_requests SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $leave_id);
        if ($stmt->execute()) {
            echo "<p class='message success'>Leave request has been $status successfully.</p>";
        } else {
            echo "<p class='message error'>Failed to update leave request.</p>";
        }
        $stmt->close();
    }
}

// Fetch pending leave requests
$sql = "SELECT lr.id, e.full_name, lr.start_date, lr.end_date, lr.reason 
        FROM leave_requests lr 
        JOIN employees e ON lr.username = e.username 
        WHERE lr.status = 'Pending'";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Approve Leave Requests</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap');

  *, *::before, *::after {
    box-sizing: border-box;
  }
  body {
    margin: 0; padding: 0;
    font-family: 'Inter', sans-serif;
    background: #f9f9f9;
    color: #333;
  }

  .banner {
    background-color: #800000;
    color: #fff;
    text-align: center;
    padding: 20px;
    font-size: 1.4rem;
    font-weight: bold;
  }

  .container {
    max-width: 960px;
    margin: 0 auto 3rem auto;
    padding: 0 1rem;
  }

  .back-btn {
    text-align: center;
    margin: 1rem 0 2rem 0;
  }

  .back-btn a {
    background-color: #800000;
    color: white;
    padding: 10px 18px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: bold;
    transition: background-color 0.3s ease;
  }

  .back-btn a:hover {
    background-color: #A52A2A;
  }

  h2 {
    text-align: center;
    margin: 1rem 0 1.5rem;
    font-weight: 600;
    font-size: 2rem;
    color: #800000;
  }

  table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 12px;
  }

  thead th {
    text-align: left;
    color: #555;
    font-weight: 600;
    font-size: 0.95rem;
    padding-left: 12px;
    padding-bottom: 6px;
    letter-spacing: 0.02em;
  }

  tbody tr {
    background: #fff;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    border-radius: 10px;
    transition: 0.3s ease;
  }

  tbody tr:hover {
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
  }

  tbody td {
    padding: 16px 20px;
    vertical-align: middle;
    font-size: 1rem;
    color: #444;
  }

  tbody tr td:first-child {
    border-top-left-radius: 10px;
    border-bottom-left-radius: 10px;
    padding-left: 24px;
  }

  tbody tr td:last-child {
    border-top-right-radius: 10px;
    border-bottom-right-radius: 10px;
    padding-right: 24px;
  }

  button {
    border: none;
    cursor: pointer;
    font-weight: 600;
    font-size: 0.9rem;
    padding: 10px 18px;
    border-radius: 8px;
    transition: all 0.3s ease;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.12);
    user-select: none;
  }

  button.approve {
    background: linear-gradient(135deg, #228B22, #66BB6A);
    color: white;
    margin-right: 12px;
  }

  button.approve:hover {
    background: linear-gradient(135deg, #1e7a1e, #4CAF50);
  }

  button.reject {
    background: linear-gradient(135deg, #B22222, #FF6B6B);
    color: white;
  }

  button.reject:hover {
    background: linear-gradient(135deg, #8B0000, #e74c3c);
  }

  .message {
    max-width: 960px;
    margin: 1rem auto 2rem;
    padding: 15px 20px;
    border-radius: 12px;
    font-weight: 600;
    font-size: 1rem;
    text-align: center;
  }

  .message.success {
    background-color: #d4edda;
    color: #155724;
    border: 1.5px solid #c3e6cb;
  }

  .message.error {
    background-color: #f8d7da;
    color: #721c24;
    border: 1.5px solid #f5c6cb;
  }

  @media (max-width: 700px) {
    tbody tr {
      display: block;
      padding: 1rem 1.5rem;
    }

    tbody tr + tr {
      margin-top: 1rem;
    }

    tbody td {
      display: flex;
      justify-content: space-between;
      padding: 8px 0;
      font-size: 0.95rem;
    }

    tbody td::before {
      content: attr(data-label);
      font-weight: 600;
      color: #777;
      flex: 1;
    }

    tbody td:last-child {
      display: flex;
      justify-content: flex-start;
      gap: 12px;
      padding-top: 12px;
    }

    button {
      flex: none;
      width: 45%;
      padding: 10px 0;
    }
  }
</style>
</head>
<body>

<div class="banner">
  Dire Dawa University – HR Leave Approval Panel
</div>

<div class="container">

  

  <h2>Pending Leave Requests</h2>

  <?php
  if ($result === false) {
      echo "<p class='message error'>Database query error: " . htmlspecialchars($conn->error) . "</p>";
  } elseif ($result->num_rows > 0) {
      echo "<table>";
      echo "<thead><tr>
              <th>Employee Name</th>
              <th>Leave Dates</th>
              <th>Reason</th>
              <th>Action</th>
            </tr></thead>";
      echo "<tbody>";
      while ($row = $result->fetch_assoc()) {
          $leaveDates = htmlspecialchars($row['start_date']);
          if (!empty($row['end_date'])) {
              $leaveDates .= " to " . htmlspecialchars($row['end_date']);
          }
          echo "<tr>";
          echo "<td data-label='Employee Name'>" . htmlspecialchars($row['full_name']) . "</td>";
          echo "<td data-label='Leave Dates'>" . $leaveDates . "</td>";
          echo "<td data-label='Reason'>" . htmlspecialchars($row['reason']) . "</td>";
          echo "<td data-label='Action'>
                  <form method='post' style='display:inline-flex; gap: 8px;'>
                      <input type='hidden' name='leave_id' value='" . intval($row['id']) . "'>
                      <button class='approve' type='submit' name='action' value='approve'>Approve</button>
                      <button class='reject' type='submit' name='action' value='reject'>Reject</button>
                  </form>
                </td>";
          echo "</tr>";
      }
      echo "</tbody></table>";
  } else {
      echo "<p class='message'>No pending leave requests.</p>";
  }

  $conn->close();
  ?>
  <div class="back-btn">
    <a href="dashboard_hr.php" class="back-btn">← Back to Dashboard</a>
    
  </div>
</div>

</body>
</html>
