<?php
// Simple test login checker for debugging
$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = 'admin';           // Replace with test input
$password = 'admin123';           // Replace with test input
$role = 'admin';               // Replace with test input

$stmt = $conn->prepare("SELECT username, password, role FROM users WHERE username = ? AND role = ?");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("ss", $username, $role);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows === 1) {
    $user = $result->fetch_assoc();
    
    echo "Found user: " . $user['username'] . "<br>";
    echo "Role: " . $user['role'] . "<br>";

    if (password_verify($password, $user['password'])) {
        echo "<strong>✅ Password is correct. Login should succeed.</strong>";
    } else {
        echo "<strong>❌ Password is incorrect.</strong>";
    }
} else {
    echo "❌ No user found with username '$username' and role '$role'.";
}
?>
