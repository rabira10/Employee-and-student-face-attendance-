<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student') {
    header("Location: student_login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) die("DB connection failed");

$student_id = $_SESSION['student_id'];
$message = '';
$today = date('Y-m-d');

// Check if attendance already signed for today
$stmt_check = $conn->prepare("SELECT * FROM student_attendance WHERE student_id = ? AND date = ?");
$stmt_check->bind_param("is", $student_id, $today);
$stmt_check->execute();
$res_check = $stmt_check->get_result();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($res_check->num_rows > 0) {
        $message = "You have already signed your attendance for today.";
    } else {
        // Insert attendance as present
        $stmt = $conn->prepare("INSERT INTO student_attendance (student_id, date, status) VALUES (?, ?, 'present')");
        $stmt->bind_param("is", $student_id, $today);
        if ($stmt->execute()) {
            $message = "Attendance signed successfully for today.";
        } else {
            $message = "Error signing attendance. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Sign Attendance - Student</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; max-width: 400px; margin: auto; }
        button { padding: 10px 20px; background: #003366; color: white; border: none; cursor: pointer; }
        button:disabled { background: #ccc; cursor: default; }
        .message { margin-top: 20px; color: green; }
    </style>
</head>
<body>
    <h2>Sign Attendance for <?php echo $today; ?></h2>

    <?php if ($message): ?>
        <p class="message"><?php echo htmlspecialchars($message); ?></p>
    <?php endif; ?>

    <form method="POST" action="">
        <button type="submit" <?php if ($res_check->num_rows > 0) echo "disabled"; ?>>
            <?php echo ($res_check->num_rows > 0) ? "Attendance Already Signed" : "Sign Attendance"; ?>
        </button>
    </form>
</body>
</html>
