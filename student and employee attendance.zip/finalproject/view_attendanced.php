<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student_dean') {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$student_search = trim($_GET['student_search'] ?? '');
$department = trim($_GET['department'] ?? '');
$year = trim($_GET['year'] ?? '');
$view_type = trim($_GET['view_type'] ?? 'daily'); // daily, weekly, monthly
$show_all = isset($_GET['show_all']);

// Prepare base student filter query
$whereStudent = [];
$paramsStudent = [];
$typesStudent = '';

if ($student_search !== '') {
    $whereStudent[] = "(username LIKE ? OR full_name LIKE ?)";
    $paramsStudent[] = "%$student_search%";
    $paramsStudent[] = "%$student_search%";
    $typesStudent .= 'ss';
}
if ($department !== '') {
    $whereStudent[] = "department = ?";
    $paramsStudent[] = $department;
    $typesStudent .= 's';
}
if ($year !== '') {
    $whereStudent[] = "year_of_study = ?";
    $paramsStudent[] = $year;
    $typesStudent .= 's';
}

$whereStudentSQL = !empty($whereStudent) ? "WHERE " . implode(" AND ", $whereStudent) : "";

// Fetch all filtered students with created_at
$sqlStudents = "SELECT id, username, full_name, department, year_of_study, created_at FROM students $whereStudentSQL ORDER BY username";
$stmtStudents = $conn->prepare($sqlStudents);
if (!$stmtStudents) {
    die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
}

if (!empty($paramsStudent)) {
    $bind_names[] = $typesStudent;
    foreach ($paramsStudent as $i => $param) {
        $bind_name = 'bind' . $i;
        $$bind_name = $param;
        $bind_names[] = &$$bind_name;
    }
    call_user_func_array([$stmtStudents, 'bind_param'], $bind_names);
}

$stmtStudents->execute();
$resultStudents = $stmtStudents->get_result();

$students = [];
while ($row = $resultStudents->fetch_assoc()) {
    $students[] = $row;
}

// Function to generate date periods based on view type
function generateDatePeriods($student_created_at, $view_type) {
    $periods = [];
    $today = date('Y-m-d');
    
    if ($view_type === 'weekly') {
        // Get the Monday of the week when student was created
        $current = strtotime($student_created_at);
        $current = strtotime('last Monday', $current) ?: $current;
        
        // Generate weekly periods from student creation to current week
        while ($current <= strtotime($today)) {
            $week_start = date('Y-m-d', $current);
            $week_end = date('Y-m-d', strtotime('next Sunday', $current));
            if (strtotime($week_end) > strtotime($today)) {
                $week_end = $today;
            }
            
            $periods[] = [
                'label' => date('M j', $current) . ' - ' . date('M j, Y', strtotime($week_end)),
                'start' => $week_start,
                'end' => $week_end
            ];
            
            // Move to next week
            $current = strtotime('+1 week', $current);
        }
    } elseif ($view_type === 'monthly') {
        // Get the first day of the month when student was created
        $current = strtotime(date('Y-m-01', strtotime($student_created_at)));
        
        // Generate monthly periods from student creation to current month
        while ($current <= strtotime($today)) {
            $month_start = date('Y-m-01', $current);
            $month_end = date('Y-m-t', $current);
            if (strtotime($month_end) > strtotime($today)) {
                $month_end = $today;
            }
            
            $periods[] = [
                'label' => date('F Y', $current),
                'start' => $month_start,
                'end' => $month_end
            ];
            
            // Move to next month
            $current = strtotime('+1 month', $current);
        }
    } else {
        // Daily view - from student creation to today
        $current = strtotime($student_created_at);
        $today_time = strtotime($today);
        
        while ($current <= $today_time) {
            $date = date('Y-m-d', $current);
            $periods[] = [
                'label' => date('M j, Y', $current),
                'start' => $date,
                'end' => $date
            ];
            $current = strtotime('+1 day', $current);
        }
    }
    
    return $periods;
}

// Prepare to fetch attendance for multiple students
$studentIds = array_column($students, 'id');
if (empty($studentIds)) {
    $attendanceData = [];
} else {
    $placeholders = implode(',', array_fill(0, count($studentIds), '?'));
    
    // Fetch all attendance records for the filtered students
    $sqlAttendance = "
        SELECT student_id, attendance_date, status
        FROM student_attendance
        WHERE student_id IN ($placeholders)
    ";

    $stmtAttendance = $conn->prepare($sqlAttendance);
    if (!$stmtAttendance) {
        die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
    }

    $typesAttendance = str_repeat('i', count($studentIds));
    $bind_names = [];
    $bind_names[] = $typesAttendance;
    foreach ($studentIds as $i => $id) {
        $bind_name = 'bind' . $i;
        $$bind_name = $id;
        $bind_names[] = &$$bind_name;
    }
    call_user_func_array([$stmtAttendance, 'bind_param'], $bind_names);

    $stmtAttendance->execute();
    $resultAttendance = $stmtAttendance->get_result();

    $attendanceData = [];
    while ($att = $resultAttendance->fetch_assoc()) {
        $attendanceData[$att['student_id']][$att['attendance_date']] = $att['status'];
    }
}

// Function to calculate attendance summary for a period
function getAttendanceSummary($student_id, $period_start, $period_end, $attendanceData) {
    $present = 0;
    $absent = 0;
    $leave = 0;
    $total_days = 0;
    
    $current = strtotime($period_start);
    $end = strtotime($period_end);
    
    while ($current <= $end) {
        $date = date('Y-m-d', $current);
        $status = $attendanceData[$student_id][$date] ?? 'absent';
        
        switch ($status) {
            case 'present': $present++; break;
            case 'absent': $absent++; break;
            case 'leave': $leave++; break;
        }
        
        $total_days++;
        $current = strtotime('+1 day', $current);
    }
    
    return [
        'present' => $present,
        'absent' => $absent,
        'leave' => $leave,
        'total' => $total_days,
        'percentage' => $total_days > 0 ? round(($present / $total_days) * 100, 2) : 0
    ];
}

// For dropdowns
$deptResult = $conn->query("SELECT DISTINCT department FROM students ORDER BY department");
$yearResult = $conn->query("SELECT DISTINCT year_of_study FROM students ORDER BY year_of_study");
$allStudents = $conn->query("SELECT username FROM students ORDER BY username");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Student Dean - Attendance Viewer</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f1f5f9; padding: 20px; }
        h2 { color: #003366; }
        form { background: #fff; padding: 15px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 6px rgba(0,0,0,0.1); }
        label { margin-right: 10px; font-weight: bold; }
        input, select { padding: 6px; margin-right: 15px; }
        table { width: 100%; border-collapse: collapse; background: #fff; }
        th, td { padding: 10px; border: 1px solid #ccc; text-align: left; }
        th { background: #003366; color: #fff; }
        .button { padding: 8px 15px; background-color: #003366; color: white; text-decoration: none; border-radius: 5px; margin-top: 10px; }
        .button:hover { background-color: #00509e; }
        .show-all-btn { background-color: #4CAF50; }
        .show-all-btn:hover { background-color: #45a049; }
        .view-type { background-color: #6c757d; }
        .view-type:hover { background-color: #5a6268; }
        .present { background-color: #d4edda; }
        .absent { background-color: #f8d7da; }
        .leave { background-color: #fff3cd; }
        .summary-row { font-weight: bold; }
    </style>
</head>
<body>

<h2>Student Attendance Report</h2>

<p style="margin-bottom: 15px; font-weight: bold;">
    View: <?= ucfirst($view_type) ?>
</p>

<form method="GET" action="view_attendanced.php">
    <label>Search:</label>
    <input list="students" name="student_search" value="<?= htmlspecialchars($student_search) ?>" placeholder="Username or Name">
    <datalist id="students">
        <?php while ($student = $allStudents->fetch_assoc()): ?>
            <option value="<?= htmlspecialchars($student['username']) ?>">
        <?php endwhile; ?>
    </datalist>

    <label>Department:</label>
    <select name="department">
        <option value="">All</option>
        <?php while ($row = $deptResult->fetch_assoc()): ?>
            <option value="<?= htmlspecialchars($row['department']) ?>" <?= ($department === $row['department']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($row['department']) ?>
            </option>
        <?php endwhile; ?>
    </select>

    <label>Year:</label>
    <select name="year">
        <option value="">All</option>
        <?php while ($row = $yearResult->fetch_assoc()): ?>
            <option value="<?= htmlspecialchars($row['year_of_study']) ?>" <?= ($year === $row['year_of_study']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($row['year_of_study']) ?>
            </option>
        <?php endwhile; ?>
    </select>
    
    <label>View:</label>
    <select name="view_type">
        <option value="daily" <?= $view_type === 'daily' ? 'selected' : '' ?>>Daily</option>
        <option value="weekly" <?= $view_type === 'weekly' ? 'selected' : '' ?>>Weekly</option>
        <option value="monthly" <?= $view_type === 'monthly' ? 'selected' : '' ?>>Monthly</option>
    </select>

    <button type="submit">Filter</button>
    <a href="view_attendanced.php" class="button" style="background:#999;">Reset</a>
    <button type="submit" name="show_all" value="1" class="button show-all-btn">Show All Attendance</button>
</form>

<table>
    <thead>
        <tr>
            <th><?= ucfirst($view_type) ?> Period</th>
            <th>Username</th>
            <th>Full Name</th>
            <th>Department</th>
            <th>Year</th>
            <th>Present</th>
            <th>Absent</th>
          
        </tr>
    </thead>
    <tbody>
    <?php if (!empty($students)): ?>
        <?php
        foreach ($students as $student):
            // Generate periods for this student based on their creation date
            $periods = generateDatePeriods($student['created_at'], $view_type);
            
            foreach ($periods as $period):
                $summary = getAttendanceSummary($student['id'], $period['start'], $period['end'], $attendanceData);
        ?>
        <tr>
            <td><?= htmlspecialchars($period['label']) ?></td>
            <td><?= htmlspecialchars($student['username']) ?></td>
            <td><?= htmlspecialchars($student['full_name']) ?></td>
            <td><?= htmlspecialchars($student['department']) ?></td>
            <td><?= htmlspecialchars($student['year_of_study']) ?></td>
            <td class="present"><?= $summary['present'] ?></td>
            <td class="absent"><?= $summary['absent'] ?></td>
        </tr>
        <?php
            endforeach;
        endforeach;
    else: ?>
        <tr><td colspan="10">No students found.</td></tr>
    <?php endif; ?>
    </tbody>
</table>

<a href="student_dean_dashboard.php" class="button">&larr; Back to Dashboard</a>

</body>
</html>