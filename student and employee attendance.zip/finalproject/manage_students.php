<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student_dean') {
    header("Location: login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = '';
$error = '';

// Handle activate/deactivate requests
if (isset($_GET['action'], $_GET['username'])) {
    $action = $_GET['action'];
    $username = $_GET['username'];

    if ($action === 'activate') {
        $stmt = $conn->prepare("UPDATE students SET is_active = 1 WHERE username = ?");
    } elseif ($action === 'deactivate') {
        $stmt = $conn->prepare("UPDATE students SET is_active = 0 WHERE username = ?");
    } else {
        $error = "Invalid action.";
    }

    if (isset($stmt)) {
        $stmt->bind_param("s", $username);
        if ($stmt->execute()) {
            $message = "Student account '$username' has been " . ($action === 'activate' ? "activated." : "deactivated.");
        } else {
            $error = "Failed to update student status.";
        }
        $stmt->close();
    }
}

// Fetch all students (make sure 'is_active' column exists in table)
$query = "SELECT username, full_name, department, year_of_study, is_active FROM students";

$result = $conn->query($query);
if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Students - Student Dean</title>
    <style>
        body { font-family: Arial; background-color: #eef2f7; padding: 20px; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { border: 1px solid #aaa; padding: 8px; text-align: left; }
        th { background-color: #003366; color: white; }
        a.button {
            text-decoration: none;
            color: white;
            padding: 5px 12px;
            border-radius: 5px;
            font-weight: bold;
        }
        .activate { background-color: #28a745; }
        .deactivate { background-color: #dc3545; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 5px; }
        .success { background-color: #d4edda; color: #155724; }
        .error { background-color: #f8d7da; color: #721c24; }
        .back-btn {
            display: inline-block;
            margin-bottom: 20px;
            background-color: #003366;
            color: white;
            padding: 8px 16px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
        }
        .back-btn:hover {
            background-color: #1a4d6b;
        }
    </style>
</head>
<body>

   
    <h2>Manage Student Accounts</h2>

    <?php if ($message): ?>
        <div class="message success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="message error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>Username</th>
                <th>Full Name</th>
                <th>Department</th>
                <th>Year</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['username']) ?></td>
                    <td><?= htmlspecialchars($row['full_name']) ?></td>
                    <td><?= htmlspecialchars($row['department']) ?></td>
                    <td><?= htmlspecialchars($row['year_of_study']) ?></td>
                    <td><?= $row['is_active'] == 1 ? 'Active' : 'Inactive' ?></td>
                    <td>
                        <?php if ($row['is_active'] == 1): ?>
                            <a href="manage_students.php?action=deactivate&username=<?= urlencode($row['username']) ?>" class="button deactivate" onclick="return confirm('Deactivate this student?')">Deactivate</a>
                        <?php else: ?>
                            <a href="manage_students.php?action=activate&username=<?= urlencode($row['username']) ?>" class="button activate" onclick="return confirm('Activate this student?')">Activate</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
 <a href="student_dean_dashboard.php" class="back-btn">&larr; Back to Dashboard</a>

</body>
</html>
