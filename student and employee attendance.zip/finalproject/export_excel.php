<?php
require 'db.php';

$selectedDate = $_POST['report_date'] ?? date('Y-m-d');

// Query attendance report with counts
$stmt = $pdo->prepare("
    SELECT 
        e.full_name AS name,
        CASE WHEN a.status = 'present' THEN 1 ELSE 0 END AS present_count,
        CASE WHEN a.status = 'leave' THEN 1 ELSE 0 END AS leave_count,
        CASE WHEN a.status = 'absent' OR a.username IS NULL THEN 1 ELSE 0 END AS absent_count
    FROM employees e
    LEFT JOIN attendance a 
        ON e.username = a.username 
        AND a.role = 'employee' 
        AND a.date = :selected_date
    ORDER BY e.full_name
");
$stmt->execute(['selected_date' => $selectedDate]);
$report = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Total counts
$total_present = 0;
$total_absent = 0;
$total_leave = 0;
foreach ($report as $row) {
    $total_present += $row['present_count'];
    $total_absent += $row['absent_count'];
    $total_leave   += $row['leave_count'];
}

// Output Excel headers
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=attendance_report_$selectedDate.xls");

echo "Employee Name\tPresent\tAbsent\tLeave\n";

foreach ($report as $row) {
    echo "{$row['name']}\t{$row['present_count']}\t{$row['absent_count']}\t{$row['leave_count']}\n";
}

// Add summary
echo "\nTOTALS\t$total_present\t$total_absent\t$total_leave\n";
?>
