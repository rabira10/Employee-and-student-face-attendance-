<?php
session_start();
require_once 'db_config.php'; // Your database connection file

header('Content-Type: application/json');

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['unreadCount' => 0]);
    exit();
}

$student_id = $_SESSION['student_id'];

try {
    $stmt = $conn->prepare("
        SELECT COUNT(*) as unread_count 
        FROM notifications 
        WHERE (target_role IN ('student', 'all') OR target_id = ?)
        AND (read_status = 0 OR read_status IS NULL)
    ");
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    echo json_encode(['unreadCount' => $result['unread_count'] ?? 0]);
} catch (Exception $e) {
    echo json_encode(['unreadCount' => 0]);
}