<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Manually set session for testing, remove or comment this after verifying
// $_SESSION['user'] = 'testuser';
// $_SESSION['role'] = 'student_dean';

// Check login
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student_dean') {
    die("Access denied. You are not logged in as student dean.");
}

// DB connection
$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("DB Connection failed: " . $conn->connect_error);
}

echo "DB connected successfully.<br>";

// Simple query to check tables and data
$sql = "SELECT username, full_name FROM students LIMIT 5";
$res = $conn->query($sql);
if (!$res) {
    die("Query failed: " . $conn->error);
}

echo "Sample students:<br>";
while ($row = $res->fetch_assoc()) {
    echo htmlspecialchars($row['username']) . " - " . htmlspecialchars($row['full_name']) . "<br>";
}

$conn->close();
