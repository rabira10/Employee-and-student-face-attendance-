<?php
session_start();

// Language support
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

$default_lang = 'en';
$current_lang = $_SESSION['lang'] ?? $default_lang;

// Load translations
$translations = [];
$lang_file = "languages/{$current_lang}.php";
if (file_exists($lang_file)) {
    $translations = require $lang_file;
}

function t($key, $translations) {
    return $translations[$key] ?? $key;
}

// Session check (example for student_dean role)
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student_dean') {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?php echo t('student_dean_dashboard', $translations); ?> - Dire Dawa University</title>

    <style>
        /* ===== Your full CSS copied exactly here ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #003366 0%, #1a4d6b 100%);
            min-height: 100vh;
            color: #333;
            line-height: 1.6;
        }

        .header {
            background: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-bottom: 4px solid #FFCC00;
            padding: 1.5rem 0;
            animation: slideIn 0.6s ease-out;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }

        .logo {
            font-size: 2.4rem;
            font-weight: bold;
            color: #0058a3;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .university-info h1 {
            font-size: 1.3rem;
            font-weight: 600;
            color: #003366;
        }

        .university-info p {
            font-size: 0.85rem;
            font-weight: 400;
            color: #666;
        }

        .header-nav {
            display: flex;
            gap: 1rem;
            font-size: 1rem;
            font-weight: 600;
        }

        .header-nav-item {
            position: relative;
        }

        .header-nav-link {
            display: inline-block;
            padding: 0.5rem 0.8rem;
            color: #333;
            text-decoration: none;
            cursor: pointer;
            user-select: none;
        }

        .header-nav-link:hover,
        .header-nav-link:focus {
            color: #0058a3;
        }

        .header-dropdown {
            display: none;
            position: absolute;
            top: 2.6rem;
            left: 0;
            background: white;
            border-radius: 0 0 8px 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
            padding: 0.4rem 0;
            min-width: 180px;
            z-index: 1000;
        }

        .header-nav-item:hover .header-dropdown,
        .header-nav-item:focus-within .header-dropdown {
            display: block;
        }

        .header-dropdown-link {
            display: block;
            padding: 0.5rem 1.1rem;
            color: #333;
            text-decoration: none;
            transition: background-color 0.2s ease-in-out;
        }

        .header-dropdown-link:hover,
        .header-dropdown-link:focus {
            background-color: #e0e0e0;
            color: #0058a3;
        }

        .logout {
            color: #d32f2f;
        }

        .logout:hover,
        .logout:focus {
            color: #9a0007;
            background-color: #ffcdd2;
        }

        .dean-section {
            display: flex;
            align-items: center;
            gap: 1rem;
            font-weight: 600;
            color: #0058a3;
        }

        .dean-badge i {
            margin-right: 0.4rem;
            color: #0058a3;
        }

        .language-switcher a {
            margin: 0 0.3rem;
            color: #666;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
        }

        .language-switcher a.active,
        .language-switcher a:hover {
            color: #0058a3;
            text-decoration: underline;
        }

        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        footer {
            background-color: #003366;
            color: #fff;
            padding: 2rem 1rem;
            text-align: center;
            font-size: 0.9rem;
            margin-top: 2rem;
        }

        /* Add your other CSS here if any */

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

    </style>

    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>

<div class="header">
    <div class="header-content">
        <div class="logo-section">
            <div class="logo">DDU</div>
            <div class="university-info">
                <h1><?php echo t('dire_dawa_university', $translations); ?></h1>
                <p><?php echo t('student_dean_portal', $translations); ?></p>
            </div>
        </div>

        <nav class="header-nav">
            <div class="header-nav-item">
                <a href="#" class="header-nav-link">
                    🎓 <?php echo t('student_management', $translations); ?>
                </a>
                <div class="header-dropdown">
                    <a href="view_students.php" class="header-dropdown-link">👥 <?php echo t('view_all_students', $translations); ?></a>
                    <a href="view_attendanced.php" class="header-dropdown-link">📊 <?php echo t('attendance_reports', $translations); ?></a>
                    <a href="download_attendanceD.php" class="header-dropdown-link">📥 <?php echo t('download_reports', $translations); ?></a>
                    <a href="send_notifications.php" class="header-dropdown-link">📢 <?php echo t('send_notifications', $translations); ?></a>
                    <a href="manage_students.php" class="header-dropdown-link">⚙️ <?php echo t('manage_accounts', $translations); ?></a>
                    <a href="register_student.php" class="header-dropdown-link">➕ <?php echo t('register_student', $translations); ?></a>
                </div>
            </div>

            <div class="header-nav-item">
                <a href="#" class="header-nav-link">
                    ⚡ <?php echo t('quick_actions', $translations); ?>
                </a>
                <div class="header-dropdown">
                    <a href="changeD_password.php" class="header-dropdown-link">🔒 <?php echo t('change_password', $translations); ?></a>
                    <a href="login.php" class="header-dropdown-link logout">🚪 <?php echo t('logout', $translations); ?></a>
                    <a href="time.php" class="header-dropdown-link">🕒 <?php echo t('attendance_time_window', $translations); ?></a>
                </div>
            </div>
        </nav>

        <div class="dean-section">
            <div class="language-switcher">
                <a href="?lang=en" class="<?php echo $current_lang === 'en' ? 'active' : ''; ?>">English</a>
                <a href="?lang=am" class="<?php echo $current_lang === 'am' ? 'active' : ''; ?>">አማርኛ</a>
            </div>
            <div class="dean-badge">
                <i class="fas fa-user-graduate"></i>
                <?php echo t('student_dean', $translations); ?>
            </div>
        </div>
    </div>
</div>

<div class="container">
