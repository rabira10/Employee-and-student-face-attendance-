<?php
session_start();

// Only allow if user is admin or student_dean
if (!isset($_SESSION['user']) || !in_array($_SESSION['role'], ['admin', 'student_dean'])) {
    header("Location: login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = trim($_POST['id'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $department = trim($_POST['department'] ?? '');
    $year = trim($_POST['year'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $face_descriptor = $_POST['face_descriptor'] ?? '';

    if (!$id || !$username || !$full_name || !$department || !$year || !$password || !$confirm_password) {
        $error = "Please fill in all required fields.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (empty($face_descriptor)) {
        $error = "Please capture your face for recognition.";
    } else {
        // Check if ID already exists
        $stmt = $conn->prepare("SELECT id FROM students WHERE id = ?");
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $error = "Student ID already exists. Choose a different one.";
            $stmt->close();
        } else {
            $stmt->close();

            // Check if username already exists
            $stmt2 = $conn->prepare("SELECT username FROM students WHERE username = ?");
            $stmt2->bind_param("s", $username);
            $stmt2->execute();
            $stmt2->store_result();
            if ($stmt2->num_rows > 0) {
                $error = "Username already exists. Choose a different one.";
                $stmt2->close();
            } else {
                $stmt2->close();

                // Validate face descriptor JSON
                $descArray = json_decode($face_descriptor, true);
                if (!is_array($descArray) || count($descArray) !== 128) {
                    $error = "Invalid face descriptor.";
                } else {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                    $insert = $conn->prepare("INSERT INTO students (id, username, full_name, department, year, year_of_study, email, phone, password, face_descriptor, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
                    $year_of_study = $year;
                    $face_desc_json = json_encode($descArray);

                    $insert->bind_param("ssssssssss", $id, $username, $full_name, $department, $year, $year_of_study, $email, $phone, $hashed_password, $face_desc_json);

                    if ($insert->execute()) {
                        $message = "Student registered successfully. Student ID: " . htmlspecialchars($id);
                    } else {
                        $error = "Failed to register student: " . $insert->error;
                    }
                    $insert->close();
                }
            }
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Register New Student / የተማሪ ምዝገባ</title>
<style>
    body { font-family: Arial, sans-serif; background: #eef2f7; padding: 20px; }
    form { background: white; padding: 20px; border-radius: 8px; max-width: 600px; margin: auto; }
    label { display: block; margin-bottom: 8px; font-weight: bold; }
    input, select, textarea { width: 100%; padding: 8px; margin-bottom: 15px; box-sizing: border-box; }
    button { background-color: #003366; color: white; padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer; }
    button:hover { background-color: #002244; }
    .message { padding: 10px; margin-bottom: 15px; border-radius: 5px; }
    .success { background-color: #d4edda; color: #155724; }
    .error { background-color: #f8d7da; color: #721c24; }
    .back-btn {
        display: inline-block;
        margin-bottom: 20px;
        padding: 10px 15px;
        background-color: #003366;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
    }
    #video {
        border: 2px solid #003366;
        border-radius: 6px;
        display: block;
        margin-bottom: 10px;
        width: 320px;
        height: 240px;
    }
    #faceStatus {
        margin-bottom: 15px;
        font-weight: bold;
        color: #003366;
    }
</style>

<!-- Load face-api.js from CDN -->
<script src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
</head>
<body>
<h2>Register New Student / የተማሪ ምዝገባ</h2>

<a href="student_dean_dashboard.php" class="back-btn">&larr; Back to Dashboard / ወደ ዳሽቦርድ ተመለስ</a>

<?php if ($message): ?>
    <div class="message success"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="message error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST" action="" id="registerForm">
    <label for="id">Student ID / የተማሪ መለያ:</label>
    <input type="text" id="id" name="id" required value="<?= htmlspecialchars($_POST['id'] ?? '') ?>">

    <label for="username">Username / የተጠቃሚ ስም:</label>
    <input type="text" id="username" name="username" required value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">

    <label for="full_name">Full Name / ሙሉ ስም:</label>
    <input type="text" id="full_name" name="full_name" required value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>">

    <label for="department">Department / ክፍል:</label>
    <input type="text" id="department" name="department" required value="<?= htmlspecialchars($_POST['department'] ?? '') ?>">

    <label for="year">Year / አመት:</label>
    <input type="text" id="year" name="year" required value="<?= htmlspecialchars($_POST['year'] ?? '') ?>">

    <label for="email">Email / ኢሜይል (optional):</label>
    <input type="email" id="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">

    <label for="phone">Phone / ስልክ (optional):</label>
    <input type="text" id="phone" name="phone" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">

    <label for="password">Password / የይለፍ ቃል:</label>
    <input type="password" id="password" name="password" required>

    <label for="confirm_password">Confirm Password / የይለፍ ቃል እንደገና ያረጋግጡ:</label>
    <input type="password" id="confirm_password" name="confirm_password" required>

    <h3>Face Recognition / ፊት እውቅና</h3>
    <video id="video" autoplay muted></video>
    <button type="button" id="captureBtn">Capture Face / ፊት ያንሱ</button>
    <div id="faceStatus">Loading models and starting webcam...</div>
    <input type="hidden" id="faceDescriptor" name="face_descriptor" />

    <button type="submit" style="margin-top:20px;">Register / ይመዝገቡ</button>
</form>

<script>
    const MODEL_URL = '/finalproject/models';

    async function loadModels() {
        const faceStatus = document.getElementById('faceStatus');
        try {
            await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
            await faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL);
            await faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL);
            faceStatus.innerText = "Models loaded successfully! / ሞዴሎች በተሳካ ሁኔታ ተጭነዋል!";
        } catch (e) {
            faceStatus.innerText = "Error loading models: " + e;
            throw e;
        }
    }

    async function startVideo() {
        const video = document.getElementById('video');
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: true });
            video.srcObject = stream;
        } catch (err) {
            document.getElementById('faceStatus').innerText = "Webcam error: " + err.message;
        }
    }

    async function init() {
        await loadModels();
        await startVideo();

        document.getElementById('captureBtn').addEventListener('click', async () => {
            const faceStatus = document.getElementById('faceStatus');
            faceStatus.innerText = "Detecting face...";

            const video = document.getElementById('video');

            const detection = await faceapi.detectSingleFace(video, new faceapi.TinyFaceDetectorOptions())
                .withFaceLandmarks()
                .withFaceDescriptor();

            if (!detection) {
                faceStatus.innerText = "No face detected. Please try again. / ፊት አልተገኘም። እባክዎን እንደገና ይሞክሩ.";
                return;
            }

            const descriptor = Array.from(detection.descriptor);
            document.getElementById('faceDescriptor').value = JSON.stringify(descriptor);
            faceStatus.innerText = "Face captured successfully! / ፊት ተቀብሏል!";
        });
    }

    window.onload = init;
</script>

</body>
</html>
