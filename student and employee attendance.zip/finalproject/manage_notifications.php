<?php
// Fetch sent notifications by student dean
$notif_query = "SELECT id, username, message, created_at FROM notifications ORDER BY created_at DESC";
$notif_result = $conn->query($notif_query);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $delete_id = intval($_POST['delete_id']);
    $stmt = $conn->prepare("DELETE FROM notifications WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    if ($stmt->execute()) {
        echo "<div class='message success'>Notification deleted successfully.</div>";
    } else {
        echo "<div class='message error'>Failed to delete notification.</div>";
    }
    $stmt->close();
}
?>
