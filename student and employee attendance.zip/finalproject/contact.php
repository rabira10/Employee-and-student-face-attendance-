<?php
session_start();

// Language support
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

$default_lang = 'en'; // Default language
$current_lang = $_SESSION['lang'] ?? $default_lang;

// Load translations
$translations = [];
$lang_file = __DIR__ . "/languages/{$current_lang}.php";
if (file_exists($lang_file)) {
    $translations = require $lang_file;
}

// Helper function for translations
function t($key, $translations) {
    return $translations[$key] ?? $key;
}

// Check authentication and role
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student_dean') {
    header("Location: login.php");
    exit();
}

// Set page title for header partial
$page_title = t('contact_us', $translations) . ' - ' . t('dire_dawa_university', $translations);

?>
 <?php include 'headerD.php'; ?>

<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($current_lang); ?>">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?php echo htmlspecialchars($page_title); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <style>
        /* Base styles */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f8fa;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .container {
            max-width: 900px;
            margin: 3rem auto;
            padding: 0 1rem;
        }

        /* Contact container card */
        .contact-container {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 20px;
            padding: 2.5rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.07);
        }

        /* Header inside card */
        .card-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .card-icon {
            font-size: 2.5rem;
            color: #004080;
        }

        .card-title {
            font-size: 1.8rem;
            font-weight: 700;
            color: #004080;
        }

        p {
            font-size: 1.1rem;
            line-height: 1.6;
            margin-top: 0;
            color: #555;
        }

        /* Grid for contact methods */
        .contact-methods {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }

        /* Individual cards */
        .contact-card {
            background: white;
            border-radius: 15px;
            padding: 1.8rem 1.5rem;
            box-shadow: 0 4px 18px rgba(0,0,0,0.08);
            transition: transform 0.25s ease, box-shadow 0.25s ease;
            cursor: default;
        }

        .contact-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }

        .contact-icon {
            font-size: 2.3rem;
            color: #0077cc;
            margin-bottom: 1rem;
        }

        .contact-card h3 {
            margin: 0 0 0.5rem;
            color: #004080;
            font-weight: 600;
            font-size: 1.3rem;
        }

        .contact-card p {
            margin: 0.3rem 0;
            color: #333;
            font-weight: 500;
        }

        /* Contact info section */
        .contact-info {
            margin-top: 3rem;
            background: #e9f0fa;
            border-radius: 15px;
            padding: 2rem 1.8rem;
            box-shadow: 0 6px 25px rgba(0, 112, 204, 0.1);
        }

        .contact-info h3 {
            font-size: 1.6rem;
            font-weight: 700;
            color: #003366;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.6rem;
        }

        .contact-info p {
            font-size: 1.1rem;
            margin: 0.4rem 0;
            color: #2a2a2a;
            font-weight: 600;
        }

        /* Responsive tweaks */
        @media (max-width: 480px) {
            .card-title {
                font-size: 1.5rem;
            }
            .contact-card h3 {
                font-size: 1.1rem;
            }
            .contact-info h3 {
                font-size: 1.3rem;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <?php include 'header.php'; ?>

    <div class="container">
        <div class="contact-container">
            <div class="card-header" role="banner">
                <div class="card-icon" aria-hidden="true">📧</div>
                <div class="card-title"><?php echo t('contact_us', $translations); ?></div>
            </div>

            <p><?php echo t('contact_us_description', $translations); ?></p>

            <div class="contact-methods">
                <div class="contact-card" role="region" aria-label="<?php echo t('email_us', $translations); ?>">
                    <div class="contact-icon"><i class="fas fa-envelope" aria-hidden="true"></i></div>
                    <h3><?php echo t('email_us', $translations); ?></h3>
                    <p>studentdean@ddu.edu.et</p>
                </div>

                <div class="contact-card" role="region" aria-label="<?php echo t('call_us', $translations); ?>">
                    <div class="contact-icon"><i class="fas fa-phone" aria-hidden="true"></i></div>
                    <h3><?php echo t('call_us', $translations); ?></h3>
                    <p>+251 25 111 2233</p>
                    <p><?php echo t('working_hours', $translations); ?>: 8:30 AM - 5:00 PM (EAT)</p>
                </div>

                <div class="contact-card" role="region" aria-label="<?php echo t('visit_us', $translations); ?>">
                    <div class="contact-icon"><i class="fas fa-map-marker-alt" aria-hidden="true"></i></div>
                    <h3><?php echo t('visit_us', $translations); ?></h3>
                    <p><?php echo t('university_address', $translations); ?></p>
                </div>
            </div>

            <div class="contact-info" role="contentinfo" aria-label="<?php echo t('contact_information', $translations); ?>">
                <h3>📞 <?php echo t('contact_information', $translations); ?></h3>
                <p><strong><?php echo t('email', $translations); ?>:</strong> studentdean@ddu.edu.et</p>
                <p><strong><?php echo t('phone', $translations); ?>:</strong> +251 25 111 2233</p>
                <p><strong><?php echo t('address', $translations); ?>:</strong> <?php echo t('university_address', $translations); ?></p>
                <p><strong><?php echo t('working_hours', $translations); ?>:</strong> 8:30 AM - 5:00 PM (EAT)</p>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'footerD.php'; ?>
</body>
</html>
