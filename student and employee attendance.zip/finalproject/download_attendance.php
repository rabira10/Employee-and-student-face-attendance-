<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'hr') {
    die("Unauthorized access.");
}
require 'db.php';

$date = $_GET['date'] ?? date('Y-m-d');
$viewType = $_GET['view_type'] ?? 'daily';
$format = $_GET['format'] ?? 'excel';

$filename = "attendance_" . $viewType . "_" . $date;

$baseDate = new DateTime($date);
if ($viewType === 'weekly') {
    $startDate = $baseDate->modify('last sunday')->format('Y-m-d');
    $endDate = (new DateTime($startDate))->modify('+6 days')->format('Y-m-d');
} elseif ($viewType === 'monthly') {
    $startDate = $baseDate->modify('first day of this month')->format('Y-m-d');
    $endDate = $baseDate->modify('last day of this month')->format('Y-m-d');
} else {
    $startDate = $endDate = $date;
}

$stmt = $pdo->prepare("SELECT e.full_name, a.date, a.status
                       FROM attendance a
                       JOIN employees e ON a.username = e.username
                       WHERE a.date BETWEEN ? AND ?
                       ORDER BY a.date ASC, e.full_name ASC");
$stmt->execute([$startDate, $endDate]);
$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

$content = "Employee Name\tDate\tStatus\n";
foreach ($records as $row) {
    $content .= "{$row['full_name']}\t{$row['date']}\t{$row['status']}\n";
}

if ($format === 'word') {
    header("Content-Type: application/msword");
    header("Content-Disposition: attachment; filename=\"$filename.doc\"");
} else {
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=\"$filename.xls\"");
}
echo $content;
exit;
