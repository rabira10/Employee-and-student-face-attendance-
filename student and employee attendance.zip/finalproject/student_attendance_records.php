<?php
session_start();

// Check authentication
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit();
}

$filter = $_GET['filter'] ?? 'daily';

$endDate = date('Y-m-d');
$student_id = $_SESSION['student_id'] ?? null;

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Build query depending on filter
if ($filter === 'monthly') {
    // Monthly: show all records for student (no date filter)
    $sql = "SELECT id, student_id, attendance_date, status FROM student_attendance WHERE student_id = ? ORDER BY attendance_date DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $student_id);
} else {
    // Daily or weekly filter with date range
    if ($filter === 'weekly') {
        $startDate = date('Y-m-d', strtotime('-6 days'));
    } else {
        // daily = today only
        $startDate = $endDate;
    }

    $sql = "SELECT id, student_id, attendance_date, status FROM student_attendance WHERE student_id = ? AND attendance_date BETWEEN ? AND ? ORDER BY attendance_date DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $student_id, $startDate, $endDate);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Student Attendance Records - Dire Dawa University</title>
    <style>
        /* Base reset */
        *, *::before, *::after {
            box-sizing: border-box;
        }

        body {
            font-family: 'Open Sans', Arial, sans-serif;
            background-color: #f8f9f9;
            margin: 0;
            padding: 40px 15px;
            color: #0a5029; /* Dark green */
        }

        h2 {
            text-align: center;
            color: #0a5029;
            font-weight: 700;
            font-size: 2rem;
            margin-bottom: 35px;
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        form {
            max-width: 220px;
            margin: 0 auto 30px auto;
            text-align: center;
        }

        select {
            padding: 10px 15px;
            border-radius: 5px;
            border: 2px solid #0a5029;
            font-weight: bold;
            font-size: 1rem;
            color: #0a5029;
            cursor: pointer;
            width: 100%;
            box-sizing: border-box;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            max-width: 1100px;
            margin: 0 auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgb(10 80 41 / 0.15);
            overflow: hidden;
        }

        thead {
            background-color: #0a5029; /* Dark green */
            color: #ffc72c; /* Gold */
            font-weight: 700;
            text-transform: uppercase;
        }

        th, td {
            padding: 14px 18px;
            text-align: left;
            vertical-align: middle;
            border-bottom: 1px solid #e5e5e5;
            font-size: 0.95rem;
        }

        tbody tr:nth-child(even) {
            background-color: #f3f7f2;
        }

        tbody tr:hover {
            background-color: #e6f1de;
            transition: background-color 0.3s ease;
        }

        /* Responsive */
        @media (max-width: 768px) {
            table, thead, tbody, th, td, tr {
                display: block;
            }

            thead tr {
                position: absolute;
                top: -9999px;
                left: -9999px;
            }

            tbody tr {
                background-color: #fff !important;
                margin-bottom: 18px;
                border-radius: 8px;
                box-shadow: 0 3px 6px rgb(10 80 41 / 0.1);
                padding: 12px 20px;
                border: 1px solid #d9e4d4;
            }

            tbody tr:hover {
                background-color: #dff0d6 !important;
            }

            td {
                border: none;
                position: relative;
                padding-left: 50%;
                text-align: right;
                font-weight: 600;
                color: #0a5029;
                font-size: 1rem;
            }

            td::before {
                position: absolute;
                top: 14px;
                left: 20px;
                width: 45%;
                padding-right: 10px;
                white-space: nowrap;
                text-align: left;
                text-transform: uppercase;
                font-weight: 700;
                color: #0a5029;
                font-size: 0.9rem;
            }

            td:nth-of-type(1)::before { content: "ID"; }
            td:nth-of-type(2)::before { content: "Student ID"; }
            td:nth-of-type(3)::before { content: "Date"; }
            td:nth-of-type(4)::before { content: "Status"; }
        }

        /* Modern Back to Dashboard Button */
        .back-btn {
           display: block;
    max-width: 220px;
    margin: 30px auto 0 auto;
    padding: 14px 25px;
    background: linear-gradient(135deg, #28a745 0%, #218838 100%);
    color: white;
    font-weight: 700;
    font-size: 1.1rem;
    text-align: center;
    text-decoration: none;
    border-radius: 50px;
    box-shadow: 0 8px 15px rgba(40, 167, 69, 0.4);
    transition: all 0.3s ease;
    cursor: pointer;
    user-select: none;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .back-btn:hover {
            background: linear-gradient(135deg, #218838 0%, #28a745 100%);
            box-shadow: 0 15px 20px rgba(33, 136, 56, 0.6);
            transform: translateY(-3px);
        }

        .back-btn:active {
            transform: translateY(1px);
            box-shadow: 0 5px 8px rgba(33, 136, 56, 0.4);
        }
    </style>
</head>
<body>

<h2>Student Attendance Records</h2>

<form method="get" action="">
    <label for="filter">View by: </label>
    <select id="filter" name="filter" onchange="this.form.submit()">
        <option value="daily" <?= $filter === 'daily' ? 'selected' : '' ?>>Daily</option>
        <option value="weekly" <?= $filter === 'weekly' ? 'selected' : '' ?>>Weekly</option>
        <option value="monthly" <?= $filter === 'monthly' ? 'selected' : '' ?>>Monthly</option>
    </select>
</form>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Student ID</th>
            <th>Date</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']) ?></td>
                    <td><?= htmlspecialchars($row['student_id']) ?></td>
                    <td><?= htmlspecialchars($row['attendance_date']) ?></td>
                    <td><?= htmlspecialchars($row['status']) ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="4" style="text-align:center;">No attendance records found for selected period.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<a href="student_dashboard.php" class="back-btn" aria-label="Back to Student Dashboard">← Back to Dashboard</a>

</body>
</html>
