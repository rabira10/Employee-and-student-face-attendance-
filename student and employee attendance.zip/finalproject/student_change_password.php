<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['user'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old_password = $_POST['old_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if ($new_password !== $confirm_password) {
        $message = "New password and confirmation do not match./የአዲሱ የይለፍ ቃል እና ማረጋገጫ አንደኛ አይደሉም።";
    } else {
        $stmt = $conn->prepare("SELECT password FROM students WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if (password_verify($old_password, $user['password'])) {
                $new_hashed = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt2 = $conn->prepare("UPDATE students SET password = ? WHERE username = ?");
                $stmt2->bind_param("ss", $new_hashed, $username);
                if ($stmt2->execute()) {
                    $message = "Password changed successfully./የይለፍ ቃል በትክክል ተቀይሯል።";
                } else {
                    $message = "Error updating password. Try again./የይለፍ ቃል ማሻሻያ ላይ ችግር ተፈጥሯል።";
                }
            } else {
                $message = "Old password is incorrect./አሮጌ የይለፍ ቃል ትክክል አይደለም።";
            }
        } else {
            $message = "User not found./ተጠቃሚ አልተገኘም።";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Change Password - Student</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; max-width: 400px; margin: auto; }
        form { display: flex; flex-direction: column; }
        label { margin-top: 10px; }
        input[type=password] { padding: 8px; margin-top: 5px; }
        button, .back-btn {
            margin-top: 20px;
            padding: 10px;
            background-color: #003366;
            color: white;
            border: none;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
        }
        button:hover, .back-btn:hover { background-color: #0055a5; }
        .message { margin-top: 20px; color: red; }
        .success { color: green; }
    </style>
</head>
<body>
    <h2>Change Password / የይለፍ ቃል ቀይር</h2>

    <?php if ($message): ?>
        <div class="message <?php echo strpos($message, 'successfully') !== false ? 'success' : ''; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="old_password">Old Password / አሮጌ የይለፍ ቃል:</label>
        <input type="password" id="old_password" name="old_password" required>

        <label for="new_password">New Password / አዲስ የይለፍ ቃል:</label>
        <input type="password" id="new_password" name="new_password" required>

        <label for="confirm_password">Confirm New Password / አዲሱን የይለፍ ቃል ያረጋግጡ:</label>
        <input type="password" id="confirm_password" name="confirm_password" required>

        <button type="submit">Change Password / የይለፍ ቃል ቀይር</button>

        <!-- Back to Dashboard Button -->
        <a href="student_dashboard.php" class="back-btn">⬅ Back to Dashboard / ወደ ዳሽቦርድ ተመለስ</a>
    </form>
</body>
</html>
