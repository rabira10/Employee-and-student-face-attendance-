<?php
// auth.php

class Auth {
    public static function checkEmployeeAuth() {
        session_start();

        if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'employee') {
            header("Location: employee_login.html");
            exit();
        }

        return $_SESSION['user'];
    }
}
