<?php
$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = 'hr1';                // Change if needed
$newPassword = 'hr123';             // New plain password

$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

$stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
$stmt->bind_param("ss", $hashedPassword, $username);

if ($stmt->execute()) {
    echo "✅ Password reset successfully!";
} else {
    echo "❌ Failed to reset password.";
}
?>
