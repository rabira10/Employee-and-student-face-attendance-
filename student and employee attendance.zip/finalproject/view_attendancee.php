<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'employee') {
    header("Location: employee_login.php");
    exit();
}

$usernameSession = $_SESSION['user'];
$today           = date('Y-m-d');
$filter          = $_GET['filter'] ?? 'daily';

switch ($filter) {
    case 'weekly':  $startDate = date('Y-m-d', strtotime('-6 days')); break;
    case 'monthly': $startDate = date('Y-m-01');                    break;
    default:        $startDate = $today;                            break;
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("DB connection error: " . $conn->connect_error);
}

// Fetch attendance filtered only by username (because user_id inconsistent)
$sql = "SELECT date, session, status, `time`, method
        FROM attendance
        WHERE username = ?
          AND date BETWEEN ? AND ?";
$aStmt = $conn->prepare($sql);
$aStmt->bind_param("sss", $usernameSession, $startDate, $today);
$aStmt->execute();
$aRes = $aStmt->get_result();

// Organize attendance by date and session
$attendance = [];
while ($row = $aRes->fetch_assoc()) {
    $d = $row['date'];
    $sess = strtoupper(trim($row['session']));
    $attendance[$d][$sess] = [
        'status' => ucfirst($row['status']),
        'time'   => $row['time'] ? date('h:i:s A', strtotime($row['time'])) : '--',
        'method' => trim($row['method']) !== '' ? trim($row['method']) : '--',
    ];
}
$aStmt->close();
$conn->close();

// Generate date range for display (weekdays only)
$period = new DatePeriod(
    new DateTime($startDate),
    new DateInterval('P1D'),
    (new DateTime($today))->modify('+1 day')
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Employee Attendance (AM/PM)</title>
<style>
    body { font-family: Arial, sans-serif; max-width: 900px; margin: 20px auto; background: #F2FDF6; color: #2F2F2F; }
    h1 { text-align: center; color: #145A32; }
    form { text-align: center; margin-bottom: 20px; }
    select { padding: 8px 14px; border: 2px solid #4CAF50; border-radius: 5px; font-size: 16px; background: #fff; color: #145A32; font-weight: bold; }
    table { width: 100%; border-collapse: collapse; background: #fff; box-shadow: 0 3px 8px rgba(0,100,0,.2); }
    th, td { padding: 10px 15px; text-align: center; border-bottom: 1px solid #ddd; }
    th { background: #145A32; color: #fff; }
    tr:hover { background: #E0F2E9; }
    .back-btn { display: block; width: 200px; margin: 30px auto; padding: 12px; background: #4CAF50; color: white; text-align: center; font-weight: bold; border-radius: 8px; text-decoration: none; }
</style>
</head>
<body>

<h1>My Attendance Records (AM / PM)</h1>

<form method="get">
    <label for="filter">View by: </label>
    <select id="filter" name="filter" onchange="this.form.submit()">
        <option value="daily" <?= $filter == 'daily' ? 'selected' : '' ?>>Daily</option>
        <option value="weekly" <?= $filter == 'weekly' ? 'selected' : '' ?>>Weekly</option>
        <option value="monthly" <?= $filter == 'monthly' ? 'selected' : '' ?>>Monthly</option>
    </select>
</form>

<table>
<thead>
<tr>
    <th>Date</th>
    <th>Session</th>
    <th>Status</th>
   
</tr>
</thead>
<tbody>
<?php
foreach ($period as $dt) {
    if ($dt->format('N') >= 6) continue; // skip weekends Sat, Sun
    $date = $dt->format('Y-m-d');
    foreach (['AM', 'PM'] as $sess) {
        $rec = $attendance[$date][$sess] ?? ['status' => 'Absent', 'time' => '--', 'method' => '--'];
        echo '<tr>';
        echo '<td>' . htmlspecialchars($date) . '</td>';
        echo '<td>' . $sess . '</td>';
        echo '<td>' . htmlspecialchars($rec['status']) . '</td>';
      
        echo '</tr>';
    }
}
?>
</tbody>
</table>

<a class="back-btn" href="dashboard_employee.php">Back to Dashboard</a>

</body>
</html>
