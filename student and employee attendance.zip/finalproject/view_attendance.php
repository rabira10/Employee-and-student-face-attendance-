<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'hr') {
    header("Location: login.html");
    exit;
}

require 'db.php';

$attendanceGrouped = [];
$absentees = [];
$error = '';
$today = date('Y-m-d');

try {
    $stmtMin = $pdo->query("SELECT MIN(date) AS min_date FROM attendance");
    $resultMin = $stmtMin->fetch(PDO::FETCH_ASSOC);
    $minDate = $resultMin && $resultMin['min_date'] ? $resultMin['min_date'] : $today;
} catch (PDOException $e) {
    $error = "Error fetching min date: " . $e->getMessage();
    $minDate = $today;
}

$selectedDate = $_GET['date'] ?? $today;
if ($selectedDate < $minDate) {
    $selectedDate = $minDate;
} elseif ($selectedDate > $today) {
    $selectedDate = $today;
}

$viewMode = $_GET['view'] ?? 'daily';

function getDateRange($selectedDate, $viewMode) {
    if ($viewMode === 'weekly') {
        $start = date('Y-m-d', strtotime('monday this week', strtotime($selectedDate)));
        $end = date('Y-m-d', strtotime('sunday this week', strtotime($selectedDate)));
    } elseif ($viewMode === 'monthly') {
        $start = date('Y-m-01', strtotime($selectedDate));
        $end = date('Y-m-t', strtotime($selectedDate));
    } else {
        $start = $end = $selectedDate;
    }
    return [$start, $end];
}

[$startDate, $endDate] = getDateRange($selectedDate, $viewMode);

try {
    $stmt = $pdo->prepare("
        SELECT a.id, e.full_name, a.date, a.status, a.session
        FROM attendance a
        JOIN employees e ON a.user_id = e.id
        WHERE a.date BETWEEN ? AND ?
        ORDER BY a.date ASC, e.full_name ASC, a.session ASC
    ");

    $stmt->execute([$startDate, $endDate]);
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($records as $record) {
        $key = $record['full_name'] . '_' . $record['date'];
        if (!isset($attendanceGrouped[$key])) {
            $attendanceGrouped[$key] = [
                'full_name' => $record['full_name'],
                'date' => $record['date'],
                'AM' => 'Absent',
                'PM' => 'Absent'
            ];
        }
        $attendanceGrouped[$key][$record['session']] = ucfirst($record['status']);
    }

    $stmtAll = $pdo->query("SELECT full_name, username FROM employees ORDER BY full_name ASC");
    $allEmployees = $stmtAll->fetchAll(PDO::FETCH_ASSOC);

    $stmtSigned = $pdo->prepare("SELECT DISTINCT username, date, session FROM attendance WHERE date BETWEEN ? AND ?");
    $stmtSigned->execute([$startDate, $endDate]);
    $signed = $stmtSigned->fetchAll(PDO::FETCH_ASSOC);

    $signedMap = [];
    foreach ($signed as $row) {
        $signedMap[$row['date']][$row['session']][] = $row['username'];
    }

    $period = new DatePeriod(
        new DateTime($startDate),
        new DateInterval('P1D'),
        (new DateTime($endDate))->modify('+1 day')
    );

    foreach ($period as $dateObj) {
        $dateStr = $dateObj->format('Y-m-d');
        foreach (["AM", "PM"] as $session) {
            foreach ($allEmployees as $employee) {
                $key = $employee['full_name'] . '_' . $dateStr;
                if (!isset($attendanceGrouped[$key])) {
                    $attendanceGrouped[$key] = [
                        'full_name' => $employee['full_name'],
                        'date' => $dateStr,
                        'AM' => 'Absent',
                        'PM' => 'Absent'
                    ];
                }
                if (!in_array($employee['username'], $signedMap[$dateStr][$session] ?? [])) {
                    $attendanceGrouped[$key][$session] = 'Absent';
                }
            }
        }
    }

} catch (PDOException $e) {
    $error = "Error fetching attendance: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>HR Attendance View</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; background: #f9fafb; color: #333; }
    .container { max-width: 1000px; margin: 0 auto; }
    h2 { text-align: center; color: #003366; margin-bottom: 20px; }
    table { width: 100%; border-collapse: collapse; background: #fff; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
    th, td { padding: 10px 15px; border-bottom: 1px solid #ddd; text-align: left; }
    th { background-color: #003366; color: #FFCC00; font-weight: 700; }
    tr:hover { background-color: #f1f1f1; }
    .present { color: green; font-weight: bold; }
    .absent { color: red; font-weight: bold; }
    .form-container { margin-bottom: 20px; text-align: center; }
    input, select { padding: 6px 10px; font-size: 16px; border: 1px solid #ccc; border-radius: 5px; margin-right: 10px; }
    button, .export-btn {
      padding: 7px 16px;
      background-color: #003366;
      color: #FFCC00;
      border: none;
      border-radius: 6px;
      font-weight: 700;
      cursor: pointer;
      text-decoration: none;
      margin-top: 10px;
      display: inline-block;
    }
    button:hover, .export-btn:hover { background-color: #FFCC00; color: #003366; }
    .error { color: red; font-weight: bold; text-align: center; margin-bottom: 20px; }
    .back-btn {
      display: inline-block;
      margin-top: 25px;
      padding: 10px 20px;
      background-color: #003366;
      color: #FFCC00;
      text-decoration: none;
      font-weight: 700;
      border-radius: 8px;
    }
    .back-btn:hover { background-color: #FFCC00; color: #003366; }
  </style>
</head>
<body>
  <div class="container">
    <h2>Attendance Records (<?= htmlspecialchars(ucfirst($viewMode)) ?>)</h2>

    <div class="form-container">
      <form method="GET" action="">
        <label for="date">Select Date: </label>
        <input type="date" id="date" name="date" value="<?= htmlspecialchars($selectedDate) ?>" min="<?= htmlspecialchars($minDate) ?>" max="<?= $today ?>" required>
        <select name="view" id="view">
          <option value="daily" <?= $viewMode === 'daily' ? 'selected' : '' ?>>Daily</option>
          <option value="weekly" <?= $viewMode === 'weekly' ? 'selected' : '' ?>>Weekly</option>
          <option value="monthly" <?= $viewMode === 'monthly' ? 'selected' : '' ?>>Monthly</option>
        </select>
        <button type="submit">View</button>
      </form>

      <form method="post" action="export_attendance.php" style="margin-top:10px;">
        <input type="hidden" name="start_date" value="<?= htmlspecialchars($startDate) ?>">
        <input type="hidden" name="end_date" value="<?= htmlspecialchars($endDate) ?>">
        <button class="export-btn" name="export" value="excel">Export to Excel</button>
        <button class="export-btn" name="export" value="word">Export to Word</button>
      </form>
    </div>

    <?php if (!empty($error)): ?>
      <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <table>
      <thead>
        <tr>
          <th>Employee Name</th>
          <th>Date</th>
          <th>AM Status</th>
          <th>PM Status</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($attendanceGrouped as $record): ?>
        <tr>
          <td><?= htmlspecialchars($record['full_name']) ?></td>
          <td><?= htmlspecialchars($record['date']) ?></td>
          <td class="<?= strtolower($record['AM']) ?>"><?= htmlspecialchars($record['AM']) ?></td>
          <td class="<?= strtolower($record['PM']) ?>"><?= htmlspecialchars($record['PM']) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>

    <p style="text-align: center;">
      <a href="dashboard_hr.php" class="back-btn">← Back to Dashboard</a>
    </p>
  </div>
</body>
</html>
