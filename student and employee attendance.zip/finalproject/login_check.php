<?php
session_start();
include 'dbe.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Check user credentials and active status
    $stmt = $conn->prepare("SELECT username, password, role, full_name, is_active FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Check if user account is active
        if (!$user['is_active']) {
            $error = "Your account has been deactivated. Please contact the administrator.";
            header("Location: login.php?error=" . urlencode($error));
            exit;
        }
        
        // Verify password
        if (password_verify($password, $user['password'])) {
            // Set session variables
            $_SESSION['user'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['full_name'] = $user['full_name'];
            
            // Redirect based on role
            switch ($user['role']) {
                case 'admin':
                    header("Location: admin_dashboard.php");
                    break;
                case 'hr':
                    header("Location: dashboard_hr.php");
                    break;
                case 'employee':
                    header("Location: employee_dashboard.php");
                    break;
                default:
                    header("Location: login.php?error=Invalid role");
            }
            exit;
        } else {
            $error = "Invalid username or password.";
        }
    } else {
        $error = "Invalid username or password.";
    }
    
    $stmt->close();
    header("Location: login.php?error=" . urlencode($error));
    exit;
} else {
    header("Location: login.php");
    exit;
}
?>