<?php
include 'dbe.php';

header("Content-Type: application/vnd.ms-word");
header("Content-Disposition: attachment; filename=attendance_report.doc");

$range = $_POST['range'];
$query = "SELECT full_name, username, date, status FROM attendance";

if ($range === 'daily') {
    $query .= " WHERE date = CURDATE()";
} elseif ($range === 'weekly') {
    $query .= " WHERE WEEK(date) = WEEK(CURDATE())";
} elseif ($range === 'monthly') {
    $query .= " WHERE MONTH(date) = MONTH(CURDATE())";
}

$result = $conn->query($query);
echo "<h2>Attendance Report</h2><table border='1'><tr><th>Full Name</th><th>Username</th><th>Date</th><th>Status</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr><td>{$row['full_name']}</td><td>{$row['username']}</td><td>{$row['date']}</td><td>{$row['status']}</td></tr>";
}
echo "</table>";
?>
