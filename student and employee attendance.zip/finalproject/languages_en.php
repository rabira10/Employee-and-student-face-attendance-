<?php
return [
    'welcome' => 'Welcome, Student Dean!',
    'manage_records' => 'Manage student attendance and academic records from your centralized dashboard',
    'welcome_student_dean' => '🎓 Welcome, Student Dean!',
    'welcome_message' => 'Welcome to the Student Dean Dashboard of Dire Dawa University. Here, you can manage student attendance, review performance, and foster a supportive academic environment. Thank you for your leadership!',

    // Navigation
    'student_management' => 'Student Management',
    'quick_actions' => 'Quick Actions',
    'view_students' => 'View All Students',
    'attendance_reports' => 'Attendance Reports',
    'download_reports' => 'Download Reports',
    'send_notifications' => 'Send Notifications',
    'manage_accounts' => 'Manage Accounts',
    'register_student' => 'Register Student',
    'change_password' => 'Change Password',
    'logout' => 'Logout',

    // Attendance Time
    'attendance_window' => 'Attendance Time Window',
    'current_settings' => 'Current Settings',
    'start_time' => 'Start Time',
    'end_time' => 'End Time',
    'save_attendance' => 'Save Attendance Time',

    // Header & Portal Info
    'dire_dawa_university' => 'Dire Dawa University',
    'student_dean_portal' => 'Student Dean Portal',
    'student_dean' => 'Student Dean',

    // Help Center
    'help_center' => 'Help Center',
    'help_center_description' => 'Find answers to common questions and learn how to use the Student Dean Portal effectively.',
    'search_help_articles' => 'Search help articles',
    'help_categories' => 'Help Categories',
    'attendance' => 'Attendance',
    'reports' => 'Reports',
    'account_settings' => 'Account Settings',
    'frequently_asked_questions' => 'Frequently Asked Questions',
    'how_to_set_attendance_time' => 'How to set attendance time?',
    'attendance_time_instructions' => 'Go to the Attendance section, select the course, and set the time window for attendance. You can specify different times for different days of the week.',
    'how_to_generate_reports' => 'How to generate reports?',
    'report_generation_instructions' => 'Navigate to the Reports section, select the type of report you need (attendance, academic performance, etc.), set the date range, and click Generate.',
    'how_to_register_student' => 'How to register a new student?',
    'student_registration_instructions' => 'In the Student Management section, click "Add New Student", fill in all required information, and submit. The system will generate student credentials automatically.',
    'how_to_change_password' => 'How to change my password?',
    'password_change_instructions' => 'Click on your profile icon in the top right corner, select "Account Settings", then "Change Password". Enter your current password and the new password twice.',
    'still_need_help' => 'Still need help?',
    'contact_our_support_team' => 'Contact our support team for additional assistance.',
    'contact_support' => 'Contact Support',

    // Footer
    'footer_about_text' => 'Committed to excellence in education and student services.',
    'quick_links' => 'Quick Links',
    'university_website' => 'University Website',
    'contact_us' => 'Contact Us',
    'contact_info' => 'Contact Information',
    'university_address' => 'P.O.Box 1362, Dire Dawa, Ethiopia',
    'all_rights_reserved' => 'All rights reserved.'
];
