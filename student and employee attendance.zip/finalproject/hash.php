<?php
$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SHOW COLUMNS FROM students");
while ($row = $result->fetch_assoc()) {
    echo $row['Field'] . "<br>";
}
?>
