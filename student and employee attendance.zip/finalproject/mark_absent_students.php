<?php
file_put_contents('C:/xamp/htdocs/finalproject/log.txt', "Script started at " . date('Y-m-d H:i:s') . PHP_EOL, FILE_APPEND);

// DB connection
$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

date_default_timezone_set('Africa/Addis_Ababa');

$today = date('Y-m-d');

// Check if already marked absent today (optional)
$checkSql = "SELECT COUNT(*) as cnt FROM student_attendance WHERE attendance_date = ? AND status = 'absent'";
$stmtCheck = $conn->prepare($checkSql);
$stmtCheck->bind_param("s", $today);
$stmtCheck->execute();
$result = $stmtCheck->get_result()->fetch_assoc();

if ($result['cnt'] > 0) {
    echo "Student absences already marked today.\n";
    exit;
}

// Get students who didn't mark attendance today
$sql = "
    SELECT s.student_id 
    FROM students s
    LEFT JOIN student_attendance a 
      ON s.student_id = a.student_id AND a.attendance_date = ?
    WHERE a.student_id IS NULL
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $today);
$stmt->execute();
$result = $stmt->get_result();

$absent_students = [];
while ($row = $result->fetch_assoc()) {
    $absent_students[] = $row['student_id'];
}

// Mark absent for missing students
if (count($absent_students) > 0) {
    $stmtInsert = $conn->prepare("
        INSERT INTO student_attendance (student_id, attendance_date, status) 
        VALUES (?, ?, 'absent')
    ");
    foreach ($absent_students as $student_id) {
        $stmtInsert->bind_param("is", $student_id, $today);
        $stmtInsert->execute();
    }
    echo count($absent_students) . " students marked absent.\n";
} else {
    echo "No absent students found.\n";
}

$conn->close();
file_put_contents('C:/xamp/htdocs/finalproject/log.txt', "Script ended at " . date('Y-m-d H:i:s') . PHP_EOL, FILE_APPEND);
