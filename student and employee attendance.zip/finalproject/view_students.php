<?php
session_start();

// Language support
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

$default_lang = 'en'; // Default language
$current_lang = $_SESSION['lang'] ?? $default_lang;

// Load translations
$translations = [];
$lang_file = "languages/{$current_lang}.php";
if (file_exists($lang_file)) {
    $translations = require $lang_file;
}

// Helper function for translations
function t($key, $translations) {
    return $translations[$key] ?? $key;
}

// Only allow access if user is logged in and role is 'student_dean'
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student_dean') {
    header("Location: login.php");
    exit();
}

// Database connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "ddu_attendance";

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and execute query
$sql = "SELECT id, full_name, department FROM students";
$result = $conn->query($sql);

// Check for query error
if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo t('view_all_students', $translations); ?> - <?php echo t('dire_dawa_university', $translations); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #003366 0%, #1a4d6b 100%);
            min-height: 100vh;
            color: #333;
            line-height: 1.6;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideIn {
            from { transform: translateX(-30px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        /* Header */
        .header {
            background: white;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border-bottom: 4px solid #FFCC00;
            padding: 1.5rem 0;
            animation: slideIn 0.6s ease-out;
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .logo {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #003366, #004080);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
            box-shadow: 0 4px 15px rgba(0,51,102,0.3);
        }

        .university-info h1 {
            color: #003366;
            font-size: 1.8rem;
            margin-bottom: 0.2rem;
            font-weight: 700;
        }

        .university-info p {
            color: #666;
            font-size: 1rem;
            font-weight: 500;
        }

        .dean-section {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .dean-badge {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
            padding: 0.8rem 1.5rem;
            border-radius: 25px;
            font-weight: bold;
            font-size: 1rem;
            box-shadow: 0 4px 15px rgba(255,204,0,0.3);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .language-switcher {
            display: flex;
            gap: 0.5rem;
            margin-left: 1rem;
        }

        .language-switcher a {
            padding: 0.5rem;
            border-radius: 4px;
            text-decoration: none;
            color: var(--primary-color);
            font-weight: 500;
            font-size: 0.9rem;
            transition: var(--transition);
            color: #003366;
        }

        .language-switcher a:hover {
            background: rgba(255, 204, 0, 0.2);
        }

        .language-switcher a.active {
            background: #FFCC00;
            color: #003366;
            font-weight: 600;
        }

        /* Main Container */
        .container {
            max-width: 1400px;
            margin: 2rem auto;
            padding: 2rem;
            animation: fadeIn 0.8s ease-out;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }

        h2 {
            color: #003366;
            font-size: 2rem;
            margin-bottom: 1.5rem;
            font-weight: 700;
        }

        /* Table Styles */
        .students-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1.5rem;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .students-table th {
            background: #003366;
            color: white;
            padding: 1rem;
            text-align: left;
            font-weight: 600;
        }

        .students-table td {
            padding: 1rem;
            border-bottom: 1px solid #e1e5e9;
        }

        .students-table tr:last-child td {
            border-bottom: none;
        }

        .students-table tr:nth-child(even) {
            background-color: #f8f9fa;
        }

        .students-table tr:hover {
            background-color: rgba(255, 204, 0, 0.1);
        }

        .no-students {
            text-align: center;
            padding: 2rem;
            color: #666;
        }

        /* Footer Styles */
        footer {
            background: #003366;
            color: white;
            padding: 2rem 0;
            margin-top: 3rem;
        }

        .footer-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
        }

        .footer-content {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 2rem;
        }

        .footer-section {
            flex: 1;
            min-width: 250px;
        }

        .footer-section h3 {
            color: #FFCC00;
            margin-bottom: 1rem;
            font-size: 1.2rem;
        }

        .footer-section p, .footer-section address {
            line-height: 1.6;
        }

        .footer-section address {
            font-style: normal;
        }

        .footer-section ul {
            list-style: none;
            line-height: 2;
        }

        .footer-section a {
            color: white;
            text-decoration: none;
        }

        .footer-section a:hover {
            text-decoration: underline;
            color: #FFCC00;
        }

        .footer-bottom {
            border-top: 1px solid rgba(255, 204, 0, 0.3);
            margin-top: 2rem;
            padding-top: 1.5rem;
            text-align: center;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }

            .container {
                padding: 1rem;
            }

            .university-info h1 {
                font-size: 1.5rem;
            }

            .language-switcher {
                margin-left: 0;
                margin-top: 0.5rem;
                justify-content: center;
                width: 100%;
            }

            .footer-content {
                flex-direction: column;
            }

            .students-table {
                display: block;
                overflow-x: auto;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-content">
            <div class="logo-section">
                <div class="logo">DDU</div>
                <div class="university-info">
                    <h1><?php echo t('dire_dawa_university', $translations); ?></h1>
                    <p><?php echo t('student_dean_portal', $translations); ?></p>
                </div>
            </div>
            <div class="dean-section">
                <div class="language-switcher">
                    <a href="?lang=en" class="<?php echo $current_lang === 'en' ? 'active' : ''; ?>">English</a>
                    <a href="?lang=am" class="<?php echo $current_lang === 'am' ? 'active' : ''; ?>">አማርኛ</a>
                </div>
                <div class="dean-badge">
                    <i class="fas fa-user-graduate"></i>
                    <?php echo t('student_dean', $translations); ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container">
        <h2><?php echo t('all_students', $translations); ?></h2>
        
        <table class="students-table">
            <thead>
                <tr>
                    <th><?php echo t('student_id', $translations); ?></th>
                    <th><?php echo t('full_name', $translations); ?></th>
                    <th><?php echo t('department', $translations); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id']) ?></td>
                        <td><?= htmlspecialchars($row['full_name']) ?></td>
                        <td><?= htmlspecialchars($row['department']) ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3" class="no-students">
                            <?php echo t('no_students_found', $translations); ?>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3><?php echo t('dire_dawa_university', $translations); ?></h3>
                    <p><?php echo t('footer_about_text', $translations); ?></p>
                </div>
                <div class="footer-section">
                    <h3><?php echo t('quick_links', $translations); ?></h3>
                    <ul>
                        <li><a href="https://www.ddu.edu.et"><?php echo t('university_website', $translations); ?></a></li>
                        <li><a href="contact.php"><?php echo t('contact_us', $translations); ?></a></li>
                        <li><a href="help.php"><?php echo t('help_center', $translations); ?></a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3><?php echo t('contact_info', $translations); ?></h3>
                    <address>
                        <p><i class="fas fa-map-marker-alt"></i> <?php echo t('university_address', $translations); ?></p>
                        <p><i class="fas fa-phone"></i> +251 25 111 2233</p>
                        <p><i class="fas fa-envelope"></i> studentdean@ddu.edu.et</p>
                    </address>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php echo t('dire_dawa_university', $translations); ?>. <?php echo t('all_rights_reserved', $translations); ?></p>
            </div>
        </div>
    </footer>

    <!-- Font Awesome for icons -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>

<?php
$conn->close();
?>