<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'employee') {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['user'];

// Set default language to English if not set
if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'en';
}

// Handle language change
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

// Language translations
$translations = [
    'en' => [
        'title' => 'Employee Dashboard - Dire Dawa University',
        'welcome' => 'Welcome, %s!',
        'dashboard_title' => 'Dire Dawa University Employee Dashboard',
        'staff_member' => 'Staff Member',
        'active_employee' => 'Active Employee',
        'about_title' => 'About Dire Dawa University',
        'about_text' => 'As a valued member of the Dire Dawa University community, you contribute to our mission of excellence in higher education. Located in the vibrant city of Dire Dawa, our university serves as a beacon of knowledge and innovation in eastern Ethiopia. Together, we\'re building the future through education, research, and community service.',
        'notifications' => 'Recent Notifications',
        'view_attendance' => 'View My Attendance',
        'sign_attendance' => 'Sign Attendance',
        'leave_request' => 'Annual Leave Request',
        'view_leave' => 'View Leave Requests',
        'change_password' => 'Change Password',
        'logout' => 'Logout',
        'footer_text' => 'Select an action above to get started with your employee tasks',
        'university_name' => 'Dire Dawa University',
        'employee_portal' => 'Employee Portal System',
        'serving_since' => 'Serving Excellence Since 2006',
        'location' => 'Dire Dawa, Ethiopia',
        'dashboard' => 'Dashboard',
        'attendance' => 'Attendance',
        'leave' => 'Leave',
        'profile' => 'Profile',
        'scroll_to_top' => 'Go to top',
        'quick_links' => 'Quick Links',
        'contact_us' => 'Contact Us',
        'privacy_policy' => 'Privacy Policy',
        'terms_of_service' => 'Terms of Service',
        'copyright' => 'Copyright © 2023 Dire Dawa University. All rights reserved.',
        'developed_by' => 'Developed by ICT Directorate',
        'phone' => 'Phone',
        'email' => 'Email',
        'address' => 'Address'
    ],
    'am' => [
        'title' => 'የሰራተኛ ዳሽቦርድ - ድሬዳዋ ዩኒቨርሲቲ',
        'welcome' => 'እንኳን ደህና መጡ፣ %s!',
        'dashboard_title' => 'ድሬዳዋ ዩኒቨርሲቲ የሰራተኛ ዳሽቦርድ',
        'staff_member' => 'የስታፍ አባል',
        'active_employee' => 'ንቁ ሰራተኛ',
        'about_title' => 'ስለ ድሬዳዋ ዩኒቨርሲቲ',
        'about_text' => 'ድሬዳዋ ዩኒቨርሲቲ �ናው የትምህርት ማህበረሰብ አባል እንደመሆንዎ የእኛን የትምህርት ልሂቅ እና ምርምር እንዲያሳኩ ያስተዋሉ። በተለያዩ ብልህ ከተማ ድሬዳዋ ውስጥ የምንገኝ ዩኒቨርሲቲአችን በምሥራቅ ኢትዮጵያ �ና �ዕውቀት እና ፈጠራ ውስጥ መብራት ነው። በጋራ በትምህርት፣ ምርምር እና የማህበረሰብ አገልግሎት የወደፊቱን እየገነባን ነው።',
        'notifications' => 'የቅርብ ማሳወቂያዎች',
        'view_attendance' => 'የእኔን መገኘት ይመልከቱ',
        'sign_attendance' => 'መገኘት ይፈርሙ',
        'leave_request' => 'ዓመታዊ ፈቃድ መጠየቂያ',
        'view_leave' => 'የፈቃድ መጠየቂያዎችን ይመልከቱ',
        'change_password' => 'የይለፍ ቃል ይቀይሩ',
        'logout' => 'ውጣ',
        'footer_text' => 'ከላይ ያሉትን ድርጊቶች በመምረጥ ከሰራተኛ ተግባሮችዎ ጋር ይጀምሩ',
        'university_name' => 'ድሬዳዋ ዩኒቨርሲቲ',
        'employee_portal' => 'የሰራተኛ ፖርታል ስርዓት',
        'serving_since' => 'ከ2006 ጀምሮ አገልግሎት ይሰጣል',
        'location' => 'ድሬዳዋ, ኢትዮጵያ',
        'dashboard' => 'ዳሽቦርድ',
        'attendance' => 'መገኘት',
        'leave' => 'ፈቃድ',
        'profile' => 'መገለጫ',
        'scroll_to_top' => 'ወደ ላይ ይሂዱ',
        'quick_links' => 'ፈጣን አገናኞች',
        'contact_us' => 'አግኙን',
        'privacy_policy' => 'የግላዊነት ፖሊሲ',
        'terms_of_service' => 'የአገልግሎት ውሎች',
        'copyright' => 'የቅጂ መብት © 2023 ድሬዳዋ ዩኒቨርሲቲ. ሁሉም መብቶች የተጠበቁ ናቸው።',
        'developed_by' => 'በ ICT ዳይሬክቶሬት የተዘጋጀ',
        'phone' => 'ስልክ',
        'email' => 'ኢሜይል',
        'address' => 'አድራሻ'
    ]
];

$lang = $_SESSION['lang'];
$t = $translations[$lang];

// DB connection
$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch employee details
$stmt = $conn->prepare("SELECT full_name FROM employees WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$employee = $result->fetch_assoc();
$full_name = $employee ? $employee['full_name'] : $username;

// Fetch unread notifications
$stmt = $conn->prepare("SELECT id, message FROM notifications WHERE username = ? AND is_read = 0 ORDER BY created_at DESC");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$notifications = $result->fetch_all(MYSQLI_ASSOC);

// Mark notifications as read after displaying
if (!empty($notifications)) {
    $mark_read = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE username = ? AND is_read = 0");
    $mark_read->bind_param("s", $username);
    $mark_read->execute();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo $t['title']; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #003366 0%, #1a4d6b 100%);
            min-height: 100vh;
            color: #333;
            display: flex;
            flex-direction: column;
        }

        /* Header */
        .header {
            background: white;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border-bottom: 4px solid #FFCC00;
            padding: 1rem 0;
            position: relative;
        }

        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .logo {
            width: 60px;
            height: 60px;
            background: #003366;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
        }

        .university-info h1 {
            color: #003366;
            font-size: 1.8rem;
            margin-bottom: 0.2rem;
        }

        .university-info p {
            color: #666;
            font-size: 0.9rem;
        }

        .location {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: #666;
            font-size: 0.9rem;
        }

        /* Navigation Menu */
        .nav-menu {
            display: flex;
            gap: 1.5rem;
            margin-left: 2rem;
        }

        .nav-item {
            position: relative;
        }

        .nav-link {
            color: #003366;
            text-decoration: none;
            font-weight: 600;
            padding: 0.5rem 0;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.3rem;
        }

        .nav-link:hover {
            color: #FFCC00;
        }

        .nav-link.active {
            color: #FFCC00;
            border-bottom: 2px solid #FFCC00;
        }

        /* Dropdown Menu */
        .dropdown {
            position: relative;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: white;
            min-width: 200px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            z-index: 1;
            border-radius: 5px;
            top: 100%;
            left: 0;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown-link {
            color: #003366;
            padding: 0.8rem 1rem;
            text-decoration: none;
            display: block;
            transition: all 0.3s ease;
        }

        .dropdown-link:hover {
            background-color: #f0f9ff;
            color: #FFCC00;
        }

        /* Modern Language Toggle */
        .language-switcher {
            position: absolute;
            top: 1rem;
            right: 1rem;
            display: flex;
            background: #f0f0f0;
            border-radius: 30px;
            padding: 3px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .language-btn {
            background: transparent;
            color: #666;
            border: none;
            padding: 0.5rem 1.2rem;
            border-radius: 25px;
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 600;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.3rem;
        }

        .language-btn:hover {
            color: #003366;
        }

        .language-btn.active {
            background: #003366;
            color: white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }

        .language-btn.active:hover {
            background: #1a4d6b;
        }

        .language-icon {
            font-size: 1rem;
        }

        /* Main Container */
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
            flex: 1;
        }

        /* Welcome Card */
        .welcome-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        }

        .welcome-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1.5rem;
        }

        .welcome-text h2 {
            color: #003366;
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }

        .welcome-text p {
            color: #666;
            font-size: 1.1rem;
        }

        .employee-status {
            text-align: right;
        }

        .status-badge {
            background: #FFCC00;
            color: #003366;
            padding: 0.5rem 1rem;
            border-radius: 25px;
            font-weight: bold;
            font-size: 0.9rem;
            display: inline-block;
            margin-top: 0.5rem;
        }

        .about-section {
            background: linear-gradient(to right, #f0f9ff, #fffbf0);
            padding: 1.5rem;
            border-radius: 10px;
            border-left: 4px solid #003366;
        }

        .about-section h3 {
            color: #003366;
            margin-bottom: 1rem;
        }

        .about-section p {
            color: #555;
            line-height: 1.6;
        }

        /* Notifications */
        .notifications {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        }

        .notifications h3 {
            color: #003366;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .notification-item {
            background: #f0f9ff;
            border-left: 4px solid #FFCC00;
            padding: 1rem;
            margin-bottom: 0.5rem;
            border-radius: 5px;
        }

        /* Navigation Grid */
        .nav-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .nav-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 0;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            overflow: hidden;
        }

        .nav-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(0,0,0,0.15);
        }

        .nav-button {
            width: 100%;
            background: #003366;
            color: white;
            border: none;
            padding: 2rem;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: none;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1rem;
            text-decoration: none;
        }

        .nav-button:hover {
            background: #FFCC00;
            color: #003366;
            transform: scale(1.02);
        }

        .nav-icon {
            font-size: 2rem;
        }

        /* Scroll to top button */
        .scroll-to-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 50px;
            height: 50px;
            background:#FFCC00;
            color: white;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            z-index: 1000;
        }
        
        .scroll-to-top.visible {
            opacity: 1;
            visibility: visible;
        }
        
        .scroll-to-top:hover {
            background: #FFCC00;
            color: yellow;
            transform: translateY(-3px);
        }

        /* Footer */
        .footer {
            background: #003366;
            color: white;
            padding: 2rem 0;
            margin-top: auto;
        }

        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 2rem;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
        }

        .footer-section {
            margin-bottom: 1.5rem;
        }

        .footer-section h3 {
            color: #FFCC00;
            margin-bottom: 1rem;
            font-size: 1.2rem;
            position: relative;
            padding-bottom: 0.5rem;
        }

        .footer-section h3::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 50px;
            height: 2px;
            background: #FFCC00;
        }

        .footer-links {
            list-style: none;
        }

        .footer-links li {
            margin-bottom: 0.5rem;
        }

        .footer-links a {
            color: #ddd;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-block;
        }

        .footer-links a:hover {
            color: #FFCC00;
            transform: translateX(5px);
        }

        .contact-info {
            list-style: none;
        }

        .contact-info li {
            margin-bottom: 0.8rem;
            display: flex;
            align-items: flex-start;
            gap: 0.5rem;
        }

        .contact-info i {
            color: #FFCC00;
            margin-top: 3px;
        }

        .footer-bottom {
            background: #002244;
            padding: 1rem 0;
            text-align: center;
            margin-top: 2rem;
        }

        .footer-bottom p {
            color: #aaa;
            font-size: 0.9rem;
            margin-bottom: 0;
        }

        .footer-bottom p a {
            color: #FFCC00;
            text-decoration: none;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
                padding-top: 2.5rem;
            }

            .nav-menu {
                margin-left: 0;
                flex-direction: column;
                gap: 0.5rem;
                width: 100%;
                margin-top: 1rem;
            }

            .dropdown-content {
                position: static;
                box-shadow: none;
                width: 100%;
            }

            .welcome-header {
                flex-direction: column;
                gap: 1rem;
            }

            .employee-status {
                text-align: left;
            }

            .nav-grid {
                grid-template-columns: 1fr;
            }

            .container {
                padding: 1rem;
            }
            
            .language-switcher {
                position: absolute;
                top: 0.5rem;
                right: 50%;
                transform: translateX(50%);
            }
            
            .scroll-to-top {
                bottom: 20px;
                right: 20px;
                width: 40px;
                height: 40px;
                font-size: 1.2rem;
            }

            .footer-container {
                grid-template-columns: 1fr;
                padding: 0 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <!-- Modern Language Toggle -->
        <div class="language-switcher">
            <a href="?lang=en" class="language-btn <?php echo $lang === 'en' ? 'active' : ''; ?>">
                <span class="language-icon">🌐</span>
                English
            </a>
            <a href="?lang=am" class="language-btn <?php echo $lang === 'am' ? 'active' : ''; ?>">
                <span class="language-icon">🇪🇹</span>
                አማርኛ
            </a>
        </div>

        <div class="header-content">
            <div class="logo-section">
                <div class="logo">DDU</div>
                <div class="university-info">
                    <h1><?php echo $t['university_name']; ?></h1>
                    <p><?php echo $t['employee_portal']; ?></p>
                </div>
            </div>
            
            <!-- Navigation Menu -->
            <nav class="nav-menu">
                <div class="nav-item">
                    <a href="dashboard_employee.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard_employee.php' ? 'active' : ''; ?>">
                        <span>📊</span>
                        <?php echo $t['dashboard']; ?>
                    </a>
                </div>
                
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link">
                        <span>🕒</span>
                        <?php echo $t['attendance']; ?>
                        <span>▼</span>
                    </a>
                    <div class="dropdown-content">
                        <a href="view_attendancee.php" class="dropdown-link"><?php echo $t['view_attendance']; ?></a>
                        <a href="face_verification.php" class="dropdown-link"><?php echo $t['sign_attendance']; ?></a>
                    </div>
                </div>
                
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link">
                        <span>📝</span>
                        <?php echo $t['leave']; ?>
                        <span>▼</span>
                    </a>
                    <div class="dropdown-content">
                        <a href="annual_leave_request.php" class="dropdown-link"><?php echo $t['leave_request']; ?></a>
                        <a href="view_leave_requests.php" class="dropdown-link"><?php echo $t['view_leave']; ?></a>
                    </div>
                </div>
                
                <div class="nav-item">
                    <a href="change_password_form.php" class="nav-link">
                        <span>👤</span>
                        <?php echo $t['profile']; ?>
                    </a>
                </div>
            </nav>
            
            <div class="location">
                <span>📍</span>
                <span><?php echo $t['location']; ?></span>
            </div>
        </div>
    </div>

    <!-- Main Container -->
    <div class="container">
        <!-- Welcome Section -->
        <div class="welcome-card">
            <div class="welcome-header">
                <div class="welcome-text">
                    <h2><?php echo sprintf($t['welcome'], htmlspecialchars($full_name)); ?></h2>
                    <p><?php echo $t['dashboard_title']; ?></p>
                </div>
                <div class="employee-status">
                    <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                        <span>👥</span>
                        <span style="font-weight: 600; color: #003366;"><?php echo $t['staff_member']; ?></span>
                    </div>
                    <span class="status-badge"><?php echo $t['active_employee']; ?></span>
                </div>
            </div>
            
            <div class="about-section">
                <h3><?php echo $t['about_title']; ?></h3>
                <p>
                    <?php echo $t['about_text']; ?>
                </p>
            </div>
        </div>

        <!-- Notifications -->
        <?php if (!empty($notifications)): ?>
        <div class="notifications">
            <h3>
                <span>🔔</span>
                <?php echo $t['notifications']; ?>
            </h3>
            <?php foreach ($notifications as $note): ?>
                <div class="notification-item">
                    <?php echo htmlspecialchars($note['message']); ?>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- Navigation Grid -->
        <div class="nav-grid">
            <div class="nav-card">
                <a href="view_attendancee.php" class="nav-button">
                    <div class="nav-icon">📅</div>
                    <span><?php echo $t['view_attendance']; ?></span>
                </a>
            </div>
            
            <div class="nav-card">
                <a href="face_verification.php" class="nav-button">
                    <div class="nav-icon">🕒</div>
                    <span><?php echo $t['sign_attendance']; ?></span>
                </a>
            </div>
            
            <div class="nav-card">
                <a href="annual_leave_request.php" class="nav-button">
                    <div class="nav-icon">📝</div>
                    <span><?php echo $t['leave_request']; ?></span>
                </a>
            </div>
            
            <div class="nav-card">
                <a href="view_leave_requests.php" class="nav-button">
                    <div class="nav-icon">📋</div>
                    <span><?php echo $t['view_leave']; ?></span>
                </a>
            </div>
            
            <div class="nav-card">
                <a href="change_password_form.php" class="nav-button">
                    <div class="nav-icon">🔒</div>
                    <span><?php echo $t['change_password']; ?></span>
                </a>
            </div>
            
            <div class="nav-card">
                <a href="logout.php" class="nav-button">
                    <div class="nav-icon">🚪</div>
                    <span><?php echo $t['logout']; ?></span>
                </a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h3><?php echo $t['university_name']; ?></h3>
                <p><?php echo $t['about_text']; ?></p>
            </div>
            
            <div class="footer-section">
                <h3><?php echo $t['quick_links']; ?></h3>
                <ul class="footer-links">
                    <li><a href="dashboard_employee.php"><?php echo $t['dashboard']; ?></a></li>
                    <li><a href="view_attendancee.php"><?php echo $t['view_attendance']; ?></a></li>
                    <li><a href="annual_leave_request.php"><?php echo $t['leave_request']; ?></a></li>
                    <li><a href="change_password_form.php"><?php echo $t['change_password']; ?></a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h3><?php echo $t['contact_us']; ?></h3>
                <ul class="contact-info">
                    <li>
                        <span>📞</span>
                        <div>
                            <strong><?php echo $t['phone']; ?>:</strong> +251 25 111 2233
                        </div>
                    </li>
                    <li>
                        <span>✉️</span>
                        <div>
                            <strong><?php echo $t['email']; ?>:</strong> info@ddu.edu.et
                        </div>
                    </li>
                    <li>
                        <span>📍</span>
                        <div>
                            <strong><?php echo $t['address']; ?>:</strong> <?php echo $t['location']; ?>
                        </div>
                    </li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h3><?php echo $t['employee_portal']; ?></h3>
                <ul class="footer-links">
                    <li><a href="#"><?php echo $t['privacy_policy']; ?></a></li>
                    <li><a href="#"><?php echo $t['terms_of_service']; ?></a></li>
                    <li><a href="#">Help Center</a></li>
                </ul>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p><?php echo $t['copyright']; ?> | <?php echo $t['developed_by']; ?></p>
        </div>
    </footer>

    <!-- Scroll to top button -->
    <button class="scroll-to-top" id="scrollToTopBtn" title="<?php echo $t['scroll_to_top']; ?>">↑</button>

    <script>
        // Scroll to top button functionality
        const scrollToTopBtn = document.getElementById("scrollToTopBtn");
        
        // Show the button when user scrolls down 300px from the top
        window.onscroll = function() {
            if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
                scrollToTopBtn.classList.add("visible");
            } else {
                scrollToTopBtn.classList.remove("visible");
            }
        };
        
        // Scroll to top when button is clicked
        scrollToTopBtn.addEventListener("click", function() {
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        });
    </script>
</body>
</html>