<?php
session_start();

/* ──────────────────────────────────
   1.  AUTH CHECK
   ────────────────────────────────── */
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit();
}

/* ──────────────────────────────────
   2.  DB CONNECTION
   ────────────────────────────────── */
$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

/* ──────────────────────────────────
   3.  INITIALIZE VARIABLES
   ────────────────────────────────── */
$student_id = $_SESSION['student_id'] ?? null;
$attendanceMessage = '';
$messageType = '';

/* ──────────────────────────────────
   4.  TIME-ZONE
   ────────────────────────────────── */
date_default_timezone_set('Africa/Addis_Ababa');

/* ──────────────────────────────────
   5.  FETCH ATTENDANCE TIME WINDOW AND ENABLE FLAGS FROM DB
   ────────────────────────────────── */
$am_start = null;
$am_end = null;
$pm_start = null;
$pm_end = null;
$am_enabled = 0;
$pm_enabled = 0;

$settingsRes = $conn->query("SELECT am_start, am_end, pm_start, pm_end, am_enabled, pm_enabled FROM student_attendance_settings LIMIT 1");

if ($settingsRes && $settingsRes->num_rows > 0) {
    $row = $settingsRes->fetch_assoc();
    $am_start = $row['am_start'];
    $am_end = $row['am_end'];
    $pm_start = $row['pm_start'];
    $pm_end = $row['pm_end'];
    $am_enabled = intval($row['am_enabled']);
    $pm_enabled = intval($row['pm_enabled']);
} else {
    // fallback defaults
    $am_start = "08:00:00";
    $am_end = "10:00:00";
    $pm_start = "13:00:00";
    $pm_end = "15:00:00";
    $am_enabled = 1;
    $pm_enabled = 1;
}

/* ──────────────────────────────────
   6.  FETCH STUDENT META
   ────────────────────────────────── */
$stmt = $conn->prepare("SELECT full_name, face_descriptor FROM students WHERE id = ?");
$stmt->bind_param("s", $student_id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc() ?: die("Student not found.");
$student_full_name = $row['full_name'];
$student_face_descriptor_json = $row['face_descriptor'];

/* ──────────────────────────────────
   7.  CHECK CURRENT TIME IS ALLOWED BASED ON ENABLED SESSIONS
   ────────────────────────────────── */
$current_time = date('H:i:s');
$timeAllowed = false;
$allowedTimes = [];

// Check AM session
if ($am_enabled === 1) {
    $allowedTimes[] = date('g:i A', strtotime($am_start)) . ' - ' . date('g:i A', strtotime($am_end));
    if ($current_time >= $am_start && $current_time <= $am_end) {
        $timeAllowed = true;
    }
}

// Check PM session
if ($pm_enabled === 1) {
    $allowedTimes[] = date('g:i A', strtotime($pm_start)) . ' - ' . date('g:i A', strtotime($pm_end));
    if ($current_time >= $pm_start && $current_time <= $pm_end) {
        $timeAllowed = true;
    }
}

/* ──────────────────────────────────
   8.  HANDLE SUBMIT
   ────────────────────────────────── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['attendance_confirmed'] ?? '') === 'yes') {

    $today = date('Y-m-d');

    if (!$timeAllowed) {
        if (count($allowedTimes) > 0) {
            $attendanceMessage = "Attendance signing is only allowed between " . implode(' or ', $allowedTimes) . ".";
        } else {
            $attendanceMessage = "Attendance signing is currently disabled.";
        }
        $messageType = "error";
    } else {
        // Check if already signed today
        $dup = $conn->prepare("SELECT 1 FROM student_attendance WHERE student_id=? AND attendance_date=?");
        $dup->bind_param("ss", $student_id, $today);
        $dup->execute();
        $dupResult = $dup->get_result();
        if ($dupResult && $dupResult->num_rows > 0) {
            $attendanceMessage = "You have already signed today’s attendance.";
            $messageType = "warning";
        } else {
            // Insert attendance record
            $ins = $conn->prepare(
                "INSERT INTO student_attendance (student_id, attendance_date, status) VALUES (?, ?, 'Present')"
            );
            $ins->bind_param("ss", $student_id, $today);
            if ($ins->execute()) {
                $attendanceMessage = "Attendance signed successfully!";
                $messageType = "success";
                header("Refresh: 2; URL=student_dashboard.php");
            } else {
                $attendanceMessage = "Failed to sign attendance. Please try again.";
                $messageType = "error";
            }
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Student Face Attendance - DDU</title>
<script defer src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@2.0.0/dist/tf.min.js"></script>
<script defer src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
<style>
body{font-family:'Segoe UI',Tahoma,Verdana,sans-serif;background:#f5f5f5;margin:0;display:flex;justify-content:center;align-items:center;min-height:100vh}
.container{background:#fff;border-radius:10px;box-shadow:0 4px 20px rgba(0,0,0,.1);padding:2rem;width:90%;max-width:600px;text-align:center}
h1{color:#003366;margin-bottom:1.5rem}
#video{border-radius:8px;max-width:100%;box-shadow:0 0 10px rgba(0,51,102,.5)}
.btn{background:#003366;color:#fff;border:none;padding:.8rem 1.5rem;border-radius:6px;font-size:1rem;cursor:pointer;transition:.3s;margin-top:1rem}
.btn:hover{background:#004080}
.btn:disabled{background:#6c757d;cursor:not-allowed}
#verification-result{margin:1rem 0;font-weight:bold;min-height:24px}
.verification-success{color:#28a745}.verification-failure{color:#dc3545}
.message{padding:1rem;border-radius:6px;margin:1rem 0}
.message.success{background:#d4edda;color:#155724}
.message.warning{background:#fff3cd;color:#856404}
.message.error{background:#f8d7da;color:#721c24}
.back-btn{display:inline-block;margin-top:1rem;color:#003366;text-decoration:none;font-weight:500}
.back-btn:hover{text-decoration:underline}
.student-info{background:#f8f9fa;padding:1rem;border-radius:6px;margin-bottom:1.5rem;text-align:left}
.student-info p{margin:.5rem 0}
</style>
</head>
<body>
<div class="container">
    <h1>Student Face Attendance Verification</h1>

    <div class="student-info">
        <p><strong>Student&nbsp;ID:</strong> <?= htmlspecialchars($student_id) ?></p>
        <p><strong>Name:</strong> <?= htmlspecialchars($_SESSION['user']) ?></p>
        <p><strong>Date:</strong> <?= date('F j, Y') ?></p>
        <p><strong>Time:</strong> <?= date('g:i A') ?></p>
    </div>

    <?php if (!$timeAllowed): ?>
        <div class="message error">
            Attendance signing is only allowed between
            <?= implode(' or ', $allowedTimes) ?>.
        </div>
        <a href="student_dashboard.php" class="back-btn">← Back to Dashboard</a>

    <?php elseif ($attendanceMessage): ?>
        <div class="message <?= $messageType ?>"><?= $attendanceMessage ?></div>
        <?php if ($messageType === 'success'): ?>
            <p>Redirecting to dashboard...</p>
        <?php endif; ?>

    <?php else: ?>
        <video id="video" width="480" height="360" autoplay muted playsinline></video>
        <div id="verification-result"></div>
        <button id="capture-btn" class="btn">Capture Face for Attendance</button>

        <form id="attendance-form" method="POST" style="display:none;">
            <input type="hidden" name="attendance_confirmed" value="yes">
        </form>

        <a href="student_dashboard.php" class="back-btn">← Back to Dashboard</a>
    <?php endif; ?>
</div>

<script>
<?php if ($timeAllowed): ?>
const loggedInStudentFullName       = <?= json_encode($student_full_name) ?>;
const loggedInStudentFaceDescriptor = <?= $student_face_descriptor_json ?: 'null' ?>;

window.onload = async () => {
    const resultDiv  = document.getElementById('verification-result');
    const captureBtn = document.getElementById('capture-btn');

    if (!loggedInStudentFaceDescriptor) {
        alert("No registered face data for this student. Verification unavailable.");
        captureBtn.disabled = true;
        return;
    }

    const MODEL_URL = '/finalproject/models';
    try {
        await Promise.all([
            faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
            faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
            faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL)
        ]);
        resultDiv.textContent = "Models loaded.";
    } catch (e) {
        resultDiv.textContent = "Model load error: " + e;
        captureBtn.disabled = true;
        return;
    }

    const video = document.getElementById('video');
    try {
        video.srcObject = await navigator.mediaDevices.getUserMedia({video:{facingMode:"user"}});
    } catch (err) {
        resultDiv.textContent = "Camera error: " + err.message;
        captureBtn.disabled = true;
        return;
    }

    function euclidean(d1,d2){
        let s=0;
        for(let i=0;i<d1.length;i++){const diff=d1[i]-d2[i];s+=diff*diff;}
        return Math.sqrt(s);
    }

    captureBtn.addEventListener('click', async ()=>{
        captureBtn.disabled = true;
        resultDiv.textContent = "Verifying...";
        resultDiv.className = "";

        const det = await faceapi.detectSingleFace(video,new faceapi.TinyFaceDetectorOptions())
                   .withFaceLandmarks().withFaceDescriptor();

        if(!det){
            resultDiv.textContent = "No face detected. Try again.";
            resultDiv.className = "verification-failure";
            captureBtn.disabled = false;
            return;
        }
        const dist = euclidean(det.descriptor, new Float32Array(loggedInStudentFaceDescriptor));
        if(dist < 0.6){
            resultDiv.textContent = "✓ Face verified!";
            resultDiv.className = "verification-success";
            setTimeout(()=>document.getElementById('attendance-form').submit(), 1000);
        }else{
            resultDiv.textContent = "✗ Face does not match your registered face, " + loggedInStudentFullName + ".";
            resultDiv.className = "verification-failure";
            captureBtn.disabled = false;
        }
    });
};
<?php endif; ?>
</script>
</body>
</html>
