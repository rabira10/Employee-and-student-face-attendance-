<?php
session_start();
require 'check_status.php'; // Check if user is deactivated

// Rest of your existing auth check
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'hr') {
    header("Location: login.php");
    exit;
}

// Language switching logic
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
    header("Location: ".strtok($_SERVER['REQUEST_URI'], '?'));
    exit;
}

$lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : 'en';

// Language strings
$translations = [
    'en' => [
        'title' => 'HR Dashboard - Dire Dawa University',
        'university_name' => 'Dire Dawa University',
        'portal_name' => 'Human Resources Management Portal',
        'hr_badge' => '👥 HR Officer',
        'tools_label' => 'HR Management Tools',
        'welcome' => 'Welcome',
        'logged_in_as' => 'Logged in as',
        'total_employees' => 'Total Employees',
        'pending_leaves' => 'Pending Leave Requests',
        'present_today' => 'Present Today',
        'about_title' => 'About Dire Dawa University HR Department',
        'mission_title' => '🎯 Our Mission',
        'mission_text' => 'To support the university\'s academic excellence by managing human resources effectively...',
        'heritage_title' => '🏛️ University Heritage',
        'heritage_text' => 'Established in 2006, Dire Dawa University serves as a cornerstone of higher education...',
        'services_title' => '👨‍💼 HR Services',
        'services_text' => 'Our department manages employee registration, attendance tracking...',
        'nav_title' => 'HR Management Tools',
        'register_employee' => 'Register Employee',
        'register_desc' => 'Add new staff members',
        'view_attendance' => 'View Attendance',
        'attendance_desc' => 'Monitor employee attendance',
        'generate_report' => 'Generate Report',
        'report_desc' => 'Create detailed reports',
        'approve_leave' => 'Approve Leave Requests',
        'leave_desc' => 'Manage leave applications',
        'logout' => 'Logout',
        'logout_desc' => 'End your session',
        'set_time' => 'Set Attendance Time',
        'footer_text' => 'Dire Dawa University HR Management System - Empowering Excellence in Education',
        'location' => '📍 Dire Dawa, Ethiopia',
        'email' => '📧 hr@ddu.edu.et',
        'phone' => '📞 +251-25-111-0000',
        'account_deactivated' => 'Account Deactivated',
        'deactivation_message' => 'Your account has been deactivated by an administrator.',
        'logout_message' => 'You will be logged out automatically.',
        'button_ok' => 'OK',
        'language' => 'Language',
        'nav_home' => 'Home',
        'nav_employees' => 'Employees',
        'nav_attendance' => 'Attendance',
        'nav_leaves' => 'Leaves',
        'nav_reports' => 'Reports',
        'nav_settings' => 'Settings',
        'quick_links' => 'Quick Links',
        'contact_us' => 'Contact Us',
        'privacy_policy' => 'Privacy Policy',
        'terms_of_service' => 'Terms of Service',
        'copyright' => 'Copyright © 2023 Dire Dawa University. All rights reserved.',
        'developed_by' => 'Developed by ICT Directorate',
        'scroll_to_top' => 'Go to top',
        'about_university' => 'About DDU',
        'resources' => 'Resources',
        'support' => 'Support',
        'address' => 'Address'
    ],
    'am' => [
        'title' => 'የሰው ሀብት ዳሽቦርድ - ድሬዳዋ ዩኒቨርሲቲ',
        'university_name' => 'ድሬዳዋ ዩኒቨርሲቲ',
        'portal_name' => 'የሰው ሀብት አስተዳደር ፖርታል',
        'hr_badge' => '👥 የሰው ሀብት ባለሙያ',
        'tools_label' => 'የሰው ሀብት አስተዳደር መሳሪያዎች',
        'welcome' => 'እንኳን ደህና መጡ',
        'logged_in_as' => 'እንደ ይገቡ',
        'total_employees' => 'ጠቅላላ ሰራተኞች',
        'pending_leaves' => 'በጥበቃ ላይ ያሉ የፈቃድ ጥያቄዎች',
        'present_today' => 'ዛሬ የተገኙ',
        'about_title' => 'ስለ ድሬዳዋ ዩኒቨርሲቲ የሰው ሀብት ክፍል',
        'mission_title' => '🎯 ተልእኳችን',
        'mission_text' => 'የዩኒቨርሲቲውን የትምህርት ልሂቅነት በሰው ሀብት ውጤታማ አስተዳደር ለመደገፍ...',
        'heritage_title' => '🏛️ የዩኒቨርሲቲ ታሪክ',
        'heritage_text' => 'በ2006 ዓ.ም የተመሠረተው ድሬዳዋ ዩኒቨርሲቲ በምስራቅ ኢትዮጵያ የከፍተኛ ትምህርት መሠረት ነው...',
        'services_title' => '👨‍💼 የሰው ሀብት አገልግሎቶች',
        'services_text' => 'ክፍላችን የሰራተኛ ምዝገባ፣ የመገኘት ቅጽበታዊ መከታተያ...',
        'nav_title' => 'የሰው ሀብት አስተዳደር መሳሪያዎች',
        'register_employee' => 'ሰራተኛ ይመዝግቡ',
        'register_desc' => 'አዲስ ሰራተኛ ያክሉ',
        'view_attendance' => 'መገኘት ይመልከቱ',
        'attendance_desc' => 'የሰራተኞችን መገኘት ይከታተሉ',
        'generate_report' => 'ሪፖርት ይፍጠሩ',
        'report_desc' => 'ዝርዝር ሪፖርቶችን ይፍጠሩ',
        'approve_leave' => 'የፈቃድ ጥያቄዎችን ይፈቀዱ',
        'leave_desc' => 'የፈቃድ ማመልከቻዎችን ያስተዳድሩ',
        'logout' => 'ውጣ',
        'logout_desc' => 'ክፍለ ጊዜዎን ያበቃል',
        'set_time' => 'የመገኘት ጊዜ ያቀናብሩ',
        'footer_text' => 'ድሬዳዋ ዩኒቨርሲቲ የሰው ሀብት አስተዳደር ስርዓት - በትምህርት የላቀ አገልግሎት',
        'location' => '📍 ድሬዳዋ፣ ኢትዮጵያ',
        'email' => '📧 hr@ddu.edu.et',
        'phone' => '📞 +251-25-111-0000',
        'account_deactivated' => 'መለያ ተሰናክሏል',
        'deactivation_message' => 'መለያዎ በአስተዳዳሪ ተሰናክሏል።',
        'logout_message' => 'በራስ-ሰር ከስርዓቱ ይወጣሉ።',
        'button_ok' => 'እሺ',
        'language' => 'ቋንቋ',
        'nav_home' => 'መነሻ',
        'employee Registration' => 'የሠራተኞች ምዝገባ',
        'nav_attendance' => 'መገኘት',
        'nav_leaves' => 'ፈቃዶች',
        'nav_reports' => 'ሪፖርቶች',
        'settings' => 'ሰአት ማስተካከያ',
        'quick_links' => 'ፈጣን አገናኞች',
        'contact_us' => 'አግኙን',
        'privacy_policy' => 'የግላዊነት ፖሊሲ',
        'terms_of_service' => 'የአገልግሎት ውሎች',
        'copyright' => 'የቅጂ መብት © 2023 ድሬዳዋ ዩኒቨርሲቲ. ሁሉም መብቶች የተጠበቁ ናቸው።',
        'developed_by' => 'በ ICT ዳይሬክቶሬት የተዘጋጀ',
        'scroll_to_top' => 'ወደ ላይ ይሂዱ',
        'about_university' => 'ስለ DDU',
        'resources' => 'መርጃዎች',
        'support' => 'ድጋፍ',
        'address' => 'አድራሻ'
    ]
];

function t($key) {
    global $translations, $lang;
    return $translations[$lang][$key] ?? $key;
}

// DB connection for additional data
$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get HR user details
$username = $_SESSION['user'];
$stmt = $conn->prepare("
    SELECT e.full_name 
    FROM employees e 
    JOIN users u ON e.username = u.username 
    WHERE e.username = ?
");

$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$hr_user = $result->fetch_assoc();
$full_name = $hr_user ? $hr_user['full_name'] : $username;

// Get dashboard statistics
$total_employees_query = "SELECT COUNT(*) as total FROM employees";
$total_employees_result = $conn->query($total_employees_query);
$total_employees = $total_employees_result->fetch_assoc()['total'];

$pending_leaves_query = "SELECT COUNT(*) as pending FROM leave_requests WHERE status = 'pending'";
$pending_leaves_result = $conn->query($pending_leaves_query);
$pending_leaves = $pending_leaves_result->fetch_assoc()['pending'];

// Present Today count - using single status column
$today_attendance_query = "SELECT COUNT(DISTINCT username) as present 
                          FROM attendance 
                          WHERE date = CURDATE() 
                          AND status = 'Present'";
$today_attendance_result = $conn->query($today_attendance_query);
$today_attendance = $today_attendance_result->fetch_assoc()['present'];
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo t('title'); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #003366 0%, #1a4d6b 100%);
            min-height: 100vh;
            color: #333;
            animation: fadeIn 0.5s ease-in;
            display: flex;
            flex-direction: column;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideIn {
            from { transform: translateX(-30px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes scaleIn {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        /* Header */
        .header {
            background: white;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border-bottom: 4px solid #FFCC00;
            padding: 1.5rem 0;
            animation: slideIn 0.6s ease-out;
            position: relative;
            z-index: 1000;
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .logo {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #FFCC00;
            box-shadow: 0 4px 15px rgba(0,51,102,0.3);
        }

        .university-info h1 {
            color: #003366;
            font-size: 2.2rem;
            margin-bottom: 0.3rem;
            font-weight: 700;
        }

        .university-info p {
            color: #666;
            font-size: 1rem;
            font-weight: 500;
        }

        .hr-badge {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
            padding: 0.8rem 1.5rem;
            border-radius: 25px;
            font-weight: bold;
            font-size: 1rem;
            box-shadow: 0 4px 15px rgba(255,204,0,0.3);
        }

        .tools-badge {
            background: linear-gradient(135deg, #003366, #004080);
            color: white;
            padding: 0.8rem 1.5rem;
            border-radius: 25px;
            font-weight: bold;
            font-size: 1rem;
            box-shadow: 0 4px 15px rgba(0,51,102,0.3);
            transition: all 0.3s ease;
            position: relative;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .tools-badge:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0,51,102,0.4);
        }

        .tools-badge .arrow {
            transition: transform 0.3s ease;
        }

        .tools-badge.active .arrow {
            transform: rotate(180deg);
        }

        .badge-container {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 0.5rem;
            position: relative;
        }

        .tools-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            min-width: 250px;
            border-radius: 10px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            z-index: 100;
            margin-top: 10px;
            overflow: hidden;
            animation: fadeIn 0.3s ease-out;
        }

        .tools-dropdown.show {
            display: block;
        }

        .tools-dropdown a {
            display: flex;
            align-items: center;
            padding: 0.8rem 1.5rem;
            color: #333;
            text-decoration: none;
            transition: all 0.2s ease;
            border-bottom: 1px solid #f0f0f0;
        }

        .tools-dropdown a:hover {
            background: #f0f9ff;
            color: #003366;
            padding-left: 1.8rem;
        }

        .tools-dropdown a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
            font-size: 1.1rem;
        }

        .tools-dropdown a small {
            margin-left: auto;
            font-size: 0.8rem;
            color: #888;
        }

        /* Navigation Links */
        .nav-links {
            display: flex;
            gap: 1rem;
            margin-left: 2rem;
        }

        .nav-link {
            color: #003366;
            text-decoration: none;
            font-weight: 600;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .nav-link:hover {
            background: rgba(255, 204, 0, 0.2);
            color: #003366;
        }

        .nav-link.active {
            background: #FFCC00;
            color: #003366;
        }

        /* Language Button */
        .language-btn {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #003366;
            margin-right: 10px;
        }

        .language-btn:hover {
            background: white;
            color: #003366;
            transform: scale(1.1);
        }

        /* Main Container - Updated for full height */
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
            flex: 1;
            width: 100%;
            min-height: calc(100vh - 200px); /* Adjust based on header/footer height */
            display: flex;
            flex-direction: column;
        }

        /* Welcome Section - Updated for full height */
        .welcome-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 3rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            animation: scaleIn 0.7s ease-out;
            flex: 1;
        }

        .welcome-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 2rem;
        }

        .welcome-text h2 {
            color: #003366;
            font-size: 3rem;
            margin-bottom: 0.5rem;
            font-weight: 700;
        }

        .welcome-text p {
            color: #666;
            font-size: 1.3rem;
            margin-bottom: 1rem;
        }

        .user-info {
            text-align: right;
            background: linear-gradient(135deg, #f0f9ff, #fffbf0);
            padding: 1.5rem;
            border-radius: 15px;
            border-left: 4px solid #FFCC00;
        }

        .user-info strong {
            color: #003366;
            font-size: 1.2rem;
        }

        /* Statistics Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 3rem;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            animation: scaleIn 0.8s ease-out;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 45px rgba(0,0,0,0.15);
        }

        .stat-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
        }

        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            color: #003366;
            margin-bottom: 0.5rem;
        }

        .stat-label {
            color: #666;
            font-size: 1.1rem;
            font-weight: 500;
        }

        /* About Section */
        .about-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 3rem;
            margin-bottom: 3rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            animation: slideIn 0.9s ease-out;
        }

        .about-section h3 {
            color: #003366;
            font-size: 2rem;
            margin-bottom: 1.5rem;
            text-align: center;
        }

        .about-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }

        .about-card {
            background: linear-gradient(135deg, #f0f9ff, #fffbf0);
            padding: 2rem;
            border-radius: 15px;
            border-left: 4px solid #FFCC00;
        }

        .about-card h4 {
            color: #003366;
            margin-bottom: 1rem;
            font-size: 1.3rem;
        }

        .about-card p {
            color: #555;
            line-height: 1.6;
        }

        /* Navigation Section */
        .nav-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 3rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            animation: fadeIn 1s ease-out;
        }

        .nav-title {
            text-align: center;
            color: #003366;
            font-size: 2rem;
            margin-bottom: 2rem;
            font-weight: 700;
        }

        .nav-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .nav-card {
            background: linear-gradient(135deg, #003366, #004080);
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.3s ease;
            box-shadow: 0 8px 32px rgba(0,51,102,0.2);
        }

        .nav-card:hover {
            transform: translateY(-8px) scale(1.02);
            box-shadow: 0 15px 50px rgba(0,51,102,0.3);
        }

        .nav-button {
            width: 100%;
            background: transparent;
            color: white;
            border: none;
            padding: 2.5rem;
            font-size: 1.2rem;
            font-weight: 600;
            cursor: pointer;
            transition: all -0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1rem;
            text-decoration: none;
        }

        .nav-button:hover {
            background: rgba(255, 204, 0, 0.1);
            color: #FFCC00;
        }

        .nav-icon {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }

        /* Special Attendance Time Button */
        .special-action {
            display: flex;
            justify-content: center;
            margin-top: 2rem;
        }

        .special-button {
            background: linear-gradient(135deg, #FFCC00, #FFD700);
            color: #003366;
            padding: 1.5rem 3rem;
            border-radius: 50px;
            font-size: 1.3rem;
            font-weight: bold;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 8px 25px rgba(255,204,0,0.3);
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .special-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 35px rgba(255,204,0,0.4);
            background: linear-gradient(135deg, #FFD700, #FFA500);
        }

        /* Logout Button Styles */
        .logout-btn {
            background: #e74c3c;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            margin-left: 10px;
        }

        .logout-btn:hover {
            background: #c0392b;
            transform: translateY(-2px);
        }

        /* Font Awesome for the icon (if not already included) */
        @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css');

        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.7);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            max-width: 500px;
            text-align: center;
        }

        .modal button {
            background: #003366;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            margin-top: 1rem;
            cursor: pointer;
        }

        /* Scroll to top button */
        .scroll-to-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 50px;
            height: 50px;
            background: #003366;
            color: white;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            z-index: 1000;
        }
        
        .scroll-to-top.visible {
            opacity: 1;
            visibility: visible;
        }
        
        .scroll-to-top:hover {
            background: #FFCC00;
            color: #003366;
            transform: translateY(-3px);
        }

        /* Enhanced Footer */
        .footer {
            background: #003366;
            color: white;
            padding: 3rem 0 0;
            margin-top: auto;
        }

        .footer-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
        }

        .footer-section {
            margin-bottom: 2rem;
        }

        .footer-section h3 {
            color: #FFCC00;
            margin-bottom: 1.5rem;
            font-size: 1.3rem;
            position: relative;
            padding-bottom: 0.5rem;
        }

        .footer-section h3::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 50px;
            height: 2px;
            background: #FFCC00;
        }

        .footer-links {
            list-style: none;
        }

        .footer-links li {
            margin-bottom: 0.8rem;
        }

        .footer-links a {
            color: #ddd;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-block;
        }

        .footer-links a:hover {
            color: #FFCC00;
            transform: translateX(5px);
        }

        .contact-info {
            list-style: none;
        }

        .contact-info li {
            margin-bottom: 1rem;
            display: flex;
            align-items: flex-start;
            gap: 0.8rem;
        }

        .contact-info i {
            color: #FFCC00;
            margin-top: 3px;
        }

        .footer-bottom {
            background: #002244;
            padding: 1.5rem 0;
            text-align: center;
            margin-top: 2rem;
        }

        .footer-bottom p {
            color: #aaa;
            font-size: 0.9rem;
            margin-bottom: 0;
        }

        .footer-bottom p a {
            color: #FFCC00;
            text-decoration: none;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 1.5rem;
                text-align: center;
            }

            .nav-links {
                margin-left: 0;
                margin-top: 1rem;
                justify-content: center;
                flex-wrap: wrap;
            }

            .badge-container {
                align-items: center;
                flex-direction: row;
                justify-content: center;
                width: 100%;
            }

            .tools-dropdown {
                left: 0;
                right: auto;
                width: 100%;
            }

            .welcome-header {
                flex-direction: column;
                gap: 1.5rem;
            }

            .user-info {
                text-align: left;
            }

            .nav-grid {
                grid-template-columns: 1fr;
            }

            .container {
                padding: 1rem;
            }

            .welcome-text h2 {
                font-size: 2.2rem;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .about-content {
                grid-template-columns: 1fr;
            }

            .footer-container {
                grid-template-columns: 1fr;
                padding: 0 1rem;
            }

            .scroll-to-top {
                bottom: 20px;
                right: 20px;
                width: 40px;
                height: 40px;
                font-size: 1.2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-content">
            <div class="logo-section">
                <img src="images/ddu.jfif" alt="Dire Dawa University Logo" class="logo">
                <div class="university-info">
                    <h1><?php echo t('university_name'); ?></h1>
                    <p><?php echo t('portal_name'); ?></p>
                </div>
                
                <!-- Navigation Links -->
                <div class="nav-links">
                    <a href="dashboard_hr.php" class="nav-link active"><?php echo t('nav_home'); ?></a>
                    <a href="register_employee.php" class="nav-link"><?php echo t('employee Registration'); ?></a>
                    <a href="view_attendance.php" class="nav-link"><?php echo t('nav_attendance'); ?></a>
                    <a href="approve_leave.php" class="nav-link"><?php echo t('nav_leaves'); ?></a>
                    <a href="update_attendance_time.php" class="nav-link"><?php echo t('settings'); ?></a>
                    <a href="login.php" class="logout-btn" title="<?php echo t('logout'); ?>">
                    <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                </a>
                </div>
            </div>
            
            <div class="badge-container">
                <button class="language-btn" onclick="toggleLanguage()" title="<?php echo t('language'); ?>">
                    <?php echo $lang === 'en' ? 'አማ' : 'EN'; ?>
                </button>
                
            </div>
        </div>
    </div>

    <!-- Main Container - Now takes full available height -->
    <div class="container">
        <!-- Welcome Section - Expanded to fill space -->
        <div class="welcome-section">
            <div class="welcome-header">
                <div class="welcome-text">
                    <h2><?php echo t('welcome'); ?>, <?php echo htmlspecialchars($full_name); ?>!</h2>
                    <p><?php echo t('title'); ?></p>
                    <p style="font-size: 1rem; color: #888;"><?php echo t('portal_name'); ?></p>
                </div>
                <div class="user-info">
                    <p><?php echo t('logged_in_as'); ?>:</p>
                    <strong><?php echo htmlspecialchars($_SESSION['user']); ?></strong>
                    <div style="margin-top: 0.5rem; font-size: 0.9rem; color: #666;">
                        📅 <?php echo date('F j, Y'); ?>
                    </div>
                </div>
            </div>
            
            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div class="stat-number"><?php echo $total_employees; ?></div>
                    <div class="stat-label"><?php echo t('total_employees'); ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">📋</div>
                    <div class="stat-number"><?php echo $pending_leaves; ?></div>
                    <div class="stat-label"><?php echo t('pending_leaves'); ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">✅</div>
                    <div class="stat-number"><?php echo $today_attendance; ?></div>
                    <div class="stat-label"><?php echo t('present_today'); ?></div>
                </div>
            </div>
        </div>

        <!-- About Section -->
        <div class="about-section">
            <h3><?php echo t('about_title'); ?></h3>
            <div class="about-content">
                <div class="about-card">
                    <h4><?php echo t('mission_title'); ?></h4>
                    <p><?php echo t('mission_text'); ?></p>
                </div>
                <div class="about-card">
                    <h4><?php echo t('heritage_title'); ?></h4>
                    <p><?php echo t('heritage_text'); ?></p>
                </div>
                <div class="about-card">
                    <h4><?php echo t('services_title'); ?></h4>
                    <p><?php echo t('services_text'); ?></p>
                </div>
            </div>
        </div>

        <!-- Navigation Section -->
        <div class="nav-section">
            <h3 class="nav-title"><?php echo t('nav_title'); ?></h3>
            <div class="nav-grid">
                <div class="nav-card">
                    <a href="register_employee.php" class="nav-button">
                        <div class="nav-icon">👤</div>
                        <span><?php echo t('register_employee'); ?></span>
                        <small><?php echo t('register_desc'); ?></small>
                    </a>
                </div>
                <div class="nav-card">
                    <a href="view_attendance.php" class="nav-button">
                        <div class="nav-icon">📊</div>
                        <span><?php echo t('view_attendance'); ?></span>
                        <small><?php echo t('attendance_desc'); ?></small>
                    </a>
                </div>
                <div class="nav-card">
                    <a href="generate_report.php" class="nav-button">
                        <div class="nav-icon">📄</div>
                        <span><?php echo t('generate_report'); ?></span>
                        <small><?php echo t('report_desc'); ?></small>
                    </a>
                </div>
                <div class="nav-card">
                    <a href="approve_leave.php" class="nav-button">
                        <div class="nav-icon">📝</div>
                        <span><?php echo t('approve_leave'); ?></span>
                        <small><?php echo t('leave_desc'); ?></small>
                    </a>
                </div>
                <div class="nav-card">
                    <a href="logout.php" class="nav-button">
                        <div class="nav-icon">🚪</div>
                        <span><?php echo t('logout'); ?></span>
                        <small><?php echo t('logout_desc'); ?></small>
                    </a>
                </div>
            </div>
            <div class="special-action">
                <a href="update_attendance_time.php" class="special-button">
                    <i class="fas fa-clock"></i>
                    <?php echo t('set_time'); ?>
                </a>
            </div>
        </div>
    </div>

    <!-- Enhanced Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h3><?php echo t('about_university'); ?></h3>
                <p><?php echo t('heritage_text'); ?></p>
            </div>
            
            <div class="footer-section">
                <h3><?php echo t('quick_links'); ?></h3>
                <ul class="footer-links">
                    <li><a href="dashboard_hr.php"><?php echo t('nav_home'); ?></a></li>
                    <li><a href="register_employee.php"><?php echo t('register_employee'); ?></a></li>
                    <li><a href="view_attendance.php"><?php echo t('view_attendance'); ?></a></li>
                    <li><a href="approve_leave.php"><?php echo t('approve_leave'); ?></a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h3><?php echo t('resources'); ?></h3>
                <ul class="footer-links">
                    <li><a href="#"><?php echo t('privacy_policy'); ?></a></li>
                    <li><a href="#"><?php echo t('terms_of_service'); ?></a></li>
                    <li><a href="#">HR Policies</a></li>
                    <li><a href="#">Employee Handbook</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h3><?php echo t('contact_us'); ?></h3>
                <ul class="contact-info">
                    <li>
                        <i class="fas fa-map-marker-alt"></i>
                        <span><?php echo t('address'); ?>: <?php echo t('location'); ?></span>
                    </li>
                    <li>
                        <i class="fas fa-phone"></i>
                        <span><?php echo t('phone'); ?></span>
                    </li>
                    <li>
                        <i class="fas fa-envelope"></i>
                        <span><?php echo t('email'); ?></span>
                    </li>
                    <li>
                        <i class="fas fa-clock"></i>
                        <span>Mon-Fri: 8:30 AM - 5:30 PM</span>
                    </li>
                </ul>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p><?php echo t('copyright'); ?> | <?php echo t('developed_by'); ?></p>
        </div>
    </footer>

    <!-- Scroll to top button -->
    <button class="scroll-to-top" id="scrollToTopBtn" title="<?php echo t('scroll_to_top'); ?>">↑</button>

    <script>
        // Toggle dropdown menu
        document.getElementById('toolsBadge').addEventListener('click', function(e) {
            e.stopPropagation();
            this.classList.toggle('active');
            document.getElementById('toolsDropdown').classList.toggle('show');
        });

        // Close dropdown when clicking elsewhere
        document.addEventListener('click', function() {
            document.getElementById('toolsBadge').classList.remove('active');
            document.getElementById('toolsDropdown').classList.remove('show');
        });

        // Prevent dropdown from closing when clicking inside it
        document.getElementById('toolsDropdown').addEventListener('click', function(e) {
            e.stopPropagation();
        });

        // Language switcher
        function toggleLanguage() {
            const currentLang = '<?php echo $lang; ?>';
            const newLang = currentLang === 'en' ? 'am' : 'en';
            window.location.href = `?lang=${newLang}`;
        }

        // Check account status every 30 seconds
        setInterval(checkAccountStatus, 30000);

        function checkAccountStatus() {
            fetch('check_status.php')
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'deactivated') {
                        showDeactivationModal();
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        function showDeactivationModal() {
            // Create modal HTML
            const modalHTML = `
            <div class="modal" id="deactivationModal" style="display:block">
                <div class="modal-content">
                    <h3><?php echo t('account_deactivated'); ?></h3>
                    <p><?php echo t('deactivation_message'); ?></p>
                    <p><?php echo t('logout_message'); ?></p>
                    <button onclick="logout()"><?php echo t('button_ok'); ?></button>
                </div>
            </div>
            `;
            
            // Add to body
            document.body.insertAdjacentHTML('beforeend', modalHTML);
            
            // Auto logout after 5 seconds
            setTimeout(logout, 5000);
        }

        function logout() {
            window.location.href = 'logout.php';
        }

        // Scroll to top button functionality
        const scrollToTopBtn = document.getElementById("scrollToTopBtn");
        
        // Show the button when user scrolls down 300px from the top
        window.onscroll = function() {
            if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
                scrollToTopBtn.classList.add("visible");
            } else {
                scrollToTopBtn.classList.remove("visible");
            }
        };
        
        // Scroll to top when button is clicked
        scrollToTopBtn.addEventListener("click", function() {
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        });
    </script>
</body>
</html>