<?php
require_once 'config.php';
require_once 'auth.php';

$sessionUsername = Auth::checkEmployeeAuth();
$db = new Database();
$users = $db->getAllEmployees();

// Fetch allowed attendance times from DB
$conn = new mysqli("localhost", "root", "", "ddu_attendance");
$allowedTimes = ['am_start_time' => '', 'am_end_time' => '', 'pm_start_time' => '', 'pm_end_time' => ''];
if (!$conn->connect_error) {
    $res = $conn->query("SELECT am_start_time, am_end_time, pm_start_time, pm_end_time FROM attendance_settings WHERE id = 1");
    if ($res && $res->num_rows > 0) {
        $allowedTimes = $res->fetch_assoc();
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>DDU Face Verification System</title>
    <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@2.0.0"></script>
    <script src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
    <style>
        .status-success { color: #10b981; }
        .status-error { color: #ef4444; }
        .status-warning { color: #f59e0b; }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <div class="text-center mb-8">
            <h1 class="text-4xl font-bold text-gray-800 mb-2">DDU Attendance System</h1>
            <p class="text-gray-600">Secure facial recognition attendance verification</p>
        </div>

        <div class="max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-6">
            <div class="text-center">
                <h2 class="text-2xl font-semibold mb-6">📷 Face Verification</h2>
                <div class="relative inline-block">
                    <video id="video" width="480" height="360" autoplay muted class="border-2 border-gray-300 rounded-lg shadow-md"></video>
                    <canvas id="overlay" class="absolute top-0 left-0"></canvas>
                </div>
                <div id="status" class="mt-6 text-lg font-medium"></div>
                <div id="result" class="mt-4 hidden"></div>
            </div>
        </div>
    </div>

    <script>
    class FaceRecognitionSystem {
        constructor() {
            this.video = document.getElementById('video');
            this.statusElement = document.getElementById('status');
            this.resultElement = document.getElementById('result');
            this.employees = <?= json_encode($users) ?>;
            this.sessionUser = <?= json_encode($sessionUsername) ?>;
            this.matcher = null;
            this.detectionInterval = null;

            // Allowed attendance times from PHP
            this.amStart = "<?= $allowedTimes['am_start_time'] ?>";
            this.amEnd = "<?= $allowedTimes['am_end_time'] ?>";
            this.pmStart = "<?= $allowedTimes['pm_start_time'] ?>";
            this.pmEnd = "<?= $allowedTimes['pm_end_time'] ?>";
        }

        updateStatus(message, type = 'info') {
            const icons = {
                'success': '✅',
                'error': '❌',
                'warning': '⚠️',
                'info': 'ℹ️'
            };

            const classes = {
                'success': 'status-success',
                'error': 'status-error',
                'warning': 'status-warning',
                'info': 'text-blue-600'
            };

            this.statusElement.innerHTML = message;
            this.statusElement.className = `mt-6 text-lg font-medium ${classes[type]}`;
        }

        async loadModels() {
            try {
                await Promise.all([
                    faceapi.nets.tinyFaceDetector.loadFromUri('/finalproject/models'),
                    faceapi.nets.faceLandmark68Net.loadFromUri('/finalproject/models'),
                    faceapi.nets.faceRecognitionNet.loadFromUri('/finalproject/models')
                ]);
                return true;
            } catch (error) {
                console.error('Model loading error:', error);
                this.updateStatus('Failed to load face recognition models', 'error');
                return false;
            }
        }

        setupFaceMatcher() {
            const labeledDescriptors = this.employees.map(emp => {
                return new faceapi.LabeledFaceDescriptors(
                    emp.username,
                    [new Float32Array(emp.descriptor)]
                );
            });
            this.matcher = new faceapi.FaceMatcher(labeledDescriptors, 0.4);
        }

        async initializeCamera() {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({
                    video: { width: 480, height: 360 }
                });
                this.video.srcObject = stream;
                return true;
            } catch (error) {
                console.error('Camera access error:', error);
                this.updateStatus('Could not access camera. Please allow camera permissions.', 'error');
                return false;
            }
        }

        async detectFace() {
            const detection = await faceapi
                .detectSingleFace(this.video, new faceapi.TinyFaceDetectorOptions())
                .withFaceLandmarks()
                .withFaceDescriptor();

            if (!detection) {
                this.updateStatus('Please position your face in front of the camera', 'warning');
                return;
            }

            const bestMatch = this.matcher.findBestMatch(detection.descriptor);
            console.log("Face matched:", bestMatch.label, "| Confidence:", (1 - bestMatch.distance).toFixed(2));

            this.processMatch(bestMatch);
        }

        processMatch(bestMatch) {
            if (bestMatch.label === "unknown") {
                this.updateStatus('Face not recognized in the system', 'error');
            } else if (bestMatch.label === this.sessionUser) {
                this.onSuccessfulMatch();
            } else {
                this.updateStatus(`Access denied. You are identified as ${bestMatch.label}, not ${this.sessionUser}`, 'error');
            }
        }

        onSuccessfulMatch() {
            clearInterval(this.detectionInterval);
            this.updateStatus('Identity verified! Submitting attendance...', 'success');

            this.submitAttendance();
        }

        async submitAttendance() {
            try {
                const response = await fetch('submit_attendance.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        verified: true,
                        timestamp: new Date().toISOString()
                    })
                });

                const result = await response.text();
                this.resultElement.innerHTML = result;
                this.resultElement.classList.remove('hidden');

            } catch (error) {
                console.error('Attendance submission error:', error);
                this.updateStatus('Error submitting attendance. Please try again.', 'error');
            }
        }

        async start() {
            // Check current time against allowed attendance windows
            const now = new Date();
            const formatTime = (date) => date.toTimeString().slice(0,5); // "HH:MM"
            const currentTime = formatTime(now);

            const isBetween = (time, start, end) => {
                return (time >= start && time <= end);
            };

            if (
                !isBetween(currentTime, this.amStart.slice(0,5), this.amEnd.slice(0,5)) &&
                !isBetween(currentTime, this.pmStart.slice(0,5), this.pmEnd.slice(0,5))
            ) {
                this.updateStatus(
                    `⛔ Attendance is NOT allowed at this time.<br>` +
                    `Current Time: <strong>${currentTime}</strong><br>` +
                    `Allowed Times:<br>` +
                    `&nbsp;&nbsp;AM: <strong>${this.amStart.slice(0,5)} - ${this.amEnd.slice(0,5)}</strong><br>` +
                    `&nbsp;&nbsp;PM: <strong>${this.pmStart.slice(0,5)} - ${this.pmEnd.slice(0,5)}</strong>`,
                    "error"
                );
                return; // stop, do NOT start camera or recognition
            }

            this.updateStatus('Loading face recognition models...', 'info');

            const modelsLoaded = await this.loadModels();
            if (!modelsLoaded) return;

            this.setupFaceMatcher();

            const cameraReady = await this.initializeCamera();
            if (!cameraReady) return;

            this.video.addEventListener('play', () => {
                this.updateStatus('Ready! Look at the camera for verification', 'info');

                this.detectionInterval = setInterval(() => {
                    this.detectFace();
                }, 2000);
            });
        }
    }

    // Initialize the system
    const faceSystem = new FaceRecognitionSystem();
    faceSystem.start();
    </script>
</body>
</html>
