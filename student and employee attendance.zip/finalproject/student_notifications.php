<?php
// student_notifications.php
require_once 'config.php';
require_once 'auth.php';

// Initialize variables
$username = '';
$notifications = [];
$error_message = '';

try {
    // Authenticate the student
    $username = Auth::checkStudentAuth();
    
    // Initialize database connection
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get notifications for this student (both individual and all)
    try {
        $query = "
            SELECT 
                n.id,
                n.message,
                n.is_read,
                n.created_at,
                n.status,
                n.target_role,
                IFNULL(u.full_name, 'System') AS sender_name
            FROM notifications n
            LEFT JOIN users u ON n.username = u.username
            WHERE (n.username = ? AND n.target_role = 'individual') 
               OR (n.target_role = 'all')
            ORDER BY n.created_at DESC
            LIMIT 50";
        
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            throw new Exception("Database query preparation failed: " . $conn->error);
        }
        
        if (!$stmt->bind_param("s", $username)) {
            throw new Exception("Failed to bind parameters: " . $stmt->error);
        }
        
        if (!$stmt->execute()) {
            throw new Exception("Failed to execute query: " . $stmt->error);
        }
        
        $result = $stmt->get_result();
        $notifications = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
    } catch (Exception $e) {
        error_log("Notification retrieval error for {$username}: " . $e->getMessage());
        $error_message = "Could not load notifications. Please try again.";
    }

    // Mark unread notifications as read
    if (!empty($notifications)) {
        try {
            // Mark individual notifications as read
            $update_query = "UPDATE notifications SET is_read = 1 
                            WHERE (username = ? AND target_role = 'individual' AND is_read = 0)
                               OR (target_role = 'all' AND is_read = 0)";
            
            $update_stmt = $conn->prepare($update_query);
            if (!$update_stmt) {
                throw new Exception("Update preparation failed");
            }
            
            if (!$update_stmt->bind_param("s", $username)) {
                throw new Exception("Update parameter binding failed");
            }
            
            if (!$update_stmt->execute()) {
                throw new Exception("Failed to mark notifications as read");
            }
            $update_stmt->close();
            
        } catch (Exception $e) {
            error_log("Notification update error for {$username}: " . $e->getMessage());
        }
    }

} catch (Exception $e) {
    error_log("System error: " . $e->getMessage());
    $error_message = "System temporarily unavailable. Please try again later.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Notifications | DDU</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .notification.unread {
            background-color: #f0f9ff;
            border-left: 4px solid #3b82f6;
        }
        .notification.important {
            border-left: 4px solid #ef4444;
        }
        .recipient-badge {
            display: inline-block;
            padding: 0.2rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.75rem;
            font-weight: 600;
            margin-left: 0.5rem;
        }
        .badge-individual {
            background-color: #e0f2fe;
            color: #0369a1;
        }
        .badge-all {
            background-color: #dcfce7;
            color: #166534;
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto px-4 py-8">
        <!-- Error Message Display -->
        <?php if (!empty($error_message)): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                <p><?= htmlspecialchars($error_message) ?></p>
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold text-gray-800">My Notifications</h1>
            <div class="flex items-center space-x-4">
                <span class="text-gray-600"><?= htmlspecialchars($username) ?></span>
                <a href="student_dashboard.php" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition">
                    <i class="fas fa-arrow-left mr-2"></i> Dashboard
                </a>
            </div>
        </div>

        <!-- Notification Summary -->
        <div class="bg-white rounded-lg shadow-md p-4 mb-6">
            <div class="flex items-center">
                <i class="fas fa-bell text-blue-500 text-xl mr-3"></i>
                <div>
                    <span class="font-medium">
                        <?= count($notifications) ?> notification(s)
                    </span>
                    <?php 
                    $unread_count = array_reduce($notifications, function($carry, $item) {
                        return $carry + ($item['is_read'] ? 0 : 1);
                    }, 0);
                    if ($unread_count > 0): ?>
                        <span class="ml-2 bg-blue-500 text-white text-xs px-2 py-1 rounded-full">
                            <?= $unread_count ?> new
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Notifications List -->
        <div class="space-y-4">
            <?php if (empty($notifications)): ?>
                <div class="bg-white rounded-lg shadow-md p-6 text-center text-gray-500">
                    <i class="fas fa-inbox text-4xl mb-3 text-gray-300"></i>
                    <p>No notifications found</p>
                </div>
            <?php else: ?>
                <?php foreach ($notifications as $notification): ?>
                    <div class="notification bg-white rounded-lg shadow-md p-6
                        <?= $notification['is_read'] ? '' : 'unread' ?>
                        <?= $notification['status'] === 'important' ? 'important' : '' ?>">
                        
                        <div class="flex justify-between items-start mb-2">
                            <div class="flex items-center">
                                <?php if ($notification['status'] === 'important'): ?>
                                    <i class="fas fa-exclamation-circle text-red-500 mr-2"></i>
                                <?php endif; ?>
                                <h3 class="font-bold text-lg">
                                    <?= htmlspecialchars($notification['message']) ?>
                                    <span class="recipient-badge <?= $notification['target_role'] === 'all' ? 'badge-all' : 'badge-individual' ?>">
                                        <?= $notification['target_role'] === 'all' ? 'All Students' : 'Personal' ?>
                                    </span>
                                </h3>
                            </div>
                            <span class="text-sm text-gray-500">
                                <?= date('M j, Y g:i A', strtotime($notification['created_at'])) ?>
                            </span>
                        </div>
                        
                        <div class="flex justify-between items-center mt-4">
                            <span class="text-sm text-gray-500">
                                From: <?= htmlspecialchars($notification['sender_name']) ?>
                            </span>
                            <?php if (!empty($notification['attachment_url'])): ?>
                                <a href="<?= htmlspecialchars($notification['attachment_url']) ?>" 
                                   class="text-blue-500 hover:text-blue-700 text-sm"
                                   download>
                                    <i class="fas fa-paperclip mr-1"></i> Download
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Auto-refresh every 5 minutes (300000ms)
        setTimeout(() => {
            window.location.reload();
        }, 300000);
    </script>
</body>
</html>