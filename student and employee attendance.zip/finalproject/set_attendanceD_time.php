<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student_dean') {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "ddu_attendance");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];

    // Check if already set
    $check = $conn->query("SELECT * FROM attendance_settings WHERE role = 'student'");
    if ($check->num_rows > 0) {
        $stmt = $conn->prepare("UPDATE attendance_settings SET start_time = ?, end_time = ? WHERE role = 'student'");
        $stmt->bind_param("ss", $start_time, $end_time);
    } else {
        $stmt = $conn->prepare("INSERT INTO attendance_settings (role, start_time, end_time) VALUES ('student', ?, ?)");
        $stmt->bind_param("ss", $start_time, $end_time);
    }

    if ($stmt->execute()) {
        $msg = "✅ Attendance sign-in time updated successfully.";
    } else {
        $msg = "❌ Failed to update: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Set Student Attendance Time - Student Dean</title>
</head>
<body>
    <h2>📅 Set Attendance Sign-in Time for Students</h2>
    <form method="POST" action="">
        <label>Start Time:</label>
        <input type="time" name="start_time" required><br><br>
        <label>End Time:</label>
        <input type="time" name="end_time" required><br><br>
        <button type="submit">Set Time</button>
    </form>
    <?php if ($msg): ?>
        <p><?php echo $msg; ?></p>
    <?php endif; ?>
</body>
</html>
